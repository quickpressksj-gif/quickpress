# QuickPress Partner App – PRD

## Problem Statement
User uploaded an existing QuickPress backend (FastAPI + MongoDB, customer-app focused) and asked to build the complete **Partner Application** on top of it. Constraints:
- Use the existing backend / database
- Reuse existing tables and APIs where possible
- Add only what's missing
- Do not duplicate users / orders / payments / notifications
- UI/UX same as Zomato Partner app + Zomato-style alert notifications
- All features must be database-driven
- Approval workflow lives ONLY in Admin panel

## Architecture
- **Backend**: FastAPI + Motor (MongoDB) under `/app/backend` with modular routers (auth, catalog, customer, orders, partner, admin). DB: `quickpress_db`.
- **Frontend**: React 19 + React Router 7 + Tailwind, mobile-portrait Zomato-style shell in `/app/frontend`.
- **Auth**: Mobile OTP (mocked — OTP returned in API response). Bearer token sessions stored in Mongo `user_sessions`.

## Backend additions (only what was missing)
- `POST /api/partner/apply` — Become New Partner (creates Pending partner with shop/KYC details + documents). Idempotent re-apply.
- `GET /api/partner/application-status` — partner-app gating.
- `GET /api/admin/partners?status=` — list partners by status.
- `GET /api/admin/partners/{id}` — partner detail with documents.
- `POST /api/admin/partners/{id}/approve` — approval (writes notification).
- `POST /api/admin/partners/{id}/reject` — rejection with reason.
- `POST /api/admin/partners/{id}/seed-demo` — admin-only seed demo orders/settlements/reviews/payouts for an approved partner.
- `POST /api/admin/partners/{id}/spawn-order` — admin sends a fresh "Order Created" order so the partner app rings.
- `PATCH /api/partner/bank` — partner saves bank account/IFSC/UPI for payouts.
- `GET /api/partner/payouts/cycle?range=current|last|last2` — Zomato-style detailed payout breakdown (A+B+C+D+E+F).
- `GET /api/partner/orders/poll?since=` — lightweight polling for real-time new-order alerts.
- `POST /api/partner/demo-seed` is now **403 (deprecated)**; replaced by admin endpoint.

## Frontend features implemented
- `/login` — OTP login (Zomato-style toast)
- `/apply` — 3-step Become Partner form (Owner + OTP → Shop details → KYC docs)
- `/pending` — Auto-polling application status with explicit redirect on approval; "Rejected" allows reapply
- `/hub` — Dashboard with My Feed / Sales / Funnel / Service quality / Kitchen tabs, today-so-far chart, KPIs, Quick links
- `/orders` — Tabs (New / Preparing / Processing / Ready / Pickup / Completed / Cancelled) with accept/reject/advance actions
- `/menu` — Services CRUD + Pricing
- `/growth` — Offers & Ads with create flows; running campaigns visible with live metrics
- `/finance` — Earnings/Settlements/Past cycles; clicking a cycle opens detailed Zomato-style breakdown
- `/finance/cycle/:range` — Full Zomato-style Settlement summary: Summary / Orders / Expenses tabs, Net payout, A+B+C+D+E+F expandable breakdown, UTR + Account no.
- `/reviews` — Avg rating + reply
- `/reports` — Daily/weekly/monthly KPIs and top services
- `/support` — Ticket creation and history
- `/notifications` — System notifications (approve/reject)
- `/bank` — Bank & Payout settings (account, IFSC, UPI)
- `/admin` — Admin console: Pending / Approved / Rejected partners with Approve / Reject / Seed Demo / Send Test Order actions
- **Global NewOrderAlert** — WebAudio ringtone (two-tone ding loop), Zomato-style modal with countdown + Accept/Reject, polls `/api/partner/orders/poll` every 8 s

## What's been implemented (chronological)
- 2026-01-XX: Imported the QuickPress backend into `/app/backend`, kept all existing tables/endpoints intact
- 2026-01-XX: Added Become-Partner + Admin-Approval endpoints
- 2026-01-XX: Built React Zomato-style Partner app frontend (Login, Apply, Pending, Hub, Orders, Menu, Growth, Finance, Reviews, Reports, Support, Notifications, Admin)
- 2026-01-XX: Iteration 1 — passed 20/20 backend tests, fixed bottom-nav z-index & first-click redirect from /pending
- 2026-01-XX: Iteration 2 — Removed partner-side demo-seed; added admin-only seed + spawn-order; built Zomato-style detailed PayoutCycle page; added global NewOrderAlert with ringtone + 30s countdown; added Bank settings; verified end-to-end
- 2026-01-XX: Iteration 3 — Added complete Partner Order Processing Workflow: Accept → Start Processing (timestamps) → Image uploads (Before/After/QC/Packed) → Mark Ready validates min 2 QC + min 2 packed images; audit logs for every action; new endpoints for /upload-images, /complete-processing, /alerts, /audit-logs, /orders/{id} detail; Socket.IO realtime layer added (with polling fallback at /orders-poll); OrderDetail page with timeline + audit log; Hub dashboard alerts strip. Iteration-3 testing: 22/23 backend pytest + 100% frontend; critical route-collision bug fixed (renamed /orders/poll → /orders-poll).

## Personas
- **Partner / Shop owner** — applies, manages orders, services, pricing, payouts, reviews, ads
- **Customer** — places orders (existing app, untouched)
- **Admin** — approves partners, can seed demo data and send test orders to partners

## Future / Backlog
- WebSockets instead of polling for instant ringing
- Real bank verification + Razorpay/Stripe Connect payout integration
- Multi-shop support per partner user
- Multi-language (Hindi / regional)
- Push notifications (FCM/APNs)
- Detailed funnel analytics with cohort retention

## Next Action Items
- Wire actual SMS gateway in place of mocked OTP for production
- Lock admin console behind admin role
- Add Razorpay/Stripe-based payout pipeline (replace mock UTR with real one)
