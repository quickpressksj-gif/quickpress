"""Socket.IO server attached to the FastAPI app for realtime partner events.

Channels (events emitted by the server, listened by clients):
- partner:{partner_id}      -> { type, order_id, status, order, at }
- support:{partner_id}      -> { ticket_id, message, at }
- settlement:{partner_id}   -> { settlement_id, amount, status, at }

Clients connect with an auth token (Bearer). The server resolves the partner_id
from the session and joins the connection to the matching room. Clients then
listen on events whose name is exactly the room id.
"""

from __future__ import annotations

import socketio

from core import db

sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False,
)


@sio.event
async def connect(sid, environ, auth):
    token = (auth or {}).get("token") if isinstance(auth, dict) else None
    if not token:
        # Allow connections without token but they can only listen to public rooms
        return True

    sess = await db.user_sessions.find_one({"session_token": token})
    if not sess:
        return False
    user_id = sess["user_id"]
    partner = await db.partners.find_one({"user_id": user_id}, {"_id": 0})
    if partner:
        room = f"partner:{partner['partner_id']}"
        await sio.enter_room(sid, room)
        await sio.save_session(sid, {"user_id": user_id, "partner_id": partner["partner_id"]})
        await sio.emit("connected", {"room": room}, to=sid)
    return True


@sio.event
async def disconnect(sid):
    pass


@sio.event
async def ping(sid):
    await sio.emit("pong", {}, to=sid)
