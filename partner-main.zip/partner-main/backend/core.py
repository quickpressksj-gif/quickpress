"""Core utilities, db client, and shared dependencies for QuickPress backend."""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv
from fastapi import HTTPException
from motor.motor_asyncio import AsyncIOMotorClient

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
db_name = os.environ.get("DB_NAME", "quickpress_db")
client = AsyncIOMotorClient(mongo_url)
db = client[db_name]

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("quickpress")

# ----------------------------------------------------------------- helpers


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str = "id") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def strip_mongo(doc: dict | None) -> dict | None:
    if doc is None:
        return None
    doc.pop("_id", None)
    return doc


def date_in_window(iso: str, days: int) -> bool:
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return (now_utc() - dt).days < days
    except Exception:
        return False


# ----------------------------------------------------------------- auth deps


async def get_user_from_token(authorization: str | None) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.replace("Bearer ", "", 1).strip()
    session = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if not session:
        raise HTTPException(status_code=401, detail="Invalid session")
    exp = session.get("expires_at")
    if isinstance(exp, datetime):
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp < now_utc():
            raise HTTPException(status_code=401, detail="Session expired")
    user = await db.users.find_one({"user_id": session["user_id"]}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


async def ensure_partner_for_user(user: dict) -> dict:
    """Idempotently create a partner record bound to user."""
    existing = await db.partners.find_one({"user_id": user["user_id"]}, {"_id": 0})
    if existing:
        return existing
    partner = {
        "partner_id": new_id("ptr"),
        "user_id": user["user_id"],
        "name": user.get("name") or "My Store",
        "image": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=800",
        "logo": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=200",
        "rating": 4.5,
        "reviews": 0,
        "distance_km": 1.0,
        "eta": "60 min",
        "min_price": 49,
        "sponsored": False,
        "is_open": False,
        "address": "Add your shop address",
        "about": "Welcome to my store on QuickPress!",
        "gallery": [
            "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=800",
        ],
        "working_hours": "9:00 AM – 9:00 PM",
        "categories": ["laundry"],
        "status": "Approved",
        "auto_accept": False,
        "auto_assign_rider": False,
        "holiday_mode": False,
        "max_orders_per_day": 50,
        "max_active_orders": 10,
        "created_at": now_utc().isoformat(),
    }
    await db.partners.insert_one(dict(partner))
    return partner


async def get_partner_for_user(authorization: str | None) -> dict:
    user = await get_user_from_token(authorization)
    p = await db.partners.find_one({"user_id": user["user_id"]}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="No partner application found. Please apply first.")
    return p


# ----------------------------------------------------------------- pipelines

CUSTOMER_PIPELINE = [
    "Order Created",
    "Partner Assigned",
    "Rider Assigned",
    "Pickup Scheduled",
    "Picked Up",
    "Processing",
    "Ready",
    "Out For Delivery",
    "Delivered",
]
