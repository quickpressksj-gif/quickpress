"""Admin routes: seed demo data + partner approval workflow."""

from __future__ import annotations

import random
from datetime import timedelta

from fastapi import APIRouter, HTTPException

from core import db, new_id, now_utc, strip_mongo
from models import PartnerApprovalIn

router = APIRouter(tags=["admin"])


# ---------------------------------------------------------------- partner approval


@router.get("/admin/partners")
async def admin_list_partners(status: str | None = None):
    """List partners (optionally filtered by status: Pending/Approved/Rejected)."""
    query = {"status": status} if status else {}
    rows = (
        await db.partners.find(query, {"_id": 0})
        .sort("applied_at", -1)
        .to_list(500)
    )
    # attach doc counts and owner info
    for r in rows:
        r["documents_count"] = await db.partner_documents.count_documents(
            {"partner_id": r["partner_id"]}
        )
    return {"items": rows}


@router.get("/admin/partners/{partner_id}")
async def admin_get_partner(partner_id: str):
    p = await db.partners.find_one({"partner_id": partner_id}, {"_id": 0})
    if not p:
        return {"partner": None}
    docs = await db.partner_documents.find(
        {"partner_id": partner_id}, {"_id": 0}
    ).to_list(50)
    return {"partner": p, "documents": docs}


@router.post("/admin/partners/{partner_id}/approve")
async def admin_approve_partner(partner_id: str, body: PartnerApprovalIn | None = None):
    p = await db.partners.find_one({"partner_id": partner_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Partner not found")
    await db.partners.update_one(
        {"partner_id": partner_id},
        {
            "$set": {
                "status": "Approved",
                "approved_at": now_utc().isoformat(),
                "rejection_reason": None,
            }
        },
    )
    # notify partner user
    if p.get("user_id"):
        await db.notifications.insert_one(
            {
                "notif_id": new_id("ntf"),
                "user_id": p["user_id"],
                "audience": "partner",
                "title": "Application approved",
                "body": f"Your store '{p.get('name','')}' has been approved. Go online to receive orders!",
                "type": "system",
                "read": False,
                "created_at": now_utc().isoformat(),
            }
        )
    return {"ok": True, "status": "Approved"}


@router.post("/admin/partners/{partner_id}/reject")
async def admin_reject_partner(partner_id: str, body: PartnerApprovalIn):
    p = await db.partners.find_one({"partner_id": partner_id}, {"_id": 0})
    if not p:
        return {"ok": False, "msg": "Partner not found"}
    await db.partners.update_one(
        {"partner_id": partner_id},
        {
            "$set": {
                "status": "Rejected",
                "rejection_reason": body.reason or "Application did not meet requirements.",
                "rejected_at": now_utc().isoformat(),
            }
        },
    )
    if p.get("user_id"):
        await db.notifications.insert_one(
            {
                "notif_id": new_id("ntf"),
                "user_id": p["user_id"],
                "audience": "partner",
                "title": "Application rejected",
                "body": body.reason or "Your application was rejected. Please re-apply with correct details.",
                "type": "system",
                "read": False,
                "created_at": now_utc().isoformat(),
            }
        )
    return {"ok": True, "status": "Rejected"}


# ---------------------------------------------------------------- admin: seed demo for partner


@router.post("/admin/partners/{partner_id}/seed-demo")
async def admin_seed_partner_demo(partner_id: str):
    """Populate orders/settlements/reviews/payouts for a partner (admin-only)."""
    from routes.partner import _seed_partner_demo

    res = await _seed_partner_demo(partner_id)
    if not res.get("ok"):
        raise HTTPException(status_code=404, detail=res.get("msg", "Failed"))
    return res


@router.post("/admin/partners/{partner_id}/spawn-order")
async def admin_spawn_new_order(partner_id: str):
    """Inject a fresh NEW order for testing the live-order alert / Zomato bell.

    Real customers create orders via /api/orders. This endpoint mimics that for
    demo/QA purposes.
    """
    p = await db.partners.find_one({"partner_id": partner_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Partner not found")

    demo_users = [
        ("Ananya Verma", "9911000011"),
        ("Karan Kapoor", "9911000022"),
        ("Sneha Reddy", "9911000033"),
        ("Vikram Singh", "9911000044"),
        ("Meera Joshi", "9911000055"),
    ]
    uname, uphone = random.choice(demo_users)
    uid = new_id("usr")
    await db.users.update_one(
        {"phone": uphone},
        {"$setOnInsert": {"user_id": uid, "name": uname, "phone": uphone, "role": "customer"}},
        upsert=True,
    )
    real_user = await db.users.find_one({"phone": uphone}, {"_id": 0})
    uid = real_user["user_id"]

    items = random.choice([
        [{"service_id": "s1", "name": "Wash & Fold", "price": 49, "qty": 3}],
        [{"service_id": "s2", "name": "Shirt Dry Clean", "price": 99, "qty": 4},
         {"service_id": "s3", "name": "Ironing", "price": 9, "qty": 5}],
        [{"service_id": "s4", "name": "Premium Wash", "price": 199, "qty": 2},
         {"service_id": "s5", "name": "Bedsheet", "price": 79, "qty": 1}],
    ])
    subtotal = sum(it["price"] * it["qty"] for it in items)
    delivery_fee = 29
    total = subtotal + delivery_fee
    addresses = [
        {"label": "Home", "line1": "B-204, Greenview Apartments", "city": p.get("city","Noida"), "pincode": p.get("pincode","201301")},
        {"label": "Work", "line1": "5th Floor, Tower 2", "city": p.get("city","Noida"), "pincode": p.get("pincode","201301")},
    ]
    created = now_utc().isoformat()
    order = {
        "order_id": new_id("ord"),
        "user_id": uid,
        "user_name": uname,
        "user_phone": uphone,
        "partner_id": partner_id,
        "partner_name": p["name"],
        "partner_image": p.get("image"),
        "items": items,
        "address": random.choice(addresses),
        "pickup_date": "Today",
        "pickup_slot": "Within 30 min",
        "payment_method": random.choice(["UPI", "COD", "CARD"]),
        "subtotal": subtotal,
        "delivery_fee": delivery_fee,
        "discount": 0,
        "wallet_used": 0,
        "total": total,
        "status": "Order Created",
        "timeline": [{"status": "Order Created", "at": created}],
        "eta_minutes": 45,
        "created_at": created,
    }
    await db.orders.insert_one(dict(order))
    # Emit realtime event so the partner app rings without waiting for polling
    try:
        from socket_app import sio
        await sio.emit(
            f"partner:{partner_id}",
            {
                "type": "NEW_ORDER",
                "order_id": order["order_id"],
                "status": order["status"],
                "order": order,
                "at": created,
            },
        )
    except Exception:
        pass
    return {"ok": True, "order_id": order["order_id"], "total": total, "customer": uname}


@router.post("/admin/seed")
async def seed_db():
    """Idempotently populate customer-side demo content."""
    if await db.partners.count_documents({}) > 0:
        return {"ok": True, "msg": "already seeded"}

    categories = [
        {"slug": "laundry", "name": "Laundry", "icon": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=400", "color": "#F4B400"},
        {"slug": "dry-cleaning", "name": "Dry Cleaning", "icon": "https://images.unsplash.com/photo-1489274495757-95c7c837b101?w=400", "color": "#16A34A"},
        {"slug": "ironing", "name": "Ironing", "icon": "https://images.unsplash.com/photo-1489274495757-95c7c837b101?w=400", "color": "#3B82F6"},
        {"slug": "premium-laundry", "name": "Premium Laundry", "icon": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=400", "color": "#A855F7"},
        {"slug": "express", "name": "Express", "icon": "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=400", "color": "#EF4444"},
        {"slug": "shoe-cleaning", "name": "Shoe Cleaning", "icon": "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=400", "color": "#06B6D4"},
        {"slug": "carpet-cleaning", "name": "Carpet", "icon": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=400", "color": "#F59E0B"},
        {"slug": "curtain-cleaning", "name": "Curtain", "icon": "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=400", "color": "#10B981"},
        {"slug": "blanket-cleaning", "name": "Blanket", "icon": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=400", "color": "#8B5CF6"},
    ]
    await db.categories.insert_many([dict(c) for c in categories])

    banners = [
        {"banner_id": new_id("bnr"), "title": "Flat 50% Off", "subtitle": "On first order. Code: FRESH50", "image": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=1200", "cta": "Order Now"},
        {"banner_id": new_id("bnr"), "title": "QuickPress Plus", "subtitle": "Free pickup & delivery", "image": "https://images.unsplash.com/photo-1545873509-33e944ca7655?w=1200", "cta": "Join Plus"},
        {"banner_id": new_id("bnr"), "title": "Express in 6 Hours", "subtitle": "Fresh clothes, super fast", "image": "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=1200", "cta": "Try Express"},
    ]
    await db.banners.insert_many([dict(b) for b in banners])

    partner_blueprints = [
        {"name": "FreshFold Premium", "image": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=800", "logo": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=200", "rating": 4.8, "reviews": 1287, "distance_km": 0.9, "eta": "60 min", "min_price": 49, "sponsored": True, "categories": ["laundry", "premium-laundry"]},
        {"name": "Sparkle Dry Clean", "image": "https://images.unsplash.com/photo-1489274495757-95c7c837b101?w=800", "logo": "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=200", "rating": 4.7, "reviews": 932, "distance_km": 1.4, "eta": "75 min", "min_price": 99, "sponsored": False, "categories": ["dry-cleaning", "premium-laundry"]},
        {"name": "Iron King", "image": "https://images.unsplash.com/photo-1489274495757-95c7c837b101?w=800", "logo": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=200", "rating": 4.6, "reviews": 654, "distance_km": 2.1, "eta": "50 min", "min_price": 9, "sponsored": False, "categories": ["ironing"]},
        {"name": "ShoeSpa", "image": "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800", "logo": "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=200", "rating": 4.9, "reviews": 412, "distance_km": 3.2, "eta": "120 min", "min_price": 199, "sponsored": True, "categories": ["shoe-cleaning"]},
        {"name": "Express Wash Co", "image": "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=800", "logo": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=200", "rating": 4.5, "reviews": 2104, "distance_km": 1.1, "eta": "30 min", "min_price": 79, "sponsored": False, "categories": ["express", "laundry"]},
        {"name": "Royal Carpet Care", "image": "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=800", "logo": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=200", "rating": 4.7, "reviews": 287, "distance_km": 4.0, "eta": "180 min", "min_price": 299, "sponsored": False, "categories": ["carpet-cleaning", "curtain-cleaning", "blanket-cleaning"]},
    ]

    partners = []
    for p in partner_blueprints:
        partners.append(
            {
                "partner_id": new_id("ptr"),
                "is_open": True,
                "address": "Sector 18, Noida",
                "about": "We use eco-friendly detergents and ISO-certified processes. Your clothes are in safe hands.",
                "gallery": [
                    "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=800",
                    "https://images.unsplash.com/photo-1632923565835-6582b54f2105?w=800",
                    "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=800",
                ],
                "working_hours": "8:00 AM – 10:00 PM",
                **p,
            }
        )
    await db.partners.insert_many([dict(p) for p in partners])

    service_templates = {
        "laundry": [("Wash & Fold (per kg)", 49), ("Wash & Iron (per kg)", 79), ("Bedsheet wash", 99)],
        "dry-cleaning": [("Shirt", 99), ("Trouser", 129), ("Suit (2pc)", 399), ("Saree", 299)],
        "ironing": [("Shirt", 9), ("Trouser", 12), ("Kurta", 15)],
        "premium-laundry": [("Premium Wash (per kg)", 149), ("Silk Garment", 249)],
        "express": [("Express Wash & Fold (per kg)", 99), ("Express Iron (per piece)", 19)],
        "shoe-cleaning": [("Sneaker Deep Clean", 299), ("Leather Shoe Polish", 199)],
        "carpet-cleaning": [("Carpet (sqft)", 19)],
        "curtain-cleaning": [("Curtain (per panel)", 99)],
        "blanket-cleaning": [("Blanket Single", 149), ("Blanket Double", 249)],
    }
    services = []
    for p in partners:
        for cat in p["categories"]:
            for name, price in service_templates.get(cat, []):
                services.append(
                    {
                        "service_id": new_id("srv"),
                        "partner_id": p["partner_id"],
                        "category": cat,
                        "name": name,
                        "price": price,
                        "unit": "kg" if "kg" in name else "piece",
                        "image": p["image"],
                    }
                )
    await db.services.insert_many([dict(s) for s in services])

    coupons = [
        {"code": "FRESH50", "title": "50% off first order", "subtitle": "Up to ₹150", "type": "percent", "value": 50, "expires": "2026-12-31"},
        {"code": "WELCOME100", "title": "Flat ₹100 off", "subtitle": "On orders above ₹399", "type": "flat", "value": 100, "expires": "2026-12-31"},
        {"code": "EXPRESS25", "title": "25% off Express", "subtitle": "Express orders only", "type": "percent", "value": 25, "expires": "2026-12-31"},
    ]
    await db.coupons.insert_many([dict(c) for c in coupons])

    ads = [
        {"ad_id": new_id("ad"), "placement": "home_recommended", "title": "FreshFold Premium", "image": "https://images.unsplash.com/photo-1778731660255-215c9172e18d?w=600", "partner_id": partners[0]["partner_id"]},
        {"ad_id": new_id("ad"), "placement": "search_boost", "title": "Sparkle Dry Clean", "image": "https://images.unsplash.com/photo-1489274495757-95c7c837b101?w=600", "partner_id": partners[1]["partner_id"]},
    ]
    await db.ads.insert_many([dict(a) for a in ads])

    return {"ok": True, "seeded": {"partners": len(partners), "services": len(services), "categories": len(categories)}}
