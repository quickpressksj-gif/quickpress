"""Iteration-2 tests for QuickPress Partner App.

Covers the new endpoints introduced in iteration 2:
- POST /api/partner/demo-seed is DEPRECATED (returns 403)
- POST /api/admin/partners/{id}/seed-demo (admin demo seed, idempotent)
- POST /api/admin/partners/{id}/spawn-order (admin spawns new order)
- PATCH /api/partner/bank (bank details persistence)
- GET  /api/partner/payouts/cycle?range=current|last (Zomato-style breakdown)
- GET  /api/partner/orders/poll[?since=...] (live new-order polling)
"""

from __future__ import annotations

import os
import random

import pytest
import requests
from dotenv import load_dotenv

load_dotenv("/app/frontend/.env")
BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"


def _phone() -> str:
    return "99999" + str(random.randint(10000, 99999))


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _login(session, phone=None):
    phone = phone or _phone()
    r = session.post(f"{API}/auth/otp/send", json={"phone": phone})
    assert r.status_code == 200, r.text
    otp = r.json()["otp"]
    r = session.post(
        f"{API}/auth/otp/verify",
        json={"phone": phone, "otp": otp, "role": "partner"},
    )
    assert r.status_code == 200, r.text
    return phone, r.json()["token"]


@pytest.fixture(scope="module")
def approved_partner(session):
    phone, token = _login(session)
    h = {"Authorization": f"Bearer {token}"}
    payload = {
        "owner_name": "TEST V2 Owner",
        "phone": phone,
        "name": "TEST V2 Shop",
        "address": "Sector 22",
        "city": "Noida",
        "pincode": "201301",
        "categories": ["laundry"],
        "documents": [],
    }
    r = session.post(f"{API}/partner/apply", json=payload, headers=h)
    assert r.status_code == 200, r.text
    pid = r.json()["partner_id"]
    r = session.post(f"{API}/admin/partners/{pid}/approve")
    assert r.status_code == 200
    return {"token": token, "partner_id": pid, "headers": h, "phone": phone}


# ---------------------------------------------------- DEPRECATED endpoint
class TestDeprecatedPartnerDemoSeed:
    def test_partner_demo_seed_is_403(self, session, approved_partner):
        r = session.post(f"{API}/partner/demo-seed", headers=approved_partner["headers"])
        assert r.status_code == 403, r.text
        # Body should explain admin-only
        assert "admin" in r.text.lower()


# ---------------------------------------------------- ADMIN seed-demo
class TestAdminSeedDemo:
    def test_admin_seed_populates_data(self, session, approved_partner):
        pid = approved_partner["partner_id"]
        r = session.post(f"{API}/admin/partners/{pid}/seed-demo")
        assert r.status_code == 200, r.text
        body = r.json()
        assert body.get("ok") is True

        # Validate persistence: orders + services exist
        h = approved_partner["headers"]
        orders = session.get(f"{API}/partner/orders", headers=h).json()["items"]
        assert len(orders) > 0
        services = session.get(f"{API}/partner/services", headers=h).json()["items"]
        assert len(services) > 0
        settlements = session.get(f"{API}/partner/settlements", headers=h).json().get("items", [])
        assert isinstance(settlements, list)
        reviews = session.get(f"{API}/partner/reviews", headers=h).json().get("items", [])
        assert isinstance(reviews, list)

    def test_admin_seed_idempotent(self, session, approved_partner):
        pid = approved_partner["partner_id"]
        # First call already ran in previous test, second should still be ok
        r = session.post(f"{API}/admin/partners/{pid}/seed-demo")
        assert r.status_code == 200
        assert r.json().get("ok") is True

    def test_admin_seed_unknown_partner_404(self, session):
        r = session.post(f"{API}/admin/partners/ptr_doesnotexist/seed-demo")
        assert r.status_code == 404


# ---------------------------------------------------- ADMIN spawn-order
class TestAdminSpawnOrder:
    def test_spawn_creates_new_order_created(self, session, approved_partner):
        pid = approved_partner["partner_id"]
        h = approved_partner["headers"]
        # Snapshot existing orders
        before_ids = {
            o["order_id"]
            for o in session.get(f"{API}/partner/orders", headers=h).json()["items"]
        }
        r = session.post(f"{API}/admin/partners/{pid}/spawn-order")
        assert r.status_code == 200, r.text
        body = r.json()
        assert body.get("ok") is True
        oid = body.get("order_id")
        assert oid and isinstance(oid, str)
        assert body.get("customer")
        assert isinstance(body.get("total"), (int, float))

        # Verify it shows up in partner orders
        after = session.get(f"{API}/partner/orders", headers=h).json()["items"]
        after_ids = {o["order_id"] for o in after}
        assert oid in after_ids
        assert oid not in before_ids

        # It must appear in /poll as well
        poll = session.get(f"{API}/partner/orders/poll", headers=h).json()
        assert "now" in poll
        assert any(o["order_id"] == oid for o in poll["items"])

    def test_spawn_unknown_partner_404(self, session):
        r = session.post(f"{API}/admin/partners/ptr_doesnotexist/spawn-order")
        assert r.status_code == 404


# ---------------------------------------------------- BANK PATCH
class TestPartnerBank:
    def test_patch_bank_persists(self, session, approved_partner):
        h = approved_partner["headers"]
        payload = {
            "account_number": "1234567890",
            "ifsc": "SBIN0001234",
            "bank_name": "State Bank of India",
            "account_holder": "TEST Holder",
            "upi_id": "test@upi",
        }
        r = session.patch(f"{API}/partner/bank", json=payload, headers=h)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

        # Verify via /partner/me
        me = session.get(f"{API}/partner/me", headers=h).json()["partner"]
        assert me.get("account_number") == "1234567890"
        assert me.get("ifsc") == "SBIN0001234"
        assert me.get("bank_name") == "State Bank of India"
        assert me.get("account_holder") == "TEST Holder"
        assert me.get("upi_id") == "test@upi"

    def test_patch_bank_rejects_empty(self, session, approved_partner):
        r = session.patch(
            f"{API}/partner/bank", json={"unrelated": "x"}, headers=approved_partner["headers"]
        )
        assert r.status_code == 400


# ---------------------------------------------------- PAYOUT CYCLE
class TestPayoutCycle:
    @staticmethod
    def _assert_shape(body: dict):
        for k in ("cycle_label", "payout_date", "net_payout", "total_orders", "breakdown", "bank", "settlements"):
            assert k in body, f"missing key {k}: {body.keys()}"
        bd = body["breakdown"]
        for k in (
            "A_net_order_value",
            "B_additions",
            "C_order_deductions",
            "D_tax_deductions",
            "E_investments",
            "F_hyperpure",
            "est_payout",
        ):
            assert k in bd, f"missing breakdown {k}: {bd.keys()}"
        for k in ("utr", "account_number", "ifsc", "bank_name"):
            assert k in body["bank"]
        assert isinstance(body["settlements"], list)

    def test_cycle_current(self, session, approved_partner):
        r = session.get(
            f"{API}/partner/payouts/cycle?range=current", headers=approved_partner["headers"]
        )
        assert r.status_code == 200, r.text
        self._assert_shape(r.json())

    def test_cycle_last(self, session, approved_partner):
        r = session.get(
            f"{API}/partner/payouts/cycle?range=last", headers=approved_partner["headers"]
        )
        assert r.status_code == 200, r.text
        body = r.json()
        self._assert_shape(body)
        # 'last' should label as Settled
        assert body["payout_date"].lower() == "settled" or body["payout_date"]


# ---------------------------------------------------- ORDERS POLL
class TestOrdersPoll:
    def test_poll_returns_now_and_items(self, session, approved_partner):
        r = session.get(f"{API}/partner/orders/poll", headers=approved_partner["headers"])
        assert r.status_code == 200, r.text
        body = r.json()
        assert "now" in body and isinstance(body["now"], str)
        assert "items" in body and isinstance(body["items"], list)
        for o in body["items"]:
            assert o["status"] == "Order Created"

    def test_poll_with_since_filters(self, session, approved_partner):
        # since=now should yield no items because spawn-order earlier may pre-date "now"
        future = "2099-01-01T00:00:00"
        r = session.get(
            f"{API}/partner/orders/poll?since={future}", headers=approved_partner["headers"]
        )
        assert r.status_code == 200
        assert r.json()["items"] == []
