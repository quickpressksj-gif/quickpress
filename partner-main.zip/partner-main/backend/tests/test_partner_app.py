"""End-to-end backend tests for QuickPress Partner App.

Covers: OTP auth, partner apply flow, admin approve/reject,
existing partner endpoints (services/pricing/orders/earnings/
settlements/payouts/reviews/ads/marketing/reports/support),
order pipeline, notifications side-effect, and customer endpoints.
"""

from __future__ import annotations

import os
import random
import time

import pytest
import requests
from dotenv import load_dotenv

load_dotenv("/app/frontend/.env")
BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"


def _phone() -> str:
    # Unique phone per test run
    return "99999" + str(random.randint(10000, 99999))


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _login(session, role="partner", phone=None):
    phone = phone or _phone()
    r = session.post(f"{API}/auth/otp/send", json={"phone": phone})
    assert r.status_code == 200, r.text
    otp = r.json()["otp"]
    r = session.post(
        f"{API}/auth/otp/verify",
        json={"phone": phone, "otp": otp, "role": role},
    )
    assert r.status_code == 200, r.text
    data = r.json()
    return phone, data["token"], data["user"]


# -------------------------------------------------- AUTH
class TestAuth:
    def test_otp_send_returns_otp(self, session):
        r = session.post(f"{API}/auth/otp/send", json={"phone": _phone()})
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert len(body["otp"]) == 4

    def test_otp_verify_partner_returns_token(self, session):
        phone, token, user = _login(session)
        assert isinstance(token, str) and len(token) > 10
        assert user["role"] == "partner"
        assert user["phone"] == phone

    def test_otp_verify_invalid_otp(self, session):
        phone = _phone()
        session.post(f"{API}/auth/otp/send", json={"phone": phone})
        r = session.post(
            f"{API}/auth/otp/verify",
            json={"phone": phone, "otp": "0000", "role": "partner"},
        )
        # Token system uses 4-digit numeric; "0000" might collide accidentally,
        # but probability ~1/10000. Accept either invalid (400) or success.
        assert r.status_code in (200, 400)

    def test_auth_me(self, session):
        _, token, _ = _login(session)
        r = session.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "partner"


# -------------------------------------------------- APPLY + ADMIN APPROVE
class TestApplyAndApprove:
    def test_full_apply_approve_flow(self, session):
        phone, token, user = _login(session)
        h = {"Authorization": f"Bearer {token}"}

        # No application yet
        r = session.get(f"{API}/partner/application-status", headers=h)
        assert r.status_code == 200
        assert r.json()["has_application"] is False

        # me() should fail with 404
        r = session.get(f"{API}/partner/me", headers=h)
        assert r.status_code == 404

        # Apply
        payload = {
            "owner_name": "TEST Owner",
            "phone": phone,
            "email": "test@example.com",
            "name": "TEST Laundry Shop",
            "address": "Sector 10",
            "city": "Noida",
            "pincode": "201301",
            "categories": ["laundry"],
            "gst_number": "22AAAAA0000A1Z5",
            "pan_number": "ABCDE1234F",
            "documents": [
                {"doc_type": "gst", "number": "22AAAAA0000A1Z5"},
                {"doc_type": "pan", "number": "ABCDE1234F"},
            ],
        }
        r = session.post(f"{API}/partner/apply", json=payload, headers=h)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["status"] == "Pending"
        partner_id = body["partner_id"]

        # application-status returns Pending
        r = session.get(f"{API}/partner/application-status", headers=h)
        assert r.status_code == 200
        s = r.json()
        assert s["has_application"] is True
        assert s["status"] == "Pending"

        # Admin listing should include this partner
        r = session.get(f"{API}/admin/partners?status=Pending")
        assert r.status_code == 200
        ids = [p["partner_id"] for p in r.json()["items"]]
        assert partner_id in ids

        # Admin: get single
        r = session.get(f"{API}/admin/partners/{partner_id}")
        assert r.status_code == 200
        assert r.json()["partner"]["partner_id"] == partner_id

        # Admin: approve
        r = session.post(f"{API}/admin/partners/{partner_id}/approve")
        assert r.status_code == 200
        assert r.json()["status"] == "Approved"

        # /partner/me now succeeds
        r = session.get(f"{API}/partner/me", headers=h)
        assert r.status_code == 200
        assert r.json()["partner"]["status"] == "Approved"

        # /partner/dashboard works
        r = session.get(f"{API}/partner/dashboard", headers=h)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "Approved"
        assert d["is_open"] is False

        # Notifications side-effect
        r = session.get(f"{API}/partner/notifications", headers=h)
        assert r.status_code == 200
        items = r.json()["items"]
        assert any(n.get("audience") == "partner" for n in items)
        assert any("approved" in (n.get("title", "").lower()) for n in items)

    def test_admin_reject_then_reapply(self, session):
        phone, token, _ = _login(session)
        h = {"Authorization": f"Bearer {token}"}
        payload = {
            "owner_name": "TEST Reject",
            "phone": phone,
            "name": "TEST Reject Shop",
            "address": "Sector 5",
            "city": "Noida",
            "pincode": "201301",
            "categories": ["laundry"],
            "documents": [],
        }
        r = session.post(f"{API}/partner/apply", json=payload, headers=h)
        assert r.status_code == 200
        partner_id = r.json()["partner_id"]

        # Reject
        r = session.post(
            f"{API}/admin/partners/{partner_id}/reject",
            json={"reason": "Missing documents"},
        )
        assert r.status_code == 200
        assert r.json()["status"] == "Rejected"

        # status-> rejected with reason
        r = session.get(f"{API}/partner/application-status", headers=h)
        s = r.json()
        assert s["status"] == "Rejected"
        assert s["rejection_reason"] == "Missing documents"

        # Reapply moves back to Pending
        r = session.post(f"{API}/partner/apply", json=payload, headers=h)
        assert r.status_code == 200
        assert r.json()["status"] == "Pending"

        # Notifications include reject
        r = session.get(f"{API}/partner/notifications", headers=h)
        assert any("reject" in n.get("title", "").lower() for n in r.json()["items"])


# -------------------------------------------------- APPROVED PARTNER ENDPOINTS
@pytest.fixture(scope="module")
def approved_partner(session):
    phone, token, _ = _login(session)
    h = {"Authorization": f"Bearer {token}"}
    payload = {
        "owner_name": "TEST Approved",
        "phone": phone,
        "name": "TEST Approved Shop",
        "address": "Sector 1",
        "city": "Noida",
        "pincode": "201301",
        "categories": ["laundry"],
        "documents": [],
    }
    r = session.post(f"{API}/partner/apply", json=payload, headers=h)
    partner_id = r.json()["partner_id"]
    session.post(f"{API}/admin/partners/{partner_id}/approve")
    return {"token": token, "partner_id": partner_id, "headers": h, "phone": phone}


class TestPartnerEndpoints:
    def test_services_crud(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.get(f"{API}/partner/services", headers=h)
        assert r.status_code == 200

        r = session.post(
            f"{API}/partner/services",
            json={"name": "TEST_Service", "category": "laundry", "price": 99, "unit": "kg"},
            headers=h,
        )
        assert r.status_code == 200
        sid = r.json()["service_id"]

        r = session.get(f"{API}/partner/services", headers=h)
        assert sid in [s["service_id"] for s in r.json()["items"]]

    def test_pricing(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.get(f"{API}/partner/pricing", headers=h)
        assert r.status_code == 200
        assert "laundry_price" in r.json()

        r = session.patch(
            f"{API}/partner/pricing",
            json={"laundry_price": 79, "dry_cleaning_price": 149},
            headers=h,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["laundry_price"] == 79
        assert body["dry_cleaning_price"] == 149

        # Persistence
        r = session.get(f"{API}/partner/pricing", headers=h)
        assert r.json()["laundry_price"] == 79

    def test_status_toggle(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.post(f"{API}/partner/status", json={"is_open": True}, headers=h)
        assert r.status_code == 200
        assert r.json()["is_open"] is True

        r = session.get(f"{API}/partner/me", headers=h)
        assert r.json()["partner"]["is_open"] is True

    def test_demo_seed_idempotent_and_order_pipeline(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        # Partner endpoint is now deprecated (403). Use admin-only seed.
        r = session.post(f"{API}/admin/partners/{pid}/seed-demo")
        assert r.status_code == 200

        # Second call should be idempotent
        r = session.post(f"{API}/admin/partners/{pid}/seed-demo")
        assert r.status_code == 200

        r = session.get(f"{API}/partner/orders", headers=h)
        assert r.status_code == 200
        orders = r.json()["items"]
        assert len(orders) > 0

        # Find an "Order Created" order to accept
        new_orders = [o for o in orders if o.get("status") == "Order Created"]
        assert new_orders, "No new orders seeded"
        oid = new_orders[0]["order_id"]

        r = session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        assert r.status_code == 200
        assert r.json()["status"] == "Partner Assigned"

        # Progress through pipeline
        for step, expected in [
            ("start-processing", "Processing"),
            ("ready", "Ready"),
            ("out-for-delivery", "Out For Delivery"),
            ("complete", "Delivered"),
        ]:
            r = session.post(f"{API}/partner/orders/{oid}/{step}", headers=h)
            assert r.status_code == 200, f"{step}: {r.text}"
            assert r.json()["status"] == expected

    def test_earnings_settlements_payouts(self, session, approved_partner):
        h = approved_partner["headers"]
        assert session.get(f"{API}/partner/earnings", headers=h).status_code == 200
        assert session.get(f"{API}/partner/settlements", headers=h).status_code == 200
        assert session.get(f"{API}/partner/payouts", headers=h).status_code == 200

        r = session.post(
            f"{API}/partner/payouts/request", json={"amount": 100.0}, headers=h
        )
        assert r.status_code == 200
        assert r.json()["amount"] == 100.0
        assert r.json()["status"] == "Pending"

    def test_reviews(self, session, approved_partner):
        r = session.get(f"{API}/partner/reviews", headers=approved_partner["headers"])
        assert r.status_code == 200
        assert "items" in r.json()

    def test_ads_create_list(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.get(f"{API}/partner/ads", headers=h)
        assert r.status_code == 200

        r = session.post(
            f"{API}/partner/ads",
            json={
                "name": "TEST_Ad",
                "campaign_type": "boost",
                "budget": 500,
                "daily_budget": 100,
                "start_date": "2026-01-01",
                "end_date": "2026-01-30",
                "target_city": "Noida",
            },
            headers=h,
        )
        assert r.status_code == 200, r.text
        assert r.json()["name"] == "TEST_Ad"

    def test_marketing_offer(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.post(
            f"{API}/partner/marketing",
            json={
                "title": "TEST 20% off",
                "code": "test20",
                "discount_pct": 20,
                "valid_till": "2026-12-31",
            },
            headers=h,
        )
        assert r.status_code == 200
        assert r.json()["code"] == "TEST20"

        r = session.get(f"{API}/partner/marketing", headers=h)
        assert r.status_code == 200
        assert any(o["title"] == "TEST 20% off" for o in r.json()["items"])

    def test_reports(self, session, approved_partner):
        for period in ("daily", "weekly", "monthly"):
            r = session.get(
                f"{API}/partner/reports?period={period}",
                headers=approved_partner["headers"],
            )
            assert r.status_code == 200
            assert r.json()["period"] == period

    def test_support_ticket(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.post(
            f"{API}/partner/support",
            json={"subject": "TEST issue", "message": "help me"},
            headers=h,
        )
        assert r.status_code == 200
        assert r.json()["subject"] == "TEST issue"

        r = session.get(f"{API}/partner/support", headers=h)
        assert any(t["subject"] == "TEST issue" for t in r.json()["items"])


# -------------------------------------------------- CUSTOMER REGRESSION
class TestCustomerSide:
    def test_admin_seed_idempotent(self, session):
        r = session.post(f"{API}/admin/seed")
        assert r.status_code == 200

    def test_categories(self, session):
        r = session.get(f"{API}/categories")
        assert r.status_code == 200
        assert isinstance(r.json().get("items", []), list)

    def test_partners_listing(self, session):
        r = session.get(f"{API}/partners")
        assert r.status_code == 200

    def test_services_listing(self, session):
        r = session.get(f"{API}/services")
        assert r.status_code == 200
