"""Iteration-3 tests for QuickPress Partner App.

Covers:
- Accept/Reject (new status names + audit logs)
- start-processing (state gating, audit, timestamp)
- complete-processing
- upload-images (categories, validation, append, audit)
- ready (image gating, status, timestamps, audit)
- /orders/{order_id} detail (order + audit_logs sorted asc by at)
- /audit-logs list
- /alerts aggregated
- orders tab filter mapping (accepted/processing/ready)
- /socket.io path exists
- Backwards compatibility (poll still works, /me, /dashboard, etc.)
"""

from __future__ import annotations

import os
import random
import time

import pytest
import requests
from dotenv import load_dotenv

load_dotenv("/app/frontend/.env")
BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

TINY_PNG = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


def _phone() -> str:
    return "98888" + str(random.randint(10000, 99999))


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _login(session, phone=None):
    phone = phone or _phone()
    r = session.post(f"{API}/auth/otp/send", json={"phone": phone})
    assert r.status_code == 200, r.text
    otp = r.json()["otp"]
    r = session.post(
        f"{API}/auth/otp/verify",
        json={"phone": phone, "otp": otp, "role": "partner"},
    )
    assert r.status_code == 200, r.text
    return phone, r.json()["token"]


@pytest.fixture(scope="module")
def approved_partner(session):
    phone, token = _login(session)
    h = {"Authorization": f"Bearer {token}"}
    payload = {
        "owner_name": "TEST V3 Owner",
        "phone": phone,
        "name": "TEST V3 Shop",
        "address": "Sector 22",
        "city": "Noida",
        "pincode": "201301",
        "categories": ["laundry"],
        "documents": [],
    }
    r = session.post(f"{API}/partner/apply", json=payload, headers=h)
    assert r.status_code == 200, r.text
    pid = r.json()["partner_id"]
    r = session.post(f"{API}/admin/partners/{pid}/approve")
    assert r.status_code == 200
    # Open
    session.post(f"{API}/partner/status", json={"is_open": True}, headers=h)
    return {"token": token, "partner_id": pid, "headers": h, "phone": phone}


def _spawn(session, pid):
    r = session.post(f"{API}/admin/partners/{pid}/spawn-order")
    assert r.status_code == 200, r.text
    return r.json()["order_id"]


# ------------------------------------------------ Accept / Reject
class TestAcceptReject:
    def test_accept_sets_new_status_and_audit(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)

        r = session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["status"] == "Accepted By Partner"
        assert body.get("accepted_at")

        # Audit log persisted
        r2 = session.get(f"{API}/partner/audit-logs?order_id={oid}", headers=h)
        assert r2.status_code == 200
        actions = [x["action"] for x in r2.json()["items"]]
        assert "ORDER_ACCEPTED" in actions

    def test_reject_sets_cancelled_and_audit(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)

        r = session.post(f"{API}/partner/orders/{oid}/reject", headers=h)
        assert r.status_code == 200, r.text

        # Verify order persistence
        det = session.get(f"{API}/partner/orders/{oid}", headers=h).json()
        o = det["order"]
        assert o["status"] == "Cancelled"
        assert o.get("rejected_by_partner") is True
        assert o.get("rejected_at")

        actions = [a["action"] for a in det["audit_logs"]]
        assert "ORDER_REJECTED" in actions


# ------------------------------------------------ Start / Complete processing
class TestProcessingFlow:
    def test_start_processing_requires_accepted(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)  # still Order Created

        r = session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        assert r.status_code == 400, r.text
        assert "accept" in r.text.lower()

    def test_start_processing_after_accept(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)

        assert session.post(f"{API}/partner/orders/{oid}/accept", headers=h).status_code == 200
        r = session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["status"] == "Processing Started"
        assert body.get("processing_started_at")

        # Audit
        det = session.get(f"{API}/partner/orders/{oid}", headers=h).json()
        actions = [a["action"] for a in det["audit_logs"]]
        assert "ORDER_ACCEPTED" in actions and "PROCESSING_STARTED" in actions

    def test_complete_processing(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        r = session.post(f"{API}/partner/orders/{oid}/complete-processing", headers=h)
        assert r.status_code == 200, r.text
        b = r.json()
        assert b["status"] == "Processing Completed"
        assert b.get("processing_completed_at")


# ------------------------------------------------ Image upload validation
class TestUploadImages:
    def test_invalid_category_400(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        r = session.post(
            f"{API}/partner/orders/{oid}/upload-images",
            json={"category": "nope", "images": [TINY_PNG]},
            headers=h,
        )
        assert r.status_code == 400

    def test_empty_images_400(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        r = session.post(
            f"{API}/partner/orders/{oid}/upload-images",
            json={"category": "before_processing", "images": []},
            headers=h,
        )
        assert r.status_code == 400

    def test_upload_appends_and_audit(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        # first batch (2)
        r = session.post(
            f"{API}/partner/orders/{oid}/upload-images",
            json={"category": "quality_check", "images": [TINY_PNG, TINY_PNG]},
            headers=h,
        )
        assert r.status_code == 200, r.text
        assert r.json()["count"] == 2
        assert r.json()["total_in_category"] == 2
        # second batch (1) -> total 3
        r = session.post(
            f"{API}/partner/orders/{oid}/upload-images",
            json={"category": "quality_check", "images": [TINY_PNG]},
            headers=h,
        )
        assert r.status_code == 200
        assert r.json()["total_in_category"] == 3

        det = session.get(f"{API}/partner/orders/{oid}", headers=h).json()
        assert len(det["order"].get("quality_check_images", [])) == 3
        actions = [a["action"] for a in det["audit_logs"]]
        assert actions.count("IMAGES_UPLOADED") == 2
        # Meta carries category + count
        meta_categories = [
            a["meta"].get("category") for a in det["audit_logs"] if a["action"] == "IMAGES_UPLOADED"
        ]
        assert all(c == "quality_check" for c in meta_categories)


# ------------------------------------------------ Ready For Pickup gating
class TestReadyForPickup:
    def _setup_processing(self, session, h, pid):
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        return oid

    def test_ready_blocked_without_images(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = self._setup_processing(session, h, pid)

        r = session.post(f"{API}/partner/orders/{oid}/ready", headers=h)
        assert r.status_code == 400, r.text
        body_text = r.text.lower()
        assert "quality_check" in body_text and "packed_clothes" in body_text

    def test_ready_blocked_with_partial(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = self._setup_processing(session, h, pid)

        # Only QC, no packed
        session.post(
            f"{API}/partner/orders/{oid}/upload-images",
            json={"category": "quality_check", "images": [TINY_PNG, TINY_PNG]},
            headers=h,
        )
        r = session.post(f"{API}/partner/orders/{oid}/ready", headers=h)
        assert r.status_code == 400
        assert "packed_clothes" in r.text.lower()

    def test_ready_success_with_min_images(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = self._setup_processing(session, h, pid)

        # Upload before/after/qc/packed
        for cat in ("before_processing", "after_processing", "quality_check", "packed_clothes"):
            session.post(
                f"{API}/partner/orders/{oid}/upload-images",
                json={"category": cat, "images": [TINY_PNG, TINY_PNG]},
                headers=h,
            )
        r = session.post(f"{API}/partner/orders/{oid}/ready", headers=h)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["status"] == "Ready For Pickup"
        assert body.get("ready_for_pickup_at")
        assert body.get("quality_check_passed") is True

        # Detail + audit logs sorted ascending by 'at'
        det = session.get(f"{API}/partner/orders/{oid}", headers=h).json()
        ats = [a["at"] for a in det["audit_logs"]]
        assert ats == sorted(ats), "audit_logs must be ascending by at"
        actions = [a["action"] for a in det["audit_logs"]]
        assert "READY_FOR_PICKUP" in actions


# ------------------------------------------------ Order detail / 404 / audit-logs
class TestOrderDetailAndAuditLogs:
    def test_unknown_order_404(self, session, approved_partner):
        r = session.get(f"{API}/partner/orders/ord_doesnotexist", headers=approved_partner["headers"])
        assert r.status_code == 404

    def test_audit_logs_filter_by_order_id(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)

        r = session.get(f"{API}/partner/audit-logs?order_id={oid}", headers=h)
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) >= 1
        assert all(x["order_id"] == oid for x in items)
        assert all(x["partner_id"] == pid for x in items)

    def test_audit_logs_global_with_limit(self, session, approved_partner):
        h = approved_partner["headers"]
        r = session.get(f"{API}/partner/audit-logs?limit=5", headers=h)
        assert r.status_code == 200
        items = r.json()["items"]
        assert isinstance(items, list)
        assert len(items) <= 5


# ------------------------------------------------ Alerts
class TestAlerts:
    def test_alerts_returns_items(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        # Ensure a new order exists
        _spawn(session, pid)
        r = session.get(f"{API}/partner/alerts", headers=h)
        assert r.status_code == 200
        body = r.json()
        items = body["items"]
        assert isinstance(items, list) and len(items) > 0
        kinds = {a["kind"] for a in items}
        # at least new_order should be present
        assert "new_order" in kinds
        for a in items:
            assert a["severity"] in {"high", "medium", "info"}
            assert "title" in a and "body" in a


# ------------------------------------------------ Tab filter mapping
class TestOrdersTabMapping:
    def test_accepted_tab_includes_new_label(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)

        r = session.get(f"{API}/partner/orders?tab=accepted", headers=h)
        assert r.status_code == 200
        ids = [o["order_id"] for o in r.json()["items"]]
        assert oid in ids

    def test_processing_tab(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        r = session.get(f"{API}/partner/orders?tab=processing", headers=h)
        ids = [o["order_id"] for o in r.json()["items"]]
        assert oid in ids

    def test_ready_tab(self, session, approved_partner):
        h = approved_partner["headers"]
        pid = approved_partner["partner_id"]
        oid = _spawn(session, pid)
        session.post(f"{API}/partner/orders/{oid}/accept", headers=h)
        session.post(f"{API}/partner/orders/{oid}/start-processing", headers=h)
        for cat in ("quality_check", "packed_clothes"):
            session.post(
                f"{API}/partner/orders/{oid}/upload-images",
                json={"category": cat, "images": [TINY_PNG, TINY_PNG]},
                headers=h,
            )
        session.post(f"{API}/partner/orders/{oid}/ready", headers=h)
        r = session.get(f"{API}/partner/orders?tab=ready", headers=h)
        ids = [o["order_id"] for o in r.json()["items"]]
        assert oid in ids


# ------------------------------------------------ Socket.IO mount
class TestSocketIO:
    def test_socketio_endpoint_exists(self, session):
        # Standard polling handshake URL
        r = session.get(f"{BASE_URL}/socket.io/?EIO=4&transport=polling", timeout=10)
        # Either 200 with engine.io payload, or 400 (missing sid) — both prove it's mounted.
        assert r.status_code in (200, 400), f"unexpected {r.status_code}: {r.text[:200]}"
        # If 200, must contain engine.io open packet
        if r.status_code == 200:
            assert r.text.startswith("0") or "sid" in r.text


# ------------------------------------------------ Backwards compat
class TestBackCompat:
    def test_me(self, session, approved_partner):
        r = session.get(f"{API}/partner/me", headers=approved_partner["headers"])
        assert r.status_code == 200 and r.json()["partner"]["partner_id"] == approved_partner["partner_id"]

    def test_dashboard(self, session, approved_partner):
        r = session.get(f"{API}/partner/dashboard", headers=approved_partner["headers"])
        assert r.status_code == 200
        for k in ("today_orders", "active_orders", "rating", "acceptance_rate"):
            assert k in r.json()

    def test_legacy_endpoints(self, session, approved_partner):
        h = approved_partner["headers"]
        for path in [
            "services", "pricing", "earnings", "settlements",
            "payouts", "payouts/cycle", "reviews", "ads",
            "marketing", "reports", "support", "notifications",
        ]:
            r = session.get(f"{API}/partner/{path}", headers=h)
            assert r.status_code == 200, f"{path} -> {r.status_code} {r.text[:200]}"

    def test_orders_poll_still_works(self, session, approved_partner):
        # Critical regression: /orders/{order_id} was added BEFORE /orders/poll in routes.
        r = session.get(f"{API}/partner/orders/poll", headers=approved_partner["headers"])
        assert r.status_code == 200, f"poll broken (route ordering?): {r.status_code} {r.text[:200]}"
        body = r.json()
        assert "now" in body and "items" in body
