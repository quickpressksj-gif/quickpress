"""All Pydantic models for QuickPress backend."""

from __future__ import annotations

from pydantic import BaseModel


# ---------------------------------------------------------------- auth


class OtpSendIn(BaseModel):
    phone: str


class OtpVerifyIn(BaseModel):
    phone: str
    otp: str
    name: str | None = None
    role: str = "customer"


class GoogleSessionIn(BaseModel):
    session_id: str
    role: str = "customer"


# ---------------------------------------------------------------- common


class AddressIn(BaseModel):
    label: str = "Home"
    line1: str
    line2: str | None = None
    city: str
    pincode: str
    lat: float | None = None
    lng: float | None = None


class CartItem(BaseModel):
    service_id: str
    name: str
    price: float
    qty: int


class OrderIn(BaseModel):
    partner_id: str
    items: list[CartItem]
    address: AddressIn
    pickup_date: str
    pickup_slot: str
    payment_method: str = "COD"
    coupon_code: str | None = None
    instructions: str | None = None
    use_wallet: bool = False


class StatusUpdateIn(BaseModel):
    status: str


class ReviewIn(BaseModel):
    rating: float
    comment: str | None = None


class WalletTopupIn(BaseModel):
    amount: float


# ---------------------------------------------------------------- partner


class PartnerStatusIn(BaseModel):
    is_open: bool


class PartnerStoreIn(BaseModel):
    name: str | None = None
    image: str | None = None
    logo: str | None = None
    address: str | None = None
    about: str | None = None
    working_hours: str | None = None
    categories: list[str] | None = None


class PartnerSettingsIn(BaseModel):
    auto_accept: bool | None = None
    auto_assign_rider: bool | None = None
    holiday_mode: bool | None = None
    max_orders_per_day: int | None = None
    max_active_orders: int | None = None


class PartnerServiceIn(BaseModel):
    name: str
    category: str
    price: float
    unit: str = "piece"
    enabled: bool = True


class PartnerPricingIn(BaseModel):
    laundry_price: float | None = None
    dry_cleaning_price: float | None = None
    ironing_price: float | None = None
    express_charges: float | None = None
    pickup_charges: float | None = None
    delivery_charges: float | None = None
    urgent_charges: float | None = None


class GalleryAddIn(BaseModel):
    url: str
    label: str = "Store"


class ReviewReplyIn(BaseModel):
    reply: str


class AdCampaignIn(BaseModel):
    name: str
    campaign_type: str
    budget: float
    daily_budget: float
    start_date: str
    end_date: str
    target_city: str | None = None
    target_area: str | None = None
    target_category: str | None = None


class OfferIn(BaseModel):
    title: str
    code: str
    discount_pct: float
    valid_till: str


class DocumentIn(BaseModel):
    doc_type: str
    number: str | None = None
    url: str | None = None


class PayoutRequestIn(BaseModel):
    amount: float



# ---------------------------------------------------------------- partner onboarding


class PartnerDocIn(BaseModel):
    doc_type: str
    number: str | None = None
    url: str | None = None


class PartnerApplyIn(BaseModel):
    # owner / shop basics
    owner_name: str
    phone: str
    email: str | None = None
    # shop
    name: str
    about: str | None = None
    address: str
    city: str
    pincode: str
    working_hours: str | None = None
    categories: list[str] = ["laundry"]
    image: str | None = None
    logo: str | None = None
    # KYC
    gst_number: str | None = None
    pan_number: str | None = None
    aadhaar_number: str | None = None
    documents: list[PartnerDocIn] = []


class PartnerApprovalIn(BaseModel):
    reason: str | None = None
