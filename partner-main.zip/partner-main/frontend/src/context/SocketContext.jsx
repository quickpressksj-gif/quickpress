import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import { io } from "socket.io-client";
import { getToken, API_BASE } from "@/api";
import { useAuth } from "@/context/AuthContext";

const SocketCtx = createContext({ socket: null, connected: false, lastEvent: null });

export const SocketProvider = ({ children }) => {
  const { user, appStatus } = useAuth();
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [lastEvent, setLastEvent] = useState(null);
  const [partnerRoom, setPartnerRoom] = useState(null);
  const handlersRef = useRef(new Set());

  useEffect(() => {
    if (!user || appStatus?.status !== "Approved") {
      if (socketRef.current) { socketRef.current.disconnect(); socketRef.current = null; setConnected(false); }
      return;
    }
    const token = getToken();
    if (!token) return;
    const origin = API_BASE.replace(/\/api\/?$/, "");
    const s = io(origin, {
      path: "/socket.io",
      transports: ["websocket", "polling"],
      auth: { token },
    });
    socketRef.current = s;

    s.on("connect", () => setConnected(true));
    s.on("disconnect", () => setConnected(false));
    s.on("connected", (info) => {
      const room = info?.room;
      if (room) {
        setPartnerRoom(room);
        // Re-bind listener for the dynamic room channel
        s.off(room);
        s.on(room, (payload) => {
          setLastEvent({ ...payload, _ts: Date.now() });
          handlersRef.current.forEach((fn) => { try { fn(payload); } catch (_e) {} });
        });
      }
    });

    return () => { s.disconnect(); socketRef.current = null; setConnected(false); };
  }, [user, appStatus?.status]);

  const on = useCallback((fn) => {
    handlersRef.current.add(fn);
    return () => handlersRef.current.delete(fn);
  }, []);

  return (
    <SocketCtx.Provider value={{ socket: socketRef.current, connected, lastEvent, partnerRoom, on }}>
      {children}
    </SocketCtx.Provider>
  );
};

export const useSocket = () => useContext(SocketCtx);
