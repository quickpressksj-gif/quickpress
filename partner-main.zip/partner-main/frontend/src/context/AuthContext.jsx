import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, getToken, setToken, clearToken } from "@/api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [appStatus, setAppStatus] = useState(null); // {has_application, status, partner_id}
  const [loading, setLoading] = useState(true);

  const fetchMe = useCallback(async () => {
    if (!getToken()) {
      setUser(null); setAppStatus(null); setLoading(false);
      return;
    }
    try {
      const meRes = await api.get("/auth/me");
      setUser(meRes.data.user);
      const sRes = await api.get("/partner/application-status");
      setAppStatus(sRes.data);
    } catch (e) {
      clearToken();
      setUser(null); setAppStatus(null);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchMe(); }, [fetchMe]);

  const login = async (phone, otp, name) => {
    const r = await api.post("/auth/otp/verify", { phone, otp, name, role: "partner" });
    setToken(r.data.token);
    await fetchMe();
    return r.data.user;
  };

  const logout = async () => {
    try { await api.post("/auth/logout"); } catch (e) { /* best-effort */ }
    clearToken();
    setUser(null); setAppStatus(null);
  };

  const refreshAppStatus = async () => {
    try {
      const sRes = await api.get("/partner/application-status");
      setAppStatus(sRes.data);
    } catch (e) { /* ignore */ }
  };

  return (
    <AuthContext.Provider value={{ user, appStatus, loading, login, logout, refreshAppStatus, fetchMe }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
