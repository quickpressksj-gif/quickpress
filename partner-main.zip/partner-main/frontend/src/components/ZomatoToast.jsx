import React, { createContext, useContext, useState, useCallback } from "react";
import { Bell, CheckCircle2, AlertCircle, XCircle, Info, X } from "lucide-react";

const ToastCtx = createContext(null);

const ICONS = {
  success: <CheckCircle2 className="w-5 h-5 text-emerald-600" />,
  error: <XCircle className="w-5 h-5 text-red-600" />,
  warning: <AlertCircle className="w-5 h-5 text-amber-500" />,
  info: <Info className="w-5 h-5 text-blue-600" />,
  bell: <Bell className="w-5 h-5 text-black bell-ring" />,
};

let idCounter = 1;

export const ZomatoToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const remove = useCallback((id) => {
    setToasts((t) => t.map((x) => (x.id === id ? { ...x, leaving: true } : x)));
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 240);
  }, []);

  const push = useCallback((opts) => {
    const id = idCounter++;
    const item = {
      id,
      kind: opts.kind || "info",
      title: opts.title || "",
      body: opts.body || "",
      duration: opts.duration ?? 3800,
      leaving: false,
    };
    setToasts((t) => [item, ...t].slice(0, 4));
    if (item.duration > 0) setTimeout(() => remove(id), item.duration);
    return id;
  }, [remove]);

  const toast = {
    success: (title, body) => push({ kind: "success", title, body }),
    error: (title, body) => push({ kind: "error", title, body }),
    warning: (title, body) => push({ kind: "warning", title, body }),
    info: (title, body) => push({ kind: "info", title, body }),
    alert: (title, body) => push({ kind: "bell", title, body, duration: 5200 }),
  };

  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <div className="fixed top-2 left-0 right-0 z-[100] flex flex-col items-center gap-2 px-3 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            data-testid={`zomato-toast-${t.kind}`}
            className={`${t.leaving ? "z-toast-exit" : "z-toast-enter"} pointer-events-auto w-full max-w-[460px] bg-white rounded-2xl shadow-[0_8px_30px_rgba(0,0,0,0.12)] border border-zinc-100 px-4 py-3 flex items-start gap-3`}
          >
            <div className="mt-0.5 shrink-0">{ICONS[t.kind]}</div>
            <div className="flex-1 min-w-0">
              {t.title && <div className="text-[15px] font-semibold text-zinc-900 leading-tight">{t.title}</div>}
              {t.body && <div className="text-[13px] text-zinc-600 mt-0.5 leading-snug">{t.body}</div>}
            </div>
            <button
              onClick={() => remove(t.id)}
              className="shrink-0 text-zinc-400 hover:text-zinc-700 btn-press"
              data-testid="zomato-toast-close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
};

export const useToast = () => useContext(ToastCtx);
