import React from "react";
import { NavLink } from "react-router-dom";
import { Package, BarChart3, TrendingUp, UtensilsCrossed, IndianRupee } from "lucide-react";

const TABS = [
  { to: "/orders",  label: "To Orders", icon: Package,         tid: "tab-to-orders" },
  { to: "/hub",     label: "Hub",       icon: BarChart3,       tid: "tab-hub" },
  { to: "/growth",  label: "Growth",    icon: TrendingUp,      tid: "tab-growth" },
  { to: "/menu",    label: "Menu",      icon: UtensilsCrossed, tid: "tab-menu" },
  { to: "/finance", label: "Finance",   icon: IndianRupee,     tid: "tab-finance" },
];

export default function BottomNav() {
  return (
    <nav
      data-testid="partner-bottom-nav"
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[420px] z-50 px-3 pb-3 pointer-events-none"
    >
      <div className="bg-zinc-900 rounded-full shadow-[0_10px_30px_rgba(0,0,0,0.3)] flex items-center justify-between px-1.5 py-1.5 pointer-events-auto pr-2">
        {TABS.map(({ to, label, icon: Icon, tid }) => (
          <NavLink
            key={to}
            to={to}
            data-testid={tid}
            className={({ isActive }) =>
              `flex-1 flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-full transition-all btn-press relative z-10 ${
                isActive ? "bg-white/95 text-zinc-900" : "text-zinc-300"
              }`
            }
          >
            <Icon className="w-5 h-5" strokeWidth={2.2} />
            <span className="text-[10px] font-medium leading-none">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
