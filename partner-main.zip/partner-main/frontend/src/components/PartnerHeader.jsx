import React, { useEffect, useState } from "react";
import { Bell, Menu as MenuIcon, ChevronDown, Search } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/api";
import { useAuth } from "@/context/AuthContext";

export default function PartnerHeader({ rightAction = "menu", showOnline = true, title }) {
  const { user, appStatus, logout } = useAuth();
  const navigate = useNavigate();
  const [partner, setPartner] = useState(null);
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [drawer, setDrawer] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        if (appStatus?.status === "Approved") {
          const r = await api.get("/partner/me");
          setPartner(r.data.partner);
          setOpen(!!r.data.partner?.is_open);
        }
        const n = await api.get("/partner/notifications");
        setUnread((n.data?.items || []).filter((x) => !x.read).length);
      } catch (e) { /* ignore */ }
    })();
  }, [appStatus]);

  const toggleOnline = async () => {
    const next = !open;
    setOpen(next);
    try {
      await api.post("/partner/status", { is_open: next });
    } catch (e) { setOpen(!next); /* revert */ }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <>
      <header data-testid="partner-header" className="sticky top-0 z-30 bg-white border-b border-zinc-100">
        <div className="px-4 pt-4 pb-3 flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
              {title ? title : "Showing data for"}
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <div data-testid="partner-name" className="text-[20px] font-bold text-zinc-900 leading-tight truncate">
                {partner?.name || user?.name || "QuickPress Partner"}
              </div>
              {!title && <ChevronDown className="w-4 h-4 text-zinc-700 shrink-0" />}
            </div>
            {!title && partner && (
              <div className="text-[12px] text-zinc-500 mt-0.5">
                ID: {partner.partner_id?.replace("ptr_","").toUpperCase()} • {partner.city || "QuickPress"}
              </div>
            )}
          </div>

          {showOnline && appStatus?.status === "Approved" && (
            <button
              onClick={toggleOnline}
              data-testid="online-toggle"
              className={`shrink-0 px-3 py-1.5 rounded-full text-[12px] font-semibold flex items-center gap-1.5 btn-press ${
                open ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-zinc-100 text-zinc-700 border border-zinc-200"
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${open ? "bg-emerald-500 pulse-dot" : "bg-zinc-400"}`} />
              {open ? "Online" : "Offline"}
            </button>
          )}

          <Link to="/notifications" data-testid="notif-bell" className="shrink-0 relative p-2 rounded-full hover:bg-zinc-100 btn-press">
            <Bell className="w-5 h-5 text-zinc-700" />
            {unread > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[9px] font-bold rounded-full min-w-[16px] h-4 px-1 flex items-center justify-center">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </Link>

          {rightAction === "menu" && (
            <button onClick={() => setDrawer(true)} data-testid="header-menu-btn" className="shrink-0 p-2 rounded-full hover:bg-zinc-100 btn-press">
              <MenuIcon className="w-5 h-5 text-zinc-700" />
            </button>
          )}
          {rightAction === "search" && (
            <button data-testid="header-search-btn" className="shrink-0 p-2 rounded-full hover:bg-zinc-100 btn-press">
              <Search className="w-5 h-5 text-zinc-700" />
            </button>
          )}
        </div>
      </header>

      {/* Side drawer menu */}
      {drawer && (
        <div className="fixed inset-0 z-50" onClick={() => setDrawer(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div
            className="absolute top-0 right-0 h-full w-[78%] max-w-[360px] bg-white shadow-2xl p-5 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            data-testid="partner-drawer"
          >
            <div className="flex items-center gap-3 pb-4 border-b border-zinc-100">
              <div className="w-12 h-12 rounded-full bg-zinc-900 text-white grid place-items-center font-bold text-lg">
                {(partner?.name || user?.name || "P").charAt(0)}
              </div>
              <div className="min-w-0">
                <div className="font-semibold text-zinc-900 truncate">{partner?.name || user?.name}</div>
                <div className="text-xs text-zinc-500 truncate">{user?.phone}</div>
              </div>
            </div>
            {[
              { to: "/reviews", label: "Reviews & Ratings", tid: "drawer-reviews" },
              { to: "/reports", label: "Reports", tid: "drawer-reports" },
              { to: "/support", label: "Help & Support", tid: "drawer-support" },
              { to: "/bank", label: "Bank & Payout", tid: "drawer-bank" },
              { to: "/documents", label: "Documents", tid: "drawer-documents" },
              { to: "/settings", label: "Settings", tid: "drawer-settings" },
            ].map((it) => (
              <Link
                key={it.to}
                to={it.to}
                onClick={() => setDrawer(false)}
                data-testid={it.tid}
                className="block py-3 border-b border-zinc-100 text-zinc-800 font-medium"
              >
                {it.label}
              </Link>
            ))}
            <button
              onClick={handleLogout}
              data-testid="drawer-logout"
              className="mt-6 w-full py-3 bg-red-50 text-red-600 rounded-xl font-semibold btn-press"
            >
              Log out
            </button>
          </div>
        </div>
      )}
    </>
  );
}
