import React from "react";
import BottomNav from "./BottomNav";

export default function Layout({ children, hideNav = false }) {
  return (
    <div className="app-shell pb-[88px]">
      {children}
      {!hideNav && <BottomNav />}
    </div>
  );
}
