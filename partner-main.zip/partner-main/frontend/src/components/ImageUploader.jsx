import React, { useRef, useState, useCallback } from "react";
import { Camera, Upload, X, Check, Image as ImageIcon } from "lucide-react";

/**
 * Image uploader that converts files to base64 strings (stored directly in MongoDB).
 * Suitable for small/medium images. Production should use S3.
 */
export default function ImageUploader({
  label,
  category,
  required = 0,
  current = [],
  onUploaded,
  testid,
}) {
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const handleFiles = useCallback(async (fileList) => {
    if (!fileList || !fileList.length) return;
    setBusy(true);
    try {
      const promises = Array.from(fileList).slice(0, 5).map(
        (f) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(f);
          })
      );
      const dataUrls = await Promise.all(promises);
      await onUploaded(category, dataUrls);
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }, [category, onUploaded]);

  const count = current.length;
  const ok = count >= required;

  return (
    <div data-testid={testid} className="bg-white border border-zinc-200 rounded-2xl p-3.5">
      <div className="flex items-start justify-between">
        <div>
          <div className="font-semibold text-zinc-900 text-[14px]">{label}</div>
          <div className="text-[11px] text-zinc-500 mt-0.5">
            {required > 0
              ? <>Min {required} required • <span className={ok ? "text-emerald-600 font-semibold" : "text-amber-600 font-semibold"}>{count} uploaded</span></>
              : <>{count} uploaded</>}
          </div>
        </div>
        {ok && required > 0 && (
          <div className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
            <Check className="w-3 h-3" /> OK
          </div>
        )}
      </div>

      {count > 0 && (
        <div className="mt-3 grid grid-cols-3 gap-2" data-testid={`${testid}-thumbs`}>
          {current.slice(0, 6).map((src, i) => (
            <div key={i} className="aspect-square rounded-xl bg-zinc-100 overflow-hidden flex items-center justify-center">
              {src?.startsWith("data:") || src?.startsWith("http") ? (
                <img src={src} alt="" className="w-full h-full object-cover" />
              ) : (
                <ImageIcon className="w-5 h-5 text-zinc-400" />
              )}
            </div>
          ))}
          {count > 6 && (
            <div className="aspect-square rounded-xl bg-zinc-100 grid place-items-center text-zinc-500 text-xs font-semibold">
              +{count - 6}
            </div>
          )}
        </div>
      )}

      <div className="mt-3 flex gap-2">
        <button
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          data-testid={`${testid}-upload-btn`}
          className="flex-1 bg-zinc-900 text-white font-semibold py-2.5 rounded-xl btn-press disabled:opacity-50 flex items-center justify-center gap-1.5 text-sm"
        >
          <Camera className="w-4 h-4" /> {busy ? "Uploading..." : count > 0 ? "Add more" : "Upload photos"}
        </button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        multiple
        capture="environment"
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
        data-testid={`${testid}-input`}
      />
    </div>
  );
}
