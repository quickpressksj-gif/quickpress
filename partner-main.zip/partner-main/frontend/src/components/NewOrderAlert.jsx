import React, { useEffect, useRef, useState, useCallback } from "react";
import { Bell, Check, X, MapPin, Clock } from "lucide-react";
import { api, fmtMoney, getToken } from "@/api";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "react-router-dom";
import { useToast } from "@/components/ZomatoToast";
import { useSocket } from "@/context/SocketContext";

// WebAudio-based ringtone (no external mp3 needed)
function playRingtone(audioCtxRef, stopRef) {
  try {
    const ctx = audioCtxRef.current || new (window.AudioContext || window.webkitAudioContext)();
    audioCtxRef.current = ctx;
    if (ctx.state === "suspended") ctx.resume();

    const playBeep = (freq, start, duration) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      osc.connect(gain);
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.35, ctx.currentTime + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + duration);
    };

    const loop = () => {
      if (stopRef.current) return;
      playBeep(659.25, 0.0, 0.22);
      playBeep(783.99, 0.28, 0.32);
      setTimeout(loop, 1500);
    };
    loop();
  } catch (e) { /* WebAudio not available */ }
}

const SINCE_KEY = "qp_last_seen_order_at";

export default function NewOrderAlert() {
  const { user, appStatus } = useAuth();
  const toast = useToast();
  const location = useLocation();
  const { on: onSocket, connected } = useSocket();
  const [alertOrder, setAlertOrder] = useState(null);
  const [busy, setBusy] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(30);
  const audioCtxRef = useRef(null);
  const stopRingRef = useRef(false);
  const seenIds = useRef(new Set());

  const active =
    user && appStatus?.status === "Approved" &&
    !location.pathname.startsWith("/login") &&
    !location.pathname.startsWith("/apply") &&
    !location.pathname.startsWith("/pending") &&
    !location.pathname.startsWith("/admin");

  const stopRing = useCallback(() => {
    stopRingRef.current = true;
    try { audioCtxRef.current?.close(); audioCtxRef.current = null; } catch (e) {}
  }, []);

  const startRing = useCallback(() => {
    stopRingRef.current = false;
    playRingtone(audioCtxRef, stopRingRef);
  }, []);

  const trigger = useCallback((order) => {
    if (!order || seenIds.current.has(order.order_id)) return;
    seenIds.current.add(order.order_id);
    setAlertOrder(order);
    setSecondsLeft(30);
    startRing();
  }, [startRing]);

  // Socket.IO – instant fire
  useEffect(() => {
    if (!active) return;
    return onSocket((ev) => {
      if (ev?.type === "NEW_ORDER" && ev.order) {
        trigger(ev.order);
      }
    });
  }, [active, onSocket, trigger]);

  // Fallback polling (in case socket is down or slow)
  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    const since = localStorage.getItem(SINCE_KEY) || new Date(Date.now() - 60_000).toISOString();
    const tick = async () => {
      if (cancelled || !getToken() || alertOrder) return;
      try {
        const r = await api.get(`/partner/orders-poll?since=${encodeURIComponent(since)}`);
        const items = r.data.items || [];
        const newest = items.find((o) => !seenIds.current.has(o.order_id));
        if (newest) trigger(newest);
        if (r.data.now) localStorage.setItem(SINCE_KEY, r.data.now);
      } catch (e) { /* ignore */ }
    };
    tick();
    // Slower polling when socket is connected, faster when not
    const interval = connected ? 30_000 : 10_000;
    const id = setInterval(tick, interval);
    return () => { cancelled = true; clearInterval(id); };
  }, [active, alertOrder, trigger, connected]);

  // Countdown
  useEffect(() => {
    if (!alertOrder) return;
    setSecondsLeft(30);
    const id = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [alertOrder]);

  useEffect(() => {
    if (alertOrder && secondsLeft === 0) handleClose();
  }, [secondsLeft, alertOrder]);

  const handleClose = () => {
    stopRing();
    setAlertOrder(null);
  };

  const act = async (action) => {
    if (!alertOrder) return;
    setBusy(true);
    try {
      await api.post(`/partner/orders/${alertOrder.order_id}/${action}`);
      toast.success(action === "accept" ? "Order accepted" : "Order rejected");
      handleClose();
    } catch (e) {
      toast.error("Action failed", e.response?.data?.detail || "");
    }
    setBusy(false);
  };

  if (!alertOrder) return null;

  return (
    <div className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center" data-testid="new-order-alert">
      <div className="w-full max-w-[480px] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">
        <div className="bg-zinc-900 text-white px-5 py-4 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-amber-400 grid place-items-center">
            <Bell className="w-6 h-6 text-zinc-900 bell-ring" />
          </div>
          <div className="flex-1">
            <div className="text-[11px] uppercase tracking-wider text-amber-300 font-bold">New Order {connected ? "• live" : ""}</div>
            <div className="text-[18px] font-bold leading-tight">{alertOrder.user_name || "Customer"} • {fmtMoney(alertOrder.total)}</div>
          </div>
          <button onClick={handleClose} data-testid="new-order-close" className="p-1.5 text-zinc-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-3">
          <div className="flex items-center gap-2 text-[12px] text-zinc-600">
            <Clock className="w-3.5 h-3.5" />
            <span>Pickup {alertOrder.pickup_date || "Today"} • {alertOrder.pickup_slot || "Within 30 min"}</span>
            <span className="ml-auto px-2 py-0.5 rounded-full bg-red-50 text-red-600 font-bold text-[11px]">
              {secondsLeft}s
            </span>
          </div>

          <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3.5">
            <div className="text-[10px] uppercase font-semibold text-zinc-500">Items</div>
            <div className="mt-1 space-y-1">
              {alertOrder.items?.map((it, idx) => (
                <div key={idx} className="flex justify-between text-[13px]">
                  <span className="text-zinc-800">{it.qty}× {it.name}</span>
                  <span className="font-semibold">{fmtMoney(it.price * it.qty)}</span>
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-dashed border-zinc-200 flex justify-between font-bold">
              <span>Total ({alertOrder.payment_method})</span>
              <span className="text-emerald-700">{fmtMoney(alertOrder.total)}</span>
            </div>
          </div>

          <div className="flex items-start gap-2 text-[12px] text-zinc-600">
            <MapPin className="w-3.5 h-3.5 mt-0.5" />
            <span className="flex-1">{alertOrder.address?.line1}, {alertOrder.address?.city} - {alertOrder.address?.pincode}</span>
          </div>

          <div className="flex gap-2 pt-2">
            <button onClick={() => act("reject")} disabled={busy} data-testid="new-order-reject"
                    className="flex-1 py-3.5 rounded-2xl bg-zinc-100 text-red-600 font-bold btn-press disabled:opacity-50 flex items-center justify-center gap-1.5">
              <X className="w-4 h-4" /> Reject
            </button>
            <button onClick={() => act("accept")} disabled={busy} data-testid="new-order-accept"
                    className="flex-[2] py-3.5 rounded-2xl bg-emerald-600 text-white font-bold btn-press disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-200">
              <Check className="w-4 h-4" /> Accept order
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
