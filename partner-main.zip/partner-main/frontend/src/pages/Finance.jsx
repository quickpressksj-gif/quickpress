import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Download, ArrowRight, ChevronDown, X } from "lucide-react";

export default function Finance() {
  const toast = useToast();
  const [tab, setTab] = useState("payouts");
  const [earnings, setEarnings] = useState(null);
  const [settlements, setSettlements] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [showReq, setShowReq] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const [e, s, p] = await Promise.all([
        api.get("/partner/earnings"),
        api.get("/partner/settlements"),
        api.get("/partner/payouts"),
      ]);
      setEarnings(e.data); setSettlements(s.data.items || []); setPayouts(p.data.items || []);
    } catch (er) {}
  };

  const pending = settlements.filter((s) => s.status === "Pending").reduce((a, s) => a + (s.amount || 0), 0);

  return (
    <>
      <PartnerHeader title="Finance" rightAction="menu" showOnline={false} />

      <div className="px-3 pt-3">
        <div className="bg-zinc-100 rounded-full p-1 flex">
          {[
            { id: "payouts", label: "Payouts" },
            { id: "invoices", label: "Invoices & Taxes" },
          ].map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} data-testid={`fin-tab-${t.id}`}
                    className={`flex-1 py-1.5 rounded-full text-[13px] font-semibold ${
                      tab === t.id ? "bg-white text-zinc-900 shadow" : "text-zinc-600"
                    }`}>{t.label}</button>
          ))}
        </div>
      </div>

      {tab === "payouts" && (
        <div className="px-4 py-3 space-y-4">
          <div>
            <div className="font-bold text-zinc-900 text-[16px] mb-2">Current cycle</div>
            <Link to="/finance/cycle/current" data-testid="current-cycle" className="block bg-white border border-zinc-200 rounded-2xl p-4 btn-press">
              <div className="text-zinc-500 text-[12px]">Est. payout (this week)</div>
              <div className="text-[28px] font-bold mt-0.5">{fmtMoney(pending)}</div>
              <div className="text-[12px] text-zinc-500 mt-0.5">{settlements.filter((s) => s.status === "Pending").length} orders pending</div>

              <div className="border-t border-dashed border-zinc-200 mt-3 pt-3 flex justify-between">
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">Payout for</div>
                  <div className="text-[13px] font-semibold">This week</div>
                </div>
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">Payout date</div>
                  <div className="text-[13px] font-semibold">Mon next week</div>
                </div>
              </div>
              <div className="mt-2 text-[12px] text-blue-600 font-semibold">View settlement breakdown →</div>
            </Link>
            <button onClick={() => setShowReq(true)} disabled={pending <= 0} data-testid="request-payout"
                    className="mt-2 w-full bg-zinc-900 text-white font-semibold py-2.5 rounded-xl btn-press disabled:opacity-50">
              Request payout
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="font-bold text-zinc-900 text-[16px]">Earnings overview</div>
              <button className="text-[12px] text-blue-600 font-semibold flex items-center gap-1" data-testid="get-report">
                <Download className="w-3.5 h-3.5" /> Get report
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2" data-testid="earnings-overview">
              <Card label="Today" value={fmtMoney(earnings?.today || 0)} />
              <Card label="This week" value={fmtMoney(earnings?.weekly || 0)} />
              <Card label="This month" value={fmtMoney(earnings?.monthly || 0)} />
            </div>
            <div className="mt-2 bg-zinc-900 text-white rounded-2xl p-4">
              <div className="text-zinc-300 text-[12px]">Net revenue (12 months)</div>
              <div className="text-[26px] font-bold">{fmtMoney(earnings?.net_revenue || 0)}</div>
              <div className="text-[11px] text-zinc-400 mt-1">
                Gross {fmtMoney(earnings?.gross_revenue || 0)} • Commission {fmtMoney(earnings?.platform_commission || 0)}
              </div>
            </div>
          </div>

          <div>
            <div className="font-bold text-zinc-900 text-[16px] mb-2">Past cycles</div>
            <div className="space-y-2" data-testid="past-cycles">
              {payouts.length === 0 && <div className="text-center text-sm text-zinc-500 py-6">No past payouts</div>}
              {payouts.map((p, idx) => (
                <Link to={`/finance/cycle/last`} key={p.payout_id} className="block bg-white border border-zinc-200 rounded-2xl p-4 btn-press" data-testid={`payout-${p.payout_id}`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-zinc-500 text-[11px] uppercase">Net payout</div>
                      <div className="text-[20px] font-bold mt-0.5">{fmtMoney(p.amount)}</div>
                    </div>
                    <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full ${
                      p.status === "Paid" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"
                    }`}>{p.status}</span>
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-2">Requested: {new Date(p.created_at).toLocaleDateString()}</div>
                  <div className="mt-1 text-[12px] text-blue-600 font-semibold">View breakdown →</div>
                </Link>
              ))}
            </div>

            <div className="mt-3">
              <div className="font-bold text-zinc-900 text-[15px] mb-2">Settlements</div>
              <div className="space-y-2" data-testid="settlements-list">
                {settlements.slice(0, 8).map((s) => (
                  <div key={s.settlement_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex justify-between" data-testid={`stl-${s.settlement_id}`}>
                    <div>
                      <div className="text-zinc-500 text-[11px] font-mono">#{s.order_id?.replace("ord_","").toUpperCase().slice(0,8)}</div>
                      <div className="font-semibold mt-0.5">{fmtMoney(s.amount)}</div>
                      <div className="text-[11px] text-zinc-500">Gross {fmtMoney(s.gross)} − {fmtMoney(s.commission)} commission</div>
                    </div>
                    <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full self-start ${
                      s.status === "Paid" ? "bg-emerald-50 text-emerald-700" :
                      s.status === "Approved" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"
                    }`}>{s.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === "invoices" && (
        <div className="px-4 py-3" data-testid="invoices-list">
          <div className="text-center text-sm text-zinc-500 py-12">
            Invoices &amp; GST reports auto-generated monthly. <br/>
            <button className="text-blue-600 font-semibold mt-2" data-testid="invoices-download">Download last month →</button>
          </div>
        </div>
      )}

      {showReq && <RequestPayout pending={pending} onClose={() => setShowReq(false)} onDone={() => { setShowReq(false); load(); }} />}
    </>
  );
}

const Card = ({ label, value }) => (
  <div className="bg-white border border-zinc-200 rounded-2xl p-3 text-center">
    <div className="text-[10px] uppercase text-zinc-500">{label}</div>
    <div className="font-bold text-zinc-900 mt-1">{value}</div>
  </div>
);

function RequestPayout({ pending, onClose, onDone }) {
  const toast = useToast();
  const [amt, setAmt] = useState(pending);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await api.post("/partner/payouts/request", { amount: parseFloat(amt) });
      toast.success("Payout requested", "We'll process within 2 business days");
      onDone();
    } catch { toast.error("Failed"); }
    setBusy(false);
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8" onClick={(e) => e.stopPropagation()} data-testid="request-payout-modal">
        <div className="flex justify-between items-center mb-3">
          <div className="font-bold text-lg">Request payout</div>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="text-[12px] text-zinc-500">Available: <span className="text-zinc-900 font-semibold">{fmtMoney(pending)}</span></div>
        <div className="mt-3 flex items-center gap-2 border-2 border-zinc-200 rounded-2xl px-4 py-3">
          <span className="font-semibold">₹</span>
          <input type="number" value={amt} onChange={(e) => setAmt(e.target.value)} data-testid="payout-amount" className="flex-1 outline-none text-[18px] font-semibold" />
        </div>
        <button onClick={submit} disabled={busy || amt <= 0} data-testid="payout-submit"
                className="mt-4 w-full bg-zinc-900 text-white font-semibold py-3 rounded-2xl btn-press disabled:opacity-50">
          {busy ? "Requesting..." : "Confirm request"}
        </button>
      </div>
    </div>
  );
}
