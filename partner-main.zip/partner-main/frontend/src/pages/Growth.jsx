import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Plus, BadgePercent, Megaphone, Trash2, X, ArrowRight } from "lucide-react";

export default function Growth() {
  const [tab, setTab] = useState("offers");
  const toast = useToast();
  const [offers, setOffers] = useState([]);
  const [ads, setAds] = useState([]);
  const [showAddOffer, setShowAddOffer] = useState(false);
  const [showAddAd, setShowAddAd] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const [o, a] = await Promise.all([api.get("/partner/marketing"), api.get("/partner/ads")]);
      setOffers(o.data.items || []);
      setAds(a.data.items || []);
    } catch (e) {}
  };

  return (
    <>
      <PartnerHeader title="Grow your business" rightAction="search" showOnline={false} />

      <div className="px-3 pt-3">
        <div className="bg-zinc-100 rounded-full p-1 flex">
          {[
            { id: "offers", label: "Offers" },
            { id: "ads", label: "Ads" },
          ].map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} data-testid={`growth-tab-${t.id}`}
                    className={`flex-1 py-1.5 rounded-full text-[13px] font-semibold ${
                      tab === t.id ? "bg-white text-zinc-900 shadow" : "text-zinc-600"
                    }`}>{t.label}</button>
          ))}
        </div>
      </div>

      <div className="px-4 py-3">
        {/* Hero cards */}
        <div className="text-[12px] uppercase tracking-wider font-semibold text-zinc-500 mb-2">Build your own</div>
        <div className="space-y-2">
          <button onClick={() => setShowAddOffer(true)} data-testid="growth-offer-cta" className="w-full bg-white border border-zinc-200 rounded-2xl p-4 flex items-center gap-3 btn-press text-left">
            <div className="w-12 h-12 rounded-xl bg-amber-100 grid place-items-center">
              <BadgePercent className="w-6 h-6 text-amber-700" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-zinc-900">Offers and discounts</div>
              <div className="text-[12px] text-zinc-500">Start your own offers and grow your business</div>
            </div>
            <ArrowRight className="w-4 h-4 text-blue-600" />
          </button>
          <button onClick={() => setShowAddAd(true)} data-testid="growth-ad-cta" className="w-full bg-white border border-zinc-200 rounded-2xl p-4 flex items-center gap-3 btn-press text-left">
            <div className="w-12 h-12 rounded-xl bg-orange-100 grid place-items-center">
              <Megaphone className="w-6 h-6 text-orange-700" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-zinc-900">Create Ads</div>
              <div className="text-[12px] text-zinc-500">Get seen by more customers and get more orders</div>
            </div>
            <ArrowRight className="w-4 h-4 text-blue-600" />
          </button>
        </div>

        {tab === "offers" && (
          <div className="mt-5">
            <div className="font-bold text-zinc-900 text-[15px] mb-2">Your offers</div>
            <div className="space-y-2" data-testid="offers-list">
              {offers.length === 0 && <div className="text-center text-sm text-zinc-500 py-6">No offers yet</div>}
              {offers.map((o) => (
                <div key={o.offer_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex items-center gap-3" data-testid={`offer-${o.offer_id}`}>
                  <div className="w-10 h-10 rounded-xl bg-amber-100 grid place-items-center"><BadgePercent className="w-5 h-5 text-amber-700" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-zinc-900">{o.title}</div>
                    <div className="text-[12px] text-zinc-500 mt-0.5">{o.code} • {o.discount_pct}% off • till {o.valid_till}</div>
                  </div>
                  <button onClick={async () => { await api.delete(`/partner/marketing/${o.offer_id}`); toast.success("Removed"); load(); }}
                          data-testid={`offer-del-${o.offer_id}`} className="p-1.5 text-red-500"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "ads" && (
          <div className="mt-5">
            <div className="font-bold text-zinc-900 text-[15px] mb-2">Your campaigns</div>
            <div className="space-y-2" data-testid="ads-list">
              {ads.length === 0 && <div className="text-center text-sm text-zinc-500 py-6">No ad campaigns yet</div>}
              {ads.map((c) => (
                <div key={c.campaign_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5" data-testid={`ad-${c.campaign_id}`}>
                  <div className="flex items-start justify-between">
                    <div className="min-w-0">
                      <div className="font-semibold text-zinc-900">{c.name}</div>
                      <div className="text-[12px] text-zinc-500">{c.campaign_type} • {fmtMoney(c.budget)} budget</div>
                    </div>
                    <button onClick={async () => { await api.delete(`/partner/ads/${c.campaign_id}`); toast.success("Removed"); load(); }}
                            data-testid={`ad-del-${c.campaign_id}`} className="p-1.5 text-red-500"><Trash2 className="w-4 h-4" /></button>
                  </div>
                  <div className="mt-2 grid grid-cols-4 gap-2 text-center">
                    <Stat label="Imp" value={c.impressions} />
                    <Stat label="Clicks" value={c.clicks} />
                    <Stat label="CTR" value={`${c.ctr}%`} />
                    <Stat label="ROI" value={`${c.roi}%`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showAddOffer && <AddOffer onClose={() => setShowAddOffer(false)} onSaved={() => { setShowAddOffer(false); load(); }} />}
      {showAddAd && <AddAd onClose={() => setShowAddAd(false)} onSaved={() => { setShowAddAd(false); load(); }} />}
    </>
  );
}

const Stat = ({ label, value }) => (
  <div className="bg-zinc-50 rounded-xl py-1.5">
    <div className="text-[10px] text-zinc-500 uppercase">{label}</div>
    <div className="text-[13px] font-bold text-zinc-900">{value}</div>
  </div>
);

function AddOffer({ onClose, onSaved }) {
  const toast = useToast();
  const [form, setForm] = useState({ title: "Flat 20% off", code: "QP20", discount_pct: 20, valid_till: "2026-12-31" });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await api.post("/partner/marketing", { ...form, discount_pct: parseFloat(form.discount_pct) });
      toast.success("Offer created");
      onSaved();
    } catch { toast.error("Failed"); }
    setBusy(false);
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8" onClick={(e) => e.stopPropagation()} data-testid="add-offer-modal">
        <div className="flex justify-between items-center mb-3">
          <div className="font-bold text-lg">New offer</div>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-3">
          <input className="zinp w-full" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="offer-title" />
          <input className="zinp w-full" placeholder="Code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} data-testid="offer-code" />
          <input type="number" className="zinp w-full" placeholder="Discount %" value={form.discount_pct} onChange={(e) => setForm({ ...form, discount_pct: e.target.value })} data-testid="offer-pct" />
          <input className="zinp w-full" placeholder="Valid till YYYY-MM-DD" value={form.valid_till} onChange={(e) => setForm({ ...form, valid_till: e.target.value })} data-testid="offer-till" />
          <button onClick={save} disabled={busy} data-testid="offer-save" className="w-full bg-zinc-900 text-white font-semibold py-3 rounded-2xl btn-press">{busy ? "Saving..." : "Create offer"}</button>
        </div>
        <style>{`.zinp { border: 2px solid #e4e4e7; border-radius: 14px; padding: 12px 14px; outline: none; font-size: 15px;} .zinp:focus { border-color: #0f0f10; }`}</style>
      </div>
    </div>
  );
}

function AddAd({ onClose, onSaved }) {
  const toast = useToast();
  const today = new Date().toISOString().slice(0,10);
  const [form, setForm] = useState({ name: "Visibility Boost", campaign_type: "Visibility", budget: 1000, daily_budget: 100, start_date: today, end_date: "2026-12-31", target_city: "", target_area: "", target_category: "" });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await api.post("/partner/ads", { ...form, budget: parseFloat(form.budget), daily_budget: parseFloat(form.daily_budget) });
      toast.success("Campaign created", "Ad is now live");
      onSaved();
    } catch { toast.error("Failed"); }
    setBusy(false);
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8" onClick={(e) => e.stopPropagation()} data-testid="add-ad-modal">
        <div className="flex justify-between items-center mb-3">
          <div className="font-bold text-lg">New campaign</div>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-3">
          <input className="zinp w-full" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="ad-name" />
          <select className="zinp w-full bg-white" value={form.campaign_type} onChange={(e) => setForm({ ...form, campaign_type: e.target.value })} data-testid="ad-type">
            <option>Visibility</option><option>Sponsored Listing</option><option>Boost</option>
          </select>
          <div className="grid grid-cols-2 gap-3">
            <input type="number" className="zinp w-full" placeholder="Total budget" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} data-testid="ad-budget" />
            <input type="number" className="zinp w-full" placeholder="Daily" value={form.daily_budget} onChange={(e) => setForm({ ...form, daily_budget: e.target.value })} data-testid="ad-daily" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input className="zinp w-full" placeholder="Start" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} data-testid="ad-start" />
            <input className="zinp w-full" placeholder="End" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} data-testid="ad-end" />
          </div>
          <button onClick={save} disabled={busy} data-testid="ad-save" className="w-full bg-zinc-900 text-white font-semibold py-3 rounded-2xl btn-press">{busy ? "Saving..." : "Launch campaign"}</button>
        </div>
        <style>{`.zinp { border: 2px solid #e4e4e7; border-radius: 14px; padding: 12px 14px; outline: none; font-size: 15px;} .zinp:focus { border-color: #0f0f10; }`}</style>
      </div>
    </div>
  );
}
