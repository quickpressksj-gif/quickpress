import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";

const PERIODS = [
  { id: "daily", label: "Daily" },
  { id: "weekly", label: "Weekly" },
  { id: "monthly", label: "Monthly" },
];

export default function Reports() {
  const [period, setPeriod] = useState("weekly");
  const [data, setData] = useState(null);

  useEffect(() => { load(); }, [period]);
  const load = async () => {
    try {
      const r = await api.get(`/partner/reports?period=${period}`);
      setData(r.data);
    } catch (e) { setData(null); }
  };

  return (
    <>
      <PartnerHeader title="Reports" rightAction="menu" showOnline={false} />
      <div className="px-4 py-3">
        <div className="bg-zinc-100 rounded-full p-1 flex">
          {PERIODS.map((p) => (
            <button key={p.id} onClick={() => setPeriod(p.id)} data-testid={`report-period-${p.id}`}
                    className={`flex-1 py-1.5 rounded-full text-[13px] font-semibold ${
                      period === p.id ? "bg-white text-zinc-900 shadow" : "text-zinc-600"
                    }`}>{p.label}</button>
          ))}
        </div>

        {data && (
          <>
            <div className="mt-4 grid grid-cols-2 gap-3" data-testid="report-kpis">
              <Card label="Orders" value={data.orders} />
              <Card label="Delivered" value={data.delivered} />
              <Card label="Cancelled" value={data.cancelled} />
              <Card label="Avg order value" value={fmtMoney(data.avg_order_value)} />
            </div>
            <div className="mt-3 bg-zinc-900 text-white rounded-2xl p-4">
              <div className="text-zinc-300 text-[12px] uppercase">Total revenue ({period})</div>
              <div className="text-[26px] font-bold">{fmtMoney(data.revenue)}</div>
            </div>

            <div className="mt-4">
              <div className="font-bold text-zinc-900 text-[15px] mb-2">Top services</div>
              <div className="space-y-2" data-testid="top-services">
                {data.by_service.length === 0 && <div className="text-sm text-zinc-500 text-center py-6">No data yet</div>}
                {data.by_service.map((s, i) => (
                  <div key={i} className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-zinc-900">{s.name}</div>
                      <div className="text-[12px] text-zinc-500">{s.qty} sold</div>
                    </div>
                    <div className="font-bold text-zinc-900">{fmtMoney(s.revenue)}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}

const Card = ({ label, value }) => (
  <div className="bg-white border border-zinc-200 rounded-2xl p-3.5">
    <div className="text-[12px] text-zinc-500">{label}</div>
    <div className="text-[22px] font-bold mt-1">{value}</div>
  </div>
);
