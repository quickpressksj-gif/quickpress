import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Building2, CreditCard, Save } from "lucide-react";

export default function BankSettings() {
  const toast = useToast();
  const [form, setForm] = useState({
    account_number: "", ifsc: "", bank_name: "", account_holder: "", upi_id: "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const r = await api.get("/partner/me");
        const p = r.data.partner || {};
        setForm({
          account_number: p.account_number || "",
          ifsc: p.ifsc || "",
          bank_name: p.bank_name || "",
          account_holder: p.account_holder || p.owner_name || "",
          upi_id: p.upi_id || "",
        });
      } catch (e) { /* ignore */ }
    })();
  }, []);

  const save = async () => {
    setBusy(true);
    try {
      await api.patch("/partner/bank", form);
      toast.success("Saved", "Your bank details have been updated");
    } catch (e) { toast.error("Save failed"); }
    setBusy(false);
  };

  return (
    <>
      <PartnerHeader title="Bank & Payout" rightAction="menu" showOnline={false} />
      <div className="px-4 py-4 space-y-3" data-testid="bank-settings">
        <div className="bg-zinc-900 text-white rounded-2xl p-4 flex items-center gap-3">
          <CreditCard className="w-6 h-6 text-amber-400" />
          <div>
            <div className="font-bold">Where do we send your payouts?</div>
            <div className="text-[12px] text-zinc-300">Used for all settlement transfers via NEFT/IMPS</div>
          </div>
        </div>

        <Field label="Account holder" testid="bank-holder">
          <input value={form.account_holder} onChange={(e) => setForm({ ...form, account_holder: e.target.value })} className="zinp" />
        </Field>
        <Field label="Bank account number" testid="bank-account">
          <input value={form.account_number} onChange={(e) => setForm({ ...form, account_number: e.target.value })} className="zinp" />
        </Field>
        <Field label="IFSC code" testid="bank-ifsc">
          <input value={form.ifsc} onChange={(e) => setForm({ ...form, ifsc: e.target.value.toUpperCase() })} className="zinp" />
        </Field>
        <Field label="Bank name" testid="bank-name">
          <input value={form.bank_name} onChange={(e) => setForm({ ...form, bank_name: e.target.value })} className="zinp" placeholder="State Bank of India" />
        </Field>
        <Field label="UPI ID (optional)" testid="bank-upi">
          <input value={form.upi_id} onChange={(e) => setForm({ ...form, upi_id: e.target.value })} className="zinp" placeholder="yourshop@upi" />
        </Field>

        <button onClick={save} disabled={busy} data-testid="bank-save"
                className="w-full bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl btn-press disabled:opacity-50 flex items-center justify-center gap-2">
          <Save className="w-4 h-4" /> {busy ? "Saving..." : "Save details"}
        </button>
      </div>
      <style>{`.zinp { width: 100%; border: 2px solid #e4e4e7; border-radius: 14px; padding: 12px 14px; outline: none; font-size: 15px; background: white; } .zinp:focus { border-color: #0f0f10; }`}</style>
    </>
  );
}

const Field = ({ label, testid, children }) => (
  <label className="block" data-testid={testid}>
    <div className="text-[12px] font-semibold text-zinc-700 mb-1.5">{label}</div>
    {children}
  </label>
);
