import React, { useEffect, useState } from "react";
import { api } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { ShieldCheck, ShieldX, Eye, ArrowLeft, X } from "lucide-react";
import { Link } from "react-router-dom";

export default function AdminPartners() {
  const toast = useToast();
  const [tab, setTab] = useState("Pending");
  const [items, setItems] = useState([]);
  const [detail, setDetail] = useState(null);
  const [docs, setDocs] = useState([]);

  useEffect(() => { load(); }, [tab]);
  const load = async () => {
    try {
      const r = await api.get(`/admin/partners?status=${tab}`);
      setItems(r.data.items || []);
    } catch (e) { setItems([]); }
  };

  const open = async (pid) => {
    const r = await api.get(`/admin/partners/${pid}`);
    setDetail(r.data.partner);
    setDocs(r.data.documents || []);
  };

  const approve = async (pid) => {
    await api.post(`/admin/partners/${pid}/approve`, {});
    toast.success("Partner approved");
    setDetail(null); load();
  };

  const reject = async (pid) => {
    const reason = window.prompt("Reason for rejection?") || "Application did not meet requirements.";
    await api.post(`/admin/partners/${pid}/reject`, { reason });
    toast.success("Partner rejected");
    setDetail(null); load();
  };

  const seedDemo = async (pid) => {
    try {
      const r = await api.post(`/admin/partners/${pid}/seed-demo`);
      toast.success("Demo data seeded", r.data?.msg === "already seeded" ? "Was already seeded" : "Orders & settlements added");
      load();
    } catch (e) { toast.error("Failed", e.response?.data?.detail || ""); }
  };

  const spawnOrder = async (pid) => {
    try {
      const r = await api.post(`/admin/partners/${pid}/spawn-order`);
      toast.alert("New order sent!", `${r.data.customer} placed an order worth ₹${r.data.total}. Partner's app should ring within 8s.`);
    } catch (e) { toast.error("Failed", e.response?.data?.detail || ""); }
  };

  return (
    <div className="app-shell min-h-screen bg-white">
      <header className="sticky top-0 bg-white border-b border-zinc-100 px-4 py-3 flex items-center gap-3 z-30">
        <Link to="/login" className="p-2 -ml-2 btn-press" data-testid="admin-back"><ArrowLeft className="w-5 h-5" /></Link>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">Admin console</div>
          <div className="font-bold text-zinc-900">Partner Applications</div>
        </div>
      </header>

      <div className="px-3 pt-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          {["Pending","Approved","Rejected"].map((t) => (
            <button key={t} onClick={() => setTab(t)} data-testid={`admin-tab-${t.toLowerCase()}`}
                    className={`px-4 py-1.5 rounded-full text-[13px] font-semibold whitespace-nowrap ${
                      tab === t ? "bg-zinc-900 text-white" : "bg-white text-zinc-700 border border-zinc-200"
                    }`}>{t}</button>
          ))}
        </div>
      </div>

      <div className="px-4 py-3 space-y-3" data-testid="admin-partners-list">
        {items.length === 0 && <div className="text-center text-sm text-zinc-500 py-10">No {tab.toLowerCase()} applications</div>}
        {items.map((p) => (
          <div key={p.partner_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5" data-testid={`admin-partner-${p.partner_id}`}>
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <div className="font-bold text-zinc-900 truncate">{p.name}</div>
                <div className="text-[12px] text-zinc-500">{p.owner_name} • {p.phone}</div>
                <div className="text-[12px] text-zinc-500">{p.city} • {(p.categories||[]).join(", ")}</div>
                <div className="text-[11px] text-zinc-400 mt-1">{p.documents_count || 0} docs • Applied {p.applied_at ? new Date(p.applied_at).toLocaleDateString() : "—"}</div>
              </div>
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                p.status === "Approved" ? "bg-emerald-50 text-emerald-700" :
                p.status === "Rejected" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"
              }`}>{p.status}</span>
            </div>
            <div className="mt-3 flex gap-2">
              <button onClick={() => open(p.partner_id)} data-testid={`admin-view-${p.partner_id}`}
                      className="flex-1 bg-zinc-100 text-zinc-900 font-semibold py-2 rounded-xl text-sm btn-press flex items-center justify-center gap-1.5">
                <Eye className="w-4 h-4" /> View
              </button>
              {p.status === "Pending" && (
                <>
                  <button onClick={() => approve(p.partner_id)} data-testid={`admin-approve-${p.partner_id}`}
                          className="flex-1 bg-emerald-600 text-white font-semibold py-2 rounded-xl text-sm btn-press flex items-center justify-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" /> Approve
                  </button>
                  <button onClick={() => reject(p.partner_id)} data-testid={`admin-reject-${p.partner_id}`}
                          className="flex-1 bg-red-600 text-white font-semibold py-2 rounded-xl text-sm btn-press flex items-center justify-center gap-1.5">
                    <ShieldX className="w-4 h-4" /> Reject
                  </button>
                </>
              )}
              {p.status === "Approved" && (
                <>
                  <button onClick={() => seedDemo(p.partner_id)} data-testid={`admin-seed-${p.partner_id}`}
                          className="flex-1 bg-amber-500 text-white font-semibold py-2 rounded-xl text-sm btn-press">
                    Seed Demo
                  </button>
                  <button onClick={() => spawnOrder(p.partner_id)} data-testid={`admin-spawn-${p.partner_id}`}
                          className="flex-1 bg-blue-600 text-white font-semibold py-2 rounded-xl text-sm btn-press">
                    Send Test Order
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {detail && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={() => setDetail(null)}>
          <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()} data-testid="admin-detail-modal">
            <div className="flex justify-between items-center mb-3">
              <div className="font-bold text-lg">{detail.name}</div>
              <button onClick={() => setDetail(null)}><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-2 text-sm">
              <Row k="Owner" v={detail.owner_name} />
              <Row k="Phone" v={detail.phone} />
              <Row k="Email" v={detail.email || "—"} />
              <Row k="Address" v={`${detail.address}, ${detail.city} - ${detail.pincode}`} />
              <Row k="Hours" v={detail.working_hours} />
              <Row k="Categories" v={(detail.categories||[]).join(", ")} />
              <Row k="GST" v={detail.gst_number || "—"} />
              <Row k="PAN" v={detail.pan_number || "—"} />
              <Row k="Aadhaar" v={detail.aadhaar_number || "—"} />
            </div>
            <div className="mt-4">
              <div className="font-semibold mb-2">Documents</div>
              {docs.length === 0 && <div className="text-[12px] text-zinc-500">No documents</div>}
              {docs.map((d) => (
                <div key={d.doc_type} className="bg-zinc-50 rounded-xl px-3 py-2 mb-1.5 text-sm flex justify-between">
                  <span className="font-medium">{d.doc_type}</span>
                  <span className="text-zinc-600">{d.number || "—"}</span>
                </div>
              ))}
            </div>
            {detail.status === "Pending" && (
              <div className="mt-5 flex gap-2">
                <button onClick={() => reject(detail.partner_id)} data-testid="modal-reject" className="flex-1 bg-red-600 text-white font-semibold py-3 rounded-xl">Reject</button>
                <button onClick={() => approve(detail.partner_id)} data-testid="modal-approve" className="flex-1 bg-emerald-600 text-white font-semibold py-3 rounded-xl">Approve</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const Row = ({ k, v }) => (
  <div className="flex justify-between gap-3 border-b border-zinc-100 pb-1.5">
    <span className="text-zinc-500">{k}</span>
    <span className="text-zinc-900 font-medium text-right">{v}</span>
  </div>
);
