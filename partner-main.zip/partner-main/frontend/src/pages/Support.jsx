import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Send, Plus, MessageCircle } from "lucide-react";

export default function Support() {
  const toast = useToast();
  const [tickets, setTickets] = useState([]);
  const [form, setForm] = useState({ subject: "", message: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const r = await api.get("/partner/support");
      setTickets(r.data.items || []);
    } catch (e) { /* ignore */ }
  };

  const submit = async () => {
    if (!form.subject || !form.message) return toast.error("Fill subject and message");
    setBusy(true);
    try {
      await api.post("/partner/support", form);
      toast.success("Ticket raised", "We'll get back within 24h");
      setForm({ subject: "", message: "" });
      load();
    } catch { toast.error("Failed"); } setBusy(false);
  };

  return (
    <>
      <PartnerHeader title="Help & Support" rightAction="menu" showOnline={false} />
      <div className="px-4 py-3">
        <div className="bg-white border border-zinc-200 rounded-2xl p-4" data-testid="new-ticket">
          <div className="font-bold text-zinc-900 mb-2 flex items-center gap-2">
            <MessageCircle className="w-4 h-4" /> Raise a ticket
          </div>
          <input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}
                 placeholder="Subject" data-testid="ticket-subject"
                 className="w-full border-2 border-zinc-200 rounded-xl px-3.5 py-2.5 outline-none focus:border-zinc-900 text-sm" />
          <textarea rows={3} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Describe your issue..." data-testid="ticket-message"
                    className="mt-2 w-full border-2 border-zinc-200 rounded-xl px-3.5 py-2.5 outline-none focus:border-zinc-900 text-sm resize-none" />
          <button onClick={submit} disabled={busy} data-testid="ticket-submit"
                  className="mt-2 w-full bg-zinc-900 text-white font-semibold py-2.5 rounded-xl btn-press disabled:opacity-50 flex items-center justify-center gap-1.5">
            <Send className="w-4 h-4" /> {busy ? "Submitting..." : "Submit"}
          </button>
        </div>

        <div className="mt-5">
          <div className="font-bold text-zinc-900 text-[15px] mb-2">Your tickets</div>
          <div className="space-y-2" data-testid="tickets-list">
            {tickets.length === 0 && <div className="text-center text-sm text-zinc-500 py-6">No tickets yet</div>}
            {tickets.map((t) => (
              <div key={t.ticket_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5" data-testid={`ticket-${t.ticket_id}`}>
                <div className="flex justify-between">
                  <div className="font-semibold text-zinc-900">{t.subject}</div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    t.status === "Open" ? "bg-amber-50 text-amber-700" : "bg-emerald-50 text-emerald-700"
                  }`}>{t.status}</span>
                </div>
                <div className="text-[12px] text-zinc-600 mt-1">{t.message}</div>
                <div className="text-[11px] text-zinc-400 mt-1.5">{new Date(t.created_at).toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
