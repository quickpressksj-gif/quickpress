import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Briefcase, ClipboardList, MessageSquare, AlertCircle, Star, BarChart3, IndianRupee, FileText, LifeBuoy, Image, Wand2, Wifi, WifiOff } from "lucide-react";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/components/ZomatoToast";
import { useSocket } from "@/context/SocketContext";

const TABS = ["My Feed", "Sales", "Funnel", "Service quality", "Kitchen"];

const ALERT_ICONS = {
  new_order: { icon: ClipboardList, bg: "bg-red-50", color: "text-red-700", to: "/orders" },
  processing_pending: { icon: AlertCircle, bg: "bg-amber-50", color: "text-amber-700", to: "/orders" },
  ready_for_pickup: { icon: Briefcase, bg: "bg-blue-50", color: "text-blue-700", to: "/orders" },
  low_rating: { icon: Star, bg: "bg-purple-50", color: "text-purple-700", to: "/reviews" },
  settlement: { icon: IndianRupee, bg: "bg-emerald-50", color: "text-emerald-700", to: "/finance" },
  payout: { icon: IndianRupee, bg: "bg-emerald-50", color: "text-emerald-700", to: "/finance" },
};

export default function Hub() {
  const { user } = useAuth();
  const toast = useToast();
  const { connected, lastEvent } = useSocket();
  const [dash, setDash] = useState(null);
  const [tab, setTab] = useState("My Feed");
  const [loading, setLoading] = useState(true);
  const [alerts, setAlerts] = useState([]);

  useEffect(() => { load(); }, []);
  // refresh when realtime events fire
  useEffect(() => { if (lastEvent) load(); }, [lastEvent?._ts]);

  const load = async () => {
    try {
      const [d, a] = await Promise.all([
        api.get("/partner/dashboard"),
        api.get("/partner/alerts"),
      ]);
      setDash(d.data);
      setAlerts(a.data?.items || []);
    } catch (e) { /* not approved yet */ }
    setLoading(false);
  };

  return (
    <>
      <PartnerHeader />
      <div className="px-3 pt-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              data-testid={`hub-tab-${t.replace(/\s+/g,"-").toLowerCase()}`}
              className={`px-4 py-1.5 rounded-full text-[13px] font-semibold whitespace-nowrap btn-press ${
                tab === t ? "bg-zinc-900 text-white" : "bg-white text-zinc-700 border border-zinc-200"
              }`}
            >{t}</button>
          ))}
        </div>
      </div>

      <div className="px-4 py-3 space-y-4">
        {/* Realtime alerts (Zomato-style alert strip) */}
        {alerts.length > 0 && (
          <div className="space-y-2" data-testid="hub-alerts">
            <div className="flex items-center justify-between">
              <div className="text-[12px] uppercase tracking-wider font-bold text-zinc-500">Alerts</div>
              <div className={`text-[10px] font-semibold flex items-center gap-1 ${connected ? "text-emerald-600" : "text-zinc-400"}`}>
                {connected ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                {connected ? "Live" : "Polling"}
              </div>
            </div>
            <div className="space-y-2">
              {alerts.slice(0, 5).map((a, i) => {
                const cfg = ALERT_ICONS[a.kind] || { icon: AlertCircle, bg: "bg-zinc-50", color: "text-zinc-700", to: "/" };
                const Icon = cfg.icon;
                return (
                  <Link to={cfg.to} key={i} data-testid={`alert-${a.kind}`}
                        className={`flex items-center gap-3 ${cfg.bg} border border-zinc-100 rounded-2xl px-3.5 py-2.5 btn-press`}>
                    <div className={`w-9 h-9 rounded-xl bg-white grid place-items-center ${cfg.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-zinc-900 text-[13px] truncate">{a.title}</div>
                      <div className="text-[11px] text-zinc-600 truncate">{a.body}</div>
                    </div>
                    <span className={`w-1.5 h-1.5 rounded-full ${a.severity === "high" ? "bg-red-500 pulse-dot" : a.severity === "medium" ? "bg-amber-500" : "bg-emerald-500"}`} />
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* Promo banner */}
        <div className="rounded-2xl bg-gradient-to-br from-blue-900 to-indigo-900 p-4 text-white relative overflow-hidden">
          <div className="text-[18px] font-bold leading-tight max-w-[68%]">Boost orders with QuickPress Ads</div>
          <div className="text-[12px] text-blue-100 mt-1 max-w-[60%]">Get seen by more customers and grow your store.</div>
          <Link to="/growth" className="inline-block mt-3 bg-white text-zinc-900 text-[12px] font-semibold px-3 py-1.5 rounded-full" data-testid="hub-promo-cta">
            <Wand2 className="w-3.5 h-3.5 inline mr-1" /> Launch a campaign
          </Link>
          <div className="absolute -right-4 -bottom-4 w-32 h-32 rounded-full bg-white/10" />
          <div className="absolute right-6 top-3 w-12 h-12 rounded-full bg-white/10" />
        </div>

        {/* Today so far */}
        <div>
          <div className="font-bold text-zinc-900 text-[16px] mb-2">Today so far</div>
          <div className="bg-white border border-zinc-200 rounded-2xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-zinc-500 text-[12px]">Total sales</div>
                <div className="text-[26px] font-bold mt-0.5">{loading ? "…" : fmtMoney(dash?.today_revenue || 0)}</div>
              </div>
              <div>
                <div className="text-zinc-500 text-[12px]">Total orders</div>
                <div className="text-[26px] font-bold mt-0.5">{loading ? "…" : (dash?.today_orders || 0)}</div>
              </div>
              <div className="bg-emerald-50 text-emerald-700 text-[11px] font-semibold px-2 py-1 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-dot" /> Live
              </div>
            </div>
            <div className="mt-3 h-20 relative">
              <div className="absolute inset-x-0 bottom-0 h-px bg-zinc-200" />
              <div className="absolute inset-x-0 bottom-0 flex items-end gap-1 h-full">
                {Array.from({length: 24}).map((_, i) => (
                  <div key={i} style={{height: `${Math.abs(Math.sin(i/2)) * (dash?.today_orders ? 70 : 8) + 4}%`}} className="flex-1 bg-zinc-900 rounded-sm opacity-90" />
                ))}
              </div>
            </div>
            <div className="flex justify-between text-[10px] text-zinc-400 mt-1">
              <span>12am</span><span>6am</span><span>12pm</span><span>6pm</span><span>11pm</span>
            </div>
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 gap-3">
          <Kpi label="Active" value={dash?.active_orders ?? 0} icon={ClipboardList} testid="kpi-active" />
          <Kpi label="Completed" value={dash?.completed_orders ?? 0} icon={Briefcase} testid="kpi-completed" />
          <Kpi label="Rating" value={(dash?.rating ?? 0).toFixed(1)} icon={Star} subtext={`${dash?.reviews_count || 0} reviews`} testid="kpi-rating" />
          <Kpi label="Acceptance" value={`${dash?.acceptance_rate ?? 100}%`} icon={BarChart3} testid="kpi-acc" />
        </div>

        {/* Quick links */}
        <div>
          <div className="font-bold text-zinc-900 text-[16px] mb-2">Quick links</div>
          <div className="grid grid-cols-4 gap-2">
            {[
              { to: "/growth", label: "Ads", icon: Wand2, tid: "ql-ads" },
              { to: "/orders", label: "Orders", icon: ClipboardList, tid: "ql-orders" },
              { to: "/support", label: "Chat", icon: MessageSquare, tid: "ql-chat" },
              { to: "/reviews", label: "Reviews", icon: Star, tid: "ql-reviews" },
              { to: "/reports", label: "Reports", icon: FileText, tid: "ql-reports" },
              { to: "/finance", label: "Payouts", icon: IndianRupee, tid: "ql-payouts" },
              { to: "/store", label: "Gallery", icon: Image, tid: "ql-gallery" },
              { to: "/support", label: "Help", icon: LifeBuoy, tid: "ql-help" },
            ].map((q) => (
              <Link key={q.label} to={q.to} data-testid={q.tid} className="bg-white border border-zinc-200 rounded-xl p-2.5 flex flex-col items-center gap-1 btn-press">
                <q.icon className="w-5 h-5 text-zinc-900" />
                <div className="text-[11px] font-medium text-zinc-700 text-center leading-tight">{q.label}</div>
              </Link>
            ))}
          </div>
        </div>

        {/* Empty-state hint (no partner-side seeding) */}
        {dash && dash.today_orders === 0 && dash.completed_orders === 0 && (
          <div data-testid="hub-empty-hint" className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3.5 text-center text-[12px] text-zinc-600">
            No live data yet. Toggle <span className="font-semibold text-zinc-900">Online</span> from header to start receiving orders.
          </div>
        )}
      </div>
    </>
  );
}

const Kpi = ({ label, value, icon: Icon, subtext, testid }) => (
  <div data-testid={testid} className="bg-white border border-zinc-200 rounded-2xl p-3.5">
    <div className="flex items-center justify-between">
      <div className="text-[12px] text-zinc-500">{label}</div>
      <Icon className="w-4 h-4 text-zinc-400" />
    </div>
    <div className="text-[22px] font-bold mt-1">{value}</div>
    {subtext && <div className="text-[11px] text-zinc-400 mt-0.5">{subtext}</div>}
  </div>
);
