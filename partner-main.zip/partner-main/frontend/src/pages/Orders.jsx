import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { useSocket } from "@/context/SocketContext";
import { Check, X, Truck, PackageCheck, ChefHat, PackageOpen, MapPin, Phone, Store, ChevronRight } from "lucide-react";

const TABS = [
  { id: "new",        label: "New" },
  { id: "accepted",   label: "Accepted" },
  { id: "processing", label: "Processing" },
  { id: "ready",      label: "Ready" },
  { id: "completed",  label: "Completed" },
  { id: "cancelled",  label: "Cancelled" },
];

export default function Orders() {
  const toast = useToast();
  const { on: onSocket, lastEvent } = useSocket();
  const [tab, setTab] = useState("new");
  const [items, setItems] = useState([]);
  const [busy, setBusy] = useState({});

  useEffect(() => { load(); }, [tab]);

  // Refresh list when a realtime event fires
  useEffect(() => {
    if (!lastEvent) return;
    load();
  }, [lastEvent?._ts]);

  const load = async () => {
    try {
      const r = await api.get(`/partner/orders?tab=${tab}`);
      setItems(r.data.items || []);
    } catch (e) { setItems([]); }
  };

  const act = async (orderId, action, msg) => {
    setBusy((b) => ({ ...b, [orderId]: true }));
    try {
      await api.post(`/partner/orders/${orderId}/${action}`);
      toast.success(msg || "Updated");
      load();
    } catch (e) { toast.error("Action failed", e.response?.data?.detail || ""); }
    setBusy((b) => ({ ...b, [orderId]: false }));
  };

  return (
    <>
      <PartnerHeader title="To Orders" rightAction="search" showOnline />
      <div className="px-3 pt-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              data-testid={`orders-tab-${t.id}`}
              className={`px-4 py-1.5 rounded-full text-[13px] font-semibold whitespace-nowrap btn-press ${
                tab === t.id ? "bg-zinc-900 text-white" : "bg-white text-zinc-700 border border-zinc-200"
              }`}
            >{t.label}</button>
          ))}
        </div>
      </div>

      <div className="px-4 py-3 space-y-3" data-testid="orders-list">
        {items.length === 0 && (
          <div className="text-center py-16">
            <div className="w-28 h-28 rounded-full bg-zinc-100 mx-auto grid place-items-center">
              <Store className="w-12 h-12 text-zinc-400" />
            </div>
            <div className="mt-4 font-semibold text-zinc-700">No {TABS.find((t)=>t.id===tab)?.label?.toLowerCase()} orders</div>
            <div className="text-[12px] text-zinc-500 mt-1">Orders will appear here in real-time</div>
          </div>
        )}

        {items.map((o) => (
          <Link key={o.order_id} to={`/orders/${o.order_id}`} className="block bg-white border border-zinc-200 rounded-2xl p-4 btn-press" data-testid={`order-card-${o.order_id}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="text-[11px] text-zinc-500 font-mono">#{o.order_id.replace("ord_","").toUpperCase().slice(0,8)}</div>
                <div className="font-bold text-zinc-900 mt-0.5">{o.user_name || "Customer"} • {fmtMoney(o.total)}</div>
                <div className="text-[12px] text-zinc-500 mt-0.5">{o.items?.length || 0} item(s) • {o.payment_method} • {new Date(o.created_at).toLocaleString()}</div>
              </div>
              <ChevronRight className="w-4 h-4 text-zinc-400 mt-1" />
            </div>

            <div className="mt-2 flex items-center gap-2 text-[12px] text-zinc-600">
              <MapPin className="w-3.5 h-3.5" />
              <span className="truncate">{o.address?.line1}, {o.address?.city}</span>
            </div>

            <div className="mt-2 flex items-center justify-between">
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                o.status === "Cancelled" ? "bg-red-50 text-red-700" :
                o.status === "Delivered" ? "bg-emerald-50 text-emerald-700" :
                o.status === "Ready For Pickup" ? "bg-blue-50 text-blue-700" :
                "bg-zinc-100 text-zinc-700"
              }`}>{o.status}</span>
              <span className="text-[12px] text-blue-600 font-semibold">Open →</span>
            </div>

            {tab === "new" && (
              <div className="mt-3 flex gap-2" onClick={(e) => e.preventDefault()}>
                <button onClick={(e) => { e.preventDefault(); act(o.order_id, "reject", "Order rejected"); }}
                        disabled={busy[o.order_id]}
                        data-testid={`reject-${o.order_id}`}
                        className="flex-1 py-2.5 rounded-xl bg-zinc-100 text-red-600 font-semibold flex items-center justify-center gap-1.5 btn-press disabled:opacity-50">
                  <X className="w-4 h-4" /> Reject
                </button>
                <button onClick={(e) => { e.preventDefault(); act(o.order_id, "accept", "Order accepted"); }}
                        disabled={busy[o.order_id]}
                        data-testid={`accept-${o.order_id}`}
                        className="flex-1 py-2.5 rounded-xl bg-zinc-900 text-white font-semibold flex items-center justify-center gap-1.5 btn-press disabled:opacity-50">
                  <Check className="w-4 h-4" /> Accept
                </button>
              </div>
            )}
          </Link>
        ))}
      </div>
    </>
  );
}
