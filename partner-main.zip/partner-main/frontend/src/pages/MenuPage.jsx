import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Plus, Trash2, Edit2, Save, X } from "lucide-react";

const CATS = ["laundry", "dry-cleaning", "ironing", "premium-laundry", "express", "shoe-cleaning"];

export default function MenuPage() {
  const toast = useToast();
  const [tab, setTab] = useState("services");
  const [services, setServices] = useState([]);
  const [pricing, setPricing] = useState(null);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const [s, p] = await Promise.all([api.get("/partner/services"), api.get("/partner/pricing")]);
      setServices(s.data.items || []);
      setPricing(p.data || {});
    } catch (e) {}
  };

  const updatePricing = async (key, val) => {
    const next = { ...pricing, [key]: parseFloat(val) || 0 };
    setPricing(next);
    try {
      await api.patch("/partner/pricing", { [key]: next[key] });
    } catch (e) { toast.error("Could not save pricing"); }
  };

  const delService = async (sid) => {
    await api.delete(`/partner/services/${sid}`);
    toast.success("Service removed");
    load();
  };
  const toggleEnable = async (s) => {
    await api.patch(`/partner/services/${s.service_id}`, { enabled: !s.enabled });
    load();
  };

  return (
    <>
      <PartnerHeader title="Menu" rightAction="search" showOnline />
      <div className="px-3 pt-3">
        <div className="bg-zinc-100 rounded-full p-1 flex">
          {["services", "pricing"].map((t) => (
            <button key={t} onClick={() => setTab(t)} data-testid={`menu-tab-${t}`}
                    className={`flex-1 py-1.5 rounded-full text-[13px] font-semibold capitalize ${
                      tab === t ? "bg-white text-zinc-900 shadow" : "text-zinc-600"
                    }`}>{t}</button>
          ))}
        </div>
      </div>

      {tab === "services" && (
        <div className="px-4 py-3 space-y-3" data-testid="services-list">
          {services.length === 0 && (
            <div className="text-center py-10 text-zinc-500 text-sm">No services yet. Add your first service below.</div>
          )}
          {services.map((s) => (
            <div key={s.service_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex items-center gap-3" data-testid={`service-${s.service_id}`}>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-zinc-900 truncate">{s.name}</div>
                <div className="text-[12px] text-zinc-500 mt-0.5">{s.category} • per {s.unit} • {fmtMoney(s.price)}</div>
              </div>
              <button onClick={() => toggleEnable(s)} data-testid={`svc-toggle-${s.service_id}`}
                      className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${
                        s.enabled ? "bg-emerald-50 text-emerald-700" : "bg-zinc-100 text-zinc-500"
                      }`}>
                {s.enabled ? "On" : "Off"}
              </button>
              <button onClick={() => delService(s.service_id)} data-testid={`svc-del-${s.service_id}`}
                      className="p-1.5 text-red-500 btn-press">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}

          <button onClick={() => setShowAdd(true)} data-testid="add-service-btn"
                  className="w-full border-2 border-dashed border-zinc-300 rounded-2xl py-3 text-zinc-700 font-semibold flex items-center justify-center gap-2 btn-press">
            <Plus className="w-4 h-4" /> Add new service
          </button>
        </div>
      )}

      {tab === "pricing" && pricing && (
        <div className="px-4 py-3 space-y-3" data-testid="pricing-list">
          {[
            ["laundry_price", "Laundry (per kg)"],
            ["dry_cleaning_price", "Dry cleaning (per piece)"],
            ["ironing_price", "Ironing (per piece)"],
            ["express_charges", "Express surcharge"],
            ["pickup_charges", "Pickup charge"],
            ["delivery_charges", "Delivery charge"],
            ["urgent_charges", "Urgent (6hr) charge"],
          ].map(([k, label]) => (
            <div key={k} className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex items-center justify-between" data-testid={`pricing-row-${k}`}>
              <div className="text-zinc-700 font-medium">{label}</div>
              <div className="flex items-center gap-1.5 border border-zinc-200 rounded-xl px-3 py-1.5 bg-zinc-50">
                <span className="text-zinc-500 text-sm">₹</span>
                <input
                  type="number" min="0"
                  value={pricing[k] ?? 0}
                  onChange={(e) => updatePricing(k, e.target.value)}
                  data-testid={`pricing-input-${k}`}
                  className="w-20 bg-transparent outline-none text-right font-semibold"
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {showAdd && <AddServiceModal onClose={() => setShowAdd(false)} onAdded={() => { setShowAdd(false); load(); }} />}
    </>
  );
}

function AddServiceModal({ onClose, onAdded }) {
  const toast = useToast();
  const [form, setForm] = useState({ name: "", category: "laundry", price: "", unit: "piece", enabled: true });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!form.name || !form.price) return toast.error("Fill name and price");
    setBusy(true);
    try {
      await api.post("/partner/services", { ...form, price: parseFloat(form.price) });
      toast.success("Service added");
      onAdded();
    } catch { toast.error("Failed"); }
    setBusy(false);
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8" onClick={(e) => e.stopPropagation()} data-testid="add-service-modal">
        <div className="flex justify-between items-center mb-3">
          <div className="font-bold text-lg">Add service</div>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-3">
          <input placeholder="Service name (e.g. Shirt Wash)" value={form.name}
                 onChange={(e) => setForm({ ...form, name: e.target.value })}
                 data-testid="addsvc-name"
                 className="w-full border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none focus:border-zinc-900" />
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  data-testid="addsvc-cat"
                  className="w-full border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none focus:border-zinc-900 bg-white">
            {CATS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <div className="flex gap-3">
            <input type="number" placeholder="Price" value={form.price}
                   onChange={(e) => setForm({ ...form, price: e.target.value })}
                   data-testid="addsvc-price"
                   className="flex-1 border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none focus:border-zinc-900" />
            <select value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    data-testid="addsvc-unit"
                    className="w-32 border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none bg-white">
              <option value="piece">piece</option>
              <option value="kg">kg</option>
            </select>
          </div>
          <button onClick={save} disabled={busy} data-testid="addsvc-save"
                  className="w-full bg-zinc-900 text-white font-semibold py-3 rounded-2xl btn-press">
            {busy ? "Saving..." : "Save service"}
          </button>
        </div>
      </div>
    </div>
  );
}
