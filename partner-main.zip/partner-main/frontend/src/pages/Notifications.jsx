import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Bell } from "lucide-react";
import { api } from "@/api";

export default function Notifications() {
  const [items, setItems] = useState([]);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const r = await api.get("/partner/notifications");
      setItems(r.data.items || []);
    } catch (e) {}
  };

  return (
    <div className="app-shell min-h-screen bg-white">
      <header className="sticky top-0 bg-white border-b border-zinc-100 px-4 py-3 flex items-center gap-3 z-30">
        <Link to=".." className="p-2 -ml-2 btn-press" data-testid="notif-back"><ArrowLeft className="w-5 h-5" /></Link>
        <div className="font-bold text-zinc-900">Notifications</div>
      </header>
      <div className="px-4 py-3 space-y-2" data-testid="notifications-list">
        {items.length === 0 && (
          <div className="text-center py-16">
            <Bell className="w-12 h-12 text-zinc-300 mx-auto" />
            <div className="mt-3 text-zinc-500 text-sm">No notifications yet</div>
          </div>
        )}
        {items.map((n) => (
          <div key={n.notif_id} className={`rounded-2xl p-3.5 border ${n.read ? "bg-white border-zinc-200" : "bg-amber-50 border-amber-200"}`} data-testid={`notif-${n.notif_id}`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-zinc-900 text-white grid place-items-center"><Bell className="w-4 h-4" /></div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-zinc-900">{n.title}</div>
                <div className="text-[13px] text-zinc-600 mt-0.5">{n.body}</div>
                <div className="text-[11px] text-zinc-400 mt-1">{new Date(n.created_at).toLocaleString()}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
