import React, { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Check, X, ChefHat, PackageCheck, Truck, MapPin, Phone, ShieldCheck, Clock, History } from "lucide-react";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import ImageUploader from "@/components/ImageUploader";

const TIMELINE_STEPS = [
  { id: "Order Accepted",         match: ["Accepted By Partner", "Partner Assigned"] },
  { id: "Processing Started",     match: ["Processing Started", "Processing"] },
  { id: "Processing Completed",   match: ["Processing Completed"] },
  { id: "Quality Check Completed", match: ["Quality Check Completed"], synthetic: true },
  { id: "Ready For Pickup",       match: ["Ready For Pickup", "Ready", "Out For Delivery", "Delivered"] },
];

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { load(); }, [id]);
  const load = async () => {
    try {
      const r = await api.get(`/partner/orders/${id}`);
      setData(r.data);
    } catch (e) { toast.error("Order not found"); navigate(-1); }
  };

  const o = data?.order;
  const audit = data?.audit_logs || [];

  const stepReached = useMemo(() => {
    if (!o) return new Set();
    const reached = new Set();
    const seen = new Set([o.status, ...(o.timeline || []).map((t) => t.status)]);
    TIMELINE_STEPS.forEach((s) => {
      if (s.match.some((m) => seen.has(m))) reached.add(s.id);
    });
    // Synthetic: Quality Check Completed when both QC + Packed images present
    const qc = (o.quality_check_images || []).length;
    const pk = (o.packed_clothes_images || []).length;
    if (qc >= 2 && pk >= 2) reached.add("Quality Check Completed");
    return reached;
  }, [o]);

  const uploadImages = async (category, images) => {
    try {
      await api.post(`/partner/orders/${id}/upload-images`, { category, images });
      toast.success("Photos uploaded", `${images.length} image(s) added to ${category.replace("_"," ")}`);
      load();
    } catch (e) { toast.error("Upload failed", e.response?.data?.detail || ""); }
  };

  const callAction = async (action, successMsg) => {
    setBusy(true);
    try {
      await api.post(`/partner/orders/${id}/${action}`);
      toast.success(successMsg);
      load();
    } catch (e) {
      toast.error("Action blocked", e.response?.data?.detail || "");
    }
    setBusy(false);
  };

  if (!o) return (
    <div className="app-shell min-h-screen bg-zinc-100 grid place-items-center"><div className="text-zinc-500">Loading…</div></div>
  );

  const status = o.status;
  const qcCount = (o.quality_check_images || []).length;
  const pkCount = (o.packed_clothes_images || []).length;
  const canMarkReady = qcCount >= 2 && pkCount >= 2;

  return (
    <div className="app-shell min-h-screen bg-zinc-100 pb-28" data-testid="order-detail">
      <header className="sticky top-0 z-30 bg-white border-b border-zinc-100 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 btn-press" data-testid="order-back"><ArrowLeft className="w-5 h-5" /></button>
        <div className="flex-1 min-w-0">
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">Order</div>
          <div className="font-bold text-zinc-900 truncate font-mono text-sm">#{o.order_id.replace("ord_","").toUpperCase()}</div>
        </div>
        <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full whitespace-nowrap ${
          status === "Cancelled" ? "bg-red-50 text-red-700" :
          status === "Delivered" ? "bg-emerald-50 text-emerald-700" :
          status === "Ready For Pickup" ? "bg-blue-50 text-blue-700" :
          "bg-amber-50 text-amber-700"
        }`} data-testid="order-status-pill">{status}</span>
      </header>

      <div className="p-3 space-y-3">
        {/* Customer + items card */}
        <div className="bg-white rounded-2xl p-4">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-[11px] text-zinc-500 uppercase">Customer</div>
              <div className="font-semibold text-zinc-900">{o.user_name || "Customer"}</div>
              <div className="text-[12px] text-zinc-500 flex items-center gap-1 mt-0.5">
                <Phone className="w-3.5 h-3.5" /> {o.user_phone || "—"}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-zinc-500 uppercase">Total</div>
              <div className="text-[20px] font-bold">{fmtMoney(o.total)}</div>
              <div className="text-[11px] text-zinc-500">{o.payment_method}</div>
            </div>
          </div>
          <div className="mt-3 border-t border-dashed border-zinc-200 pt-2">
            {o.items?.map((it, i) => (
              <div key={i} className="flex justify-between text-[13px]"><span>{it.qty}× {it.name}</span><span className="font-semibold">{fmtMoney(it.price * it.qty)}</span></div>
            ))}
          </div>
          <div className="mt-3 flex items-start gap-2 text-[12px] text-zinc-600">
            <MapPin className="w-3.5 h-3.5 mt-0.5" />
            <span>{o.address?.line1}, {o.address?.city} - {o.address?.pincode}</span>
          </div>
        </div>

        {/* Action buttons based on status */}
        {status === "Order Created" && (
          <div className="bg-white rounded-2xl p-4">
            <div className="font-bold mb-2">Respond to this order</div>
            <div className="flex gap-2">
              <button disabled={busy} onClick={() => callAction("reject", "Order rejected")}
                      data-testid="action-reject"
                      className="flex-1 py-3 rounded-xl bg-zinc-100 text-red-600 font-bold btn-press disabled:opacity-50">
                <X className="w-4 h-4 inline mr-1" /> Reject
              </button>
              <button disabled={busy} onClick={() => callAction("accept", "Order accepted")}
                      data-testid="action-accept"
                      className="flex-[2] py-3 rounded-xl bg-emerald-600 text-white font-bold btn-press disabled:opacity-50">
                <Check className="w-4 h-4 inline mr-1" /> Accept order
              </button>
            </div>
          </div>
        )}

        {status === "Accepted By Partner" && (
          <button disabled={busy} onClick={() => callAction("start-processing", "Processing started!")}
                  data-testid="action-start-processing"
                  className="w-full py-3.5 rounded-2xl bg-zinc-900 text-white font-bold btn-press disabled:opacity-50 flex items-center justify-center gap-2">
            <ChefHat className="w-4 h-4" /> Start Processing
          </button>
        )}

        {/* Image uploaders – visible from "Processing Started" onwards (and after) */}
        {["Processing Started", "Processing Completed", "Ready For Pickup", "Out For Delivery", "Delivered"].includes(status) && (
          <div className="space-y-3" data-testid="image-workflow">
            <ImageUploader
              label="Before processing"
              category="before_processing"
              required={0}
              current={o.before_processing_images || []}
              onUploaded={uploadImages}
              testid="up-before"
            />
            <ImageUploader
              label="After processing"
              category="after_processing"
              required={0}
              current={o.after_processing_images || []}
              onUploaded={uploadImages}
              testid="up-after"
            />
            {status === "Processing Started" && (
              <button disabled={busy} onClick={() => callAction("complete-processing", "Processing completed")}
                      data-testid="action-complete-processing"
                      className="w-full py-3 rounded-2xl bg-zinc-900 text-white font-semibold btn-press disabled:opacity-50 flex items-center justify-center gap-2">
                <Check className="w-4 h-4" /> Mark processing completed
              </button>
            )}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-[12px] text-amber-900" data-testid="qc-banner">
              <ShieldCheck className="w-4 h-4 inline mr-1" />
              <strong>Quality check (mandatory):</strong> Upload at least <strong>2 processed-clothes</strong> + <strong>2 packed-clothes</strong> images before marking Ready.
            </div>
            <ImageUploader
              label="Processed clothes (Quality Check)"
              category="quality_check"
              required={2}
              current={o.quality_check_images || []}
              onUploaded={uploadImages}
              testid="up-qc"
            />
            <ImageUploader
              label="Packed clothes (Final)"
              category="packed_clothes"
              required={2}
              current={o.packed_clothes_images || []}
              onUploaded={uploadImages}
              testid="up-packed"
            />
            {(status === "Processing Started" || status === "Processing Completed") && (
              <button
                disabled={busy || !canMarkReady}
                onClick={() => callAction("ready", "Marked ready for pickup")}
                data-testid="action-ready"
                className={`w-full py-3.5 rounded-2xl font-bold btn-press flex items-center justify-center gap-2 ${
                  canMarkReady ? "bg-emerald-600 text-white shadow-lg shadow-emerald-200" : "bg-zinc-200 text-zinc-500"
                }`}
              >
                <PackageCheck className="w-4 h-4" /> Mark Ready For Pickup
                {!canMarkReady && <span className="text-[11px] font-medium">({qcCount}/2 QC, {pkCount}/2 packed)</span>}
              </button>
            )}
            {status === "Ready For Pickup" && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 text-emerald-900 text-sm font-semibold text-center" data-testid="ready-confirm">
                <PackageCheck className="w-4 h-4 inline mr-1" /> Ready for pickup at {new Date(o.ready_for_pickup_at || Date.now()).toLocaleString()}
              </div>
            )}
          </div>
        )}

        {/* Timeline */}
        <div className="bg-white rounded-2xl p-4" data-testid="order-timeline">
          <div className="font-bold mb-3 flex items-center gap-2"><Clock className="w-4 h-4" /> Order timeline</div>
          <div className="relative pl-6">
            <div className="absolute left-2 top-1 bottom-1 w-px bg-zinc-200" />
            {TIMELINE_STEPS.map((step, idx) => {
              const reached = stepReached.has(step.id);
              const at = (o.timeline || []).find((t) => step.match.includes(t.status))?.at;
              return (
                <div key={step.id} className="relative pb-4 last:pb-0" data-testid={`step-${step.id.replace(/\s+/g,"-").toLowerCase()}`}>
                  <div className={`absolute -left-[14px] top-0 w-3.5 h-3.5 rounded-full border-2 ${
                    reached ? "bg-emerald-500 border-emerald-500" : "bg-white border-zinc-300"
                  }`} />
                  <div className={`font-semibold text-sm ${reached ? "text-zinc-900" : "text-zinc-400"}`}>{step.id}</div>
                  {reached && at && <div className="text-[11px] text-zinc-500">{new Date(at).toLocaleString()}</div>}
                </div>
              );
            })}
          </div>
        </div>

        {/* Audit log */}
        <details className="bg-white rounded-2xl p-4" data-testid="audit-logs">
          <summary className="font-bold cursor-pointer flex items-center gap-2"><History className="w-4 h-4" /> Audit log ({audit.length})</summary>
          <div className="mt-3 space-y-1.5 max-h-72 overflow-y-auto">
            {audit.length === 0 && <div className="text-[12px] text-zinc-500">No actions yet</div>}
            {audit.map((a) => (
              <div key={a.audit_id} className="text-[12px] flex items-start gap-2 border-b border-zinc-50 pb-1.5 last:border-0">
                <div className="w-1.5 h-1.5 rounded-full bg-zinc-300 mt-1.5" />
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-zinc-800">{a.action}</div>
                  <div className="text-[10px] text-zinc-500">{new Date(a.at).toLocaleString()} • {a.audit_id}</div>
                  {a.meta && Object.keys(a.meta).length > 0 && (
                    <div className="text-[11px] text-zinc-600 mt-0.5">{Object.entries(a.meta).map(([k,v]) => `${k}: ${v}`).join(" · ")}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </details>
      </div>
    </div>
  );
}
