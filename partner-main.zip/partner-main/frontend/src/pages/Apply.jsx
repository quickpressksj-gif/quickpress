import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowRight, ArrowLeft, CheckCircle2, Phone, FileText, Store } from "lucide-react";
import { api, setToken } from "@/api";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/components/ZomatoToast";

const CATEGORIES = [
  { id: "laundry", label: "Laundry" },
  { id: "dry-cleaning", label: "Dry Cleaning" },
  { id: "ironing", label: "Ironing" },
  { id: "premium-laundry", label: "Premium" },
  { id: "express", label: "Express" },
  { id: "shoe-cleaning", label: "Shoe Cleaning" },
  { id: "carpet-cleaning", label: "Carpet" },
  { id: "curtain-cleaning", label: "Curtain" },
  { id: "blanket-cleaning", label: "Blanket" },
];

export default function Apply() {
  const navigate = useNavigate();
  const toast = useToast();
  const { fetchMe } = useAuth();

  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpShown, setOtpShown] = useState("");

  const [form, setForm] = useState({
    phone: "", otp: "",
    owner_name: "", email: "",
    name: "", about: "", address: "", city: "", pincode: "",
    working_hours: "9:00 AM – 9:00 PM",
    categories: ["laundry"],
    gst_number: "", pan_number: "", aadhaar_number: "",
  });

  const upd = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const sendOtp = async () => {
    if (form.phone.length < 10) return toast.error("Enter a 10-digit phone");
    setBusy(true);
    try {
      const r = await api.post("/auth/otp/send", { phone: form.phone });
      setOtpShown(r.data.otp);
      setOtpSent(true);
      toast.info("OTP sent", `Demo OTP: ${r.data.otp}`);
    } catch { toast.error("Could not send OTP"); }
    setBusy(false);
  };

  const verifyAndProceed = async () => {
    if (form.otp.length < 4) return toast.error("Enter the OTP");
    if (!form.owner_name) return toast.error("Enter owner name");
    setBusy(true);
    try {
      const r = await api.post("/auth/otp/verify", {
        phone: form.phone, otp: form.otp, name: form.owner_name, role: "partner",
      });
      setToken(r.data.token);
      toast.success("Verified", "Continue with shop details");
      setStep(2);
    } catch (e) { toast.error("Invalid OTP", e.response?.data?.detail || ""); }
    setBusy(false);
  };

  const toggleCat = (id) => {
    setForm((f) => ({
      ...f,
      categories: f.categories.includes(id)
        ? f.categories.filter((x) => x !== id)
        : [...f.categories, id],
    }));
  };

  const submit = async () => {
    if (!form.name || !form.address || !form.city || !form.pincode) {
      return toast.error("Fill all shop details");
    }
    setBusy(true);
    try {
      const docs = [];
      if (form.gst_number) docs.push({ doc_type: "GST", number: form.gst_number });
      if (form.pan_number) docs.push({ doc_type: "PAN", number: form.pan_number });
      if (form.aadhaar_number) docs.push({ doc_type: "AADHAAR", number: form.aadhaar_number });
      await api.post("/partner/apply", {
        owner_name: form.owner_name,
        phone: form.phone,
        email: form.email || null,
        name: form.name,
        about: form.about,
        address: form.address,
        city: form.city,
        pincode: form.pincode,
        working_hours: form.working_hours,
        categories: form.categories.length ? form.categories : ["laundry"],
        gst_number: form.gst_number || null,
        pan_number: form.pan_number || null,
        aadhaar_number: form.aadhaar_number || null,
        documents: docs,
      });
      await fetchMe();
      toast.success("Application submitted!", "Admin will review your shop within 24 hours");
      navigate("/", { replace: true });
    } catch (e) {
      toast.error("Submission failed", e.response?.data?.detail || "");
    }
    setBusy(false);
  };

  return (
    <div className="app-shell min-h-screen bg-white">
      <header className="sticky top-0 z-30 bg-white border-b border-zinc-100 px-4 py-3 flex items-center gap-3">
        <Link to="/login" className="p-2 -ml-2 btn-press" data-testid="apply-back">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">Become a partner</div>
          <div className="font-bold text-zinc-900">Step {step} of 3</div>
        </div>
        <div className="ml-auto flex items-center gap-1">
          {[1,2,3].map((i) => (
            <div key={i} className={`h-1.5 w-6 rounded-full ${i <= step ? "bg-zinc-900" : "bg-zinc-200"}`} />
          ))}
        </div>
      </header>

      <div className="px-5 pt-5 pb-32">
        {step === 1 && (
          <div data-testid="apply-step-1">
            <div className="flex items-center gap-2 mb-1"><Phone className="w-4 h-4" /><span className="text-[12px] uppercase tracking-wider font-semibold text-zinc-600">Verify Owner</span></div>
            <h1 className="text-[24px] font-bold leading-tight">Your contact details</h1>
            <p className="text-zinc-500 text-[13px] mt-1">We use your phone to log in and reach out for verification.</p>

            <div className="mt-5 space-y-3">
              <Field label="Owner full name" testid="apply-owner-name">
                <input value={form.owner_name} onChange={(e) => upd("owner_name", e.target.value)} placeholder="Aarav Sharma" className="zinp" />
              </Field>
              <Field label="Email (optional)" testid="apply-email">
                <input value={form.email} onChange={(e) => upd("email", e.target.value)} placeholder="you@store.com" className="zinp" />
              </Field>
              <Field label="Phone number" testid="apply-phone">
                <div className="flex items-center gap-2">
                  <span className="text-zinc-600 font-medium">+91</span>
                  <input value={form.phone} disabled={otpSent}
                         onChange={(e) => upd("phone", e.target.value.replace(/\D/g,"").slice(0,10))}
                         placeholder="98765 43210" className="zinp flex-1" />
                  {!otpSent ? (
                    <button onClick={sendOtp} disabled={busy} data-testid="apply-send-otp"
                            className="px-3 py-2 rounded-xl bg-zinc-900 text-white text-sm font-semibold btn-press">
                      Send OTP
                    </button>
                  ) : (
                    <button onClick={() => { setOtpSent(false); upd("otp",""); }} className="text-xs text-zinc-500 underline">Change</button>
                  )}
                </div>
              </Field>
              {otpSent && (
                <Field label={`Enter OTP ${otpShown ? `(demo: ${otpShown})` : ""}`} testid="apply-otp">
                  <input value={form.otp} onChange={(e) => upd("otp", e.target.value.replace(/\D/g,"").slice(0,4))}
                         placeholder="4-digit code" className="zinp tracking-[0.5em] text-center text-lg font-semibold" />
                </Field>
              )}
            </div>

            <button
              onClick={verifyAndProceed} disabled={!otpSent || busy} data-testid="apply-step1-next"
              className="mt-6 w-full bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50 btn-press"
            >
              Verify & continue <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {step === 2 && (
          <div data-testid="apply-step-2">
            <div className="flex items-center gap-2 mb-1"><Store className="w-4 h-4" /><span className="text-[12px] uppercase tracking-wider font-semibold text-zinc-600">Shop details</span></div>
            <h1 className="text-[24px] font-bold leading-tight">Tell us about your shop</h1>
            <p className="text-zinc-500 text-[13px] mt-1">This will appear on QuickPress to your customers.</p>

            <div className="mt-5 space-y-3">
              <Field label="Shop name" testid="apply-shop-name">
                <input value={form.name} onChange={(e) => upd("name", e.target.value)} placeholder="FreshFold Laundry" className="zinp" />
              </Field>
              <Field label="About the shop" testid="apply-about">
                <textarea value={form.about} onChange={(e) => upd("about", e.target.value)} rows={2} placeholder="ISO-certified, eco-friendly..." className="zinp resize-none" />
              </Field>
              <Field label="Full address" testid="apply-address">
                <input value={form.address} onChange={(e) => upd("address", e.target.value)} placeholder="Plot 12, Sector 18" className="zinp" />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="City" testid="apply-city">
                  <input value={form.city} onChange={(e) => upd("city", e.target.value)} placeholder="Noida" className="zinp" />
                </Field>
                <Field label="Pincode" testid="apply-pincode">
                  <input value={form.pincode} onChange={(e) => upd("pincode", e.target.value.replace(/\D/g,"").slice(0,6))} placeholder="201301" className="zinp" />
                </Field>
              </div>
              <Field label="Working hours" testid="apply-hours">
                <input value={form.working_hours} onChange={(e) => upd("working_hours", e.target.value)} className="zinp" />
              </Field>
              <Field label="Service categories" testid="apply-cats">
                <div className="flex flex-wrap gap-2 mt-1">
                  {CATEGORIES.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => toggleCat(c.id)}
                      data-testid={`cat-chip-${c.id}`}
                      className={`px-3 py-1.5 rounded-full border text-[12px] font-medium ${
                        form.categories.includes(c.id)
                          ? "bg-zinc-900 text-white border-zinc-900"
                          : "bg-white text-zinc-700 border-zinc-300"
                      }`}
                    >{c.label}</button>
                  ))}
                </div>
              </Field>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setStep(1)} className="flex-1 bg-zinc-100 text-zinc-900 font-semibold py-3.5 rounded-2xl btn-press" data-testid="apply-step2-back">Back</button>
              <button onClick={() => setStep(3)} className="flex-1 bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl btn-press" data-testid="apply-step2-next">
                Continue
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div data-testid="apply-step-3">
            <div className="flex items-center gap-2 mb-1"><FileText className="w-4 h-4" /><span className="text-[12px] uppercase tracking-wider font-semibold text-zinc-600">KYC & documents</span></div>
            <h1 className="text-[24px] font-bold leading-tight">Verify your documents</h1>
            <p className="text-zinc-500 text-[13px] mt-1">Required for compliant payouts. You can update later.</p>

            <div className="mt-5 space-y-3">
              <Field label="GSTIN" testid="apply-gst">
                <input value={form.gst_number} onChange={(e) => upd("gst_number", e.target.value.toUpperCase())} placeholder="22AAAAA0000A1Z5" className="zinp" />
              </Field>
              <Field label="PAN number" testid="apply-pan">
                <input value={form.pan_number} onChange={(e) => upd("pan_number", e.target.value.toUpperCase())} placeholder="ABCDE1234F" className="zinp" />
              </Field>
              <Field label="Aadhaar (last 4)" testid="apply-aadhaar">
                <input value={form.aadhaar_number} onChange={(e) => upd("aadhaar_number", e.target.value)} placeholder="XXXX-XXXX-1234" className="zinp" />
              </Field>
            </div>

            <div className="mt-5 p-3 rounded-xl bg-amber-50 border border-amber-200 text-[12px] text-amber-900">
              <strong>Next:</strong> Our admin team reviews applications in 24h. You&apos;ll get a notification when approved.
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setStep(2)} className="flex-1 bg-zinc-100 text-zinc-900 font-semibold py-3.5 rounded-2xl btn-press" data-testid="apply-step3-back">Back</button>
              <button onClick={submit} disabled={busy} className="flex-1 bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl btn-press flex items-center justify-center gap-2" data-testid="apply-submit">
                {busy ? "Submitting..." : <><CheckCircle2 className="w-4 h-4" /> Submit application</>}
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .zinp { width: 100%; border: 2px solid #e4e4e7; border-radius: 14px; padding: 12px 14px; outline: none; font-size: 15px; background: white; }
        .zinp:focus { border-color: #0f0f10; }
      `}</style>
    </div>
  );
}

const Field = ({ label, testid, children }) => (
  <label className="block" data-testid={testid}>
    <div className="text-[12px] font-semibold text-zinc-700 mb-1.5">{label}</div>
    {children}
  </label>
);
