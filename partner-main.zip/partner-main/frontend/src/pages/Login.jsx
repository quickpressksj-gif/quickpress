import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Phone, ArrowRight, Sparkles } from "lucide-react";
import { api } from "@/api";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/components/ZomatoToast";

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const toast = useToast();

  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [sentOtp, setSentOtp] = useState("");
  const [stage, setStage] = useState("phone");
  const [busy, setBusy] = useState(false);

  const sendOtp = async () => {
    if (phone.length < 10) return toast.error("Enter a valid phone");
    setBusy(true);
    try {
      const r = await api.post("/auth/otp/send", { phone });
      setSentOtp(r.data.otp);
      setStage("otp");
      toast.info("OTP sent", `Demo OTP: ${r.data.otp}`);
    } catch (e) { toast.error("Failed", "Could not send OTP"); }
    setBusy(false);
  };

  const verify = async () => {
    if (otp.length < 4) return toast.error("Enter the 4-digit OTP");
    setBusy(true);
    try {
      await login(phone, otp, null);
      toast.success("Welcome!", "Logged in to QuickPress Partner");
      navigate("/", { replace: true });
    } catch (e) {
      toast.error("Invalid OTP", e.response?.data?.detail || "Please try again");
    }
    setBusy(false);
  };

  return (
    <div className="app-shell min-h-screen bg-white">
      <div className="px-6 pt-16 pb-8">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 grid place-items-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="text-[22px] font-bold tracking-tight">QuickPress</div>
        </div>
        <div className="mt-1 text-xs text-zinc-500">Partner App</div>
      </div>

      <div className="px-6">
        <h1 className="text-[28px] font-bold text-zinc-900 leading-tight">
          Welcome,<br/>partner
        </h1>
        <p className="text-zinc-500 mt-2 text-[14px]">
          Login with the registered phone number to manage orders, menu, payouts and more.
        </p>

        <div className="mt-8 space-y-3">
          {stage === "phone" ? (
            <>
              <label className="block">
                <div className="text-[12px] font-semibold text-zinc-700 mb-1.5">Phone number</div>
                <div className="flex items-center border-2 border-zinc-200 rounded-2xl px-4 py-3 focus-within:border-zinc-900">
                  <Phone className="w-4 h-4 text-zinc-400 mr-2" />
                  <span className="text-zinc-700 font-medium mr-2">+91</span>
                  <input
                    data-testid="login-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    placeholder="98765 43210"
                    className="flex-1 outline-none text-[16px] bg-transparent"
                  />
                </div>
              </label>
              <button
                onClick={sendOtp}
                disabled={busy}
                data-testid="login-send-otp"
                className="w-full mt-2 bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-60 btn-press"
              >
                {busy ? "Sending..." : "Send OTP"} <ArrowRight className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <label className="block">
                <div className="text-[12px] font-semibold text-zinc-700 mb-1.5">Enter OTP</div>
                <input
                  data-testid="login-otp"
                  type="tel"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  placeholder="4-digit code"
                  className="w-full border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none focus:border-zinc-900 text-[20px] tracking-[0.5em] text-center font-semibold"
                />
                {sentOtp && (
                  <div className="text-[11px] text-zinc-500 mt-1.5 text-center">
                    Demo OTP shown: <span className="font-semibold text-zinc-900">{sentOtp}</span>
                  </div>
                )}
              </label>
              <button
                onClick={verify}
                disabled={busy}
                data-testid="login-verify"
                className="w-full bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-60 btn-press"
              >
                {busy ? "Verifying..." : "Verify & Continue"}
              </button>
              <button
                onClick={() => { setStage("phone"); setOtp(""); }}
                className="w-full text-zinc-500 text-[13px] py-2"
                data-testid="login-change-phone"
              >
                Change phone number
              </button>
            </>
          )}
        </div>

        <div className="mt-10 border-t border-zinc-100 pt-6">
          <div className="text-[13px] text-zinc-600">New here?</div>
          <Link
            to="/apply"
            data-testid="goto-apply"
            className="mt-2 inline-flex items-center gap-1 text-[15px] font-semibold text-zinc-900"
          >
            Become a QuickPress Partner <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="mt-6 text-[11px] text-zinc-400 text-center">
          <Link to="/admin" data-testid="goto-admin" className="underline">Admin console</Link>
        </div>
      </div>
    </div>
  );
}
