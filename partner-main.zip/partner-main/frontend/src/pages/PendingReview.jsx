import React, { useEffect, useState } from "react";
import { Hourglass, XCircle, CheckCircle2, RefreshCw, LogOut } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function PendingReview() {
  const { appStatus, refreshAppStatus, logout } = useAuth();
  const navigate = useNavigate();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setInterval(() => { refreshAppStatus(); }, 6000);
    return () => clearInterval(t);
  }, [refreshAppStatus]);

  const rejected = appStatus?.status === "Rejected";

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshAppStatus();
    setTimeout(() => setRefreshing(false), 400);
  };

  // Explicit redirect when approved (handles first-click race)
  useEffect(() => {
    if (appStatus?.status === "Approved") {
      navigate("/hub", { replace: true });
    }
  }, [appStatus?.status, navigate]);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div className="app-shell min-h-screen bg-white">
      <div className="px-6 pt-20 pb-10 flex flex-col items-center text-center">
        <div className={`w-24 h-24 rounded-full grid place-items-center mb-6 ${
          rejected ? "bg-red-50" : "bg-amber-50"
        }`}>
          {rejected ? <XCircle className="w-12 h-12 text-red-500" /> : <Hourglass className="w-12 h-12 text-amber-500" />}
        </div>
        <h1 className="text-[26px] font-bold text-zinc-900">
          {rejected ? "Application rejected" : "Application under review"}
        </h1>
        <p className="text-zinc-500 mt-2 max-w-[320px] text-[14px]">
          {rejected
            ? appStatus?.rejection_reason || "Your shop application did not meet our requirements."
            : "Our admin team is verifying your documents. You will be notified once approved."}
        </p>

        <div className="mt-8 w-full max-w-[360px] space-y-3" data-testid="pending-status-card">
          <div className="bg-zinc-50 border border-zinc-100 rounded-2xl p-4 text-left">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">Status</div>
            <div className="flex items-center gap-2 mt-1">
              <span className={`w-2 h-2 rounded-full ${rejected ? "bg-red-500" : "bg-amber-500 pulse-dot"}`} />
              <div className="font-semibold text-zinc-900">{appStatus?.status || "Pending"}</div>
            </div>
            {appStatus?.partner_id && (
              <div className="text-[11px] text-zinc-500 mt-2">
                Application ID: <span className="font-mono">{appStatus.partner_id}</span>
              </div>
            )}
          </div>

          {!rejected && (
            <div className="bg-zinc-900 text-white rounded-2xl p-4 text-left">
              <div className="font-semibold">What happens next?</div>
              <ul className="mt-2 text-[12px] text-zinc-300 space-y-1.5">
                <li>1. Admin verifies your documents (typically &lt; 24h)</li>
                <li>2. You receive a notification once approved</li>
                <li>3. Toggle online and start accepting orders</li>
              </ul>
            </div>
          )}
        </div>

        <button
          onClick={handleRefresh}
          data-testid="pending-refresh"
          className="mt-8 w-full max-w-[360px] bg-zinc-900 text-white font-semibold py-3.5 rounded-2xl flex items-center justify-center gap-2 btn-press"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} /> Check status
        </button>
        {rejected && (
          <button onClick={() => navigate("/apply")} data-testid="reapply-btn"
                  className="mt-3 w-full max-w-[360px] bg-zinc-100 text-zinc-900 font-semibold py-3.5 rounded-2xl btn-press">
            Reapply
          </button>
        )}
        <button onClick={handleLogout} className="mt-3 text-zinc-500 text-sm flex items-center gap-1.5 btn-press" data-testid="pending-logout">
          <LogOut className="w-4 h-4" /> Log out
        </button>
      </div>
    </div>
  );
}
