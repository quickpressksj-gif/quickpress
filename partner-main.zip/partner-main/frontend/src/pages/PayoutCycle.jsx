import React, { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Download, Mail, ChevronDown, ChevronUp, MessageCircle } from "lucide-react";
import { api, fmtMoney } from "@/api";
import { useToast } from "@/components/ZomatoToast";

const TABS = ["Summary", "Orders", "Expenses"];

export default function PayoutCycle() {
  const { range = "current" } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [tab, setTab] = useState("Summary");
  const [data, setData] = useState(null);
  const [open, setOpen] = useState({});
  const [orders, setOrders] = useState([]);

  useEffect(() => { load(); }, [range]);

  const load = async () => {
    try {
      const r = await api.get(`/partner/payouts/cycle?range=${range}`);
      setData(r.data);
      // Pull orders for these settlements
      const sids = (r.data.settlements || []).map((s) => s.order_id);
      if (sids.length) {
        const o = await api.get(`/partner/orders?tab=completed`);
        setOrders((o.data.items || []).filter((x) => sids.includes(x.order_id)));
      }
    } catch (e) { /* ignore */ }
  };

  if (!data) return (
    <div className="app-shell min-h-screen bg-zinc-100">
      <div className="p-6 text-center text-zinc-500">Loading…</div>
    </div>
  );

  const b = data.breakdown || {};

  return (
    <div className="app-shell min-h-screen bg-zinc-100" data-testid="payout-cycle-page">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-zinc-100 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} data-testid="cycle-back" className="p-2 -ml-2 btn-press"><ArrowLeft className="w-5 h-5" /></button>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-zinc-900 truncate">Settlement {data.cycle_label}</div>
          <div className="text-[11px] text-zinc-500">ID: {(data.bank?.utr || "—").slice(0,10)} · QuickPress</div>
        </div>
      </header>

      {/* Tabs */}
      <div className="px-3 pt-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 pb-2">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              data-testid={`cycle-tab-${t.toLowerCase()}`}
              className={`px-5 py-2 rounded-full text-[14px] font-semibold whitespace-nowrap btn-press ${
                tab === t ? "bg-zinc-900 text-white" : "bg-white text-zinc-700 border border-zinc-200"
              }`}
            >{t}</button>
          ))}
        </div>
      </div>

      <div className="px-3 py-3 space-y-3">
        {tab === "Summary" && (
          <>
            {/* Net payout card */}
            <div className="bg-white rounded-2xl p-4" data-testid="net-payout-card">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-[12px] text-zinc-500">Net payout</div>
                  <div className="text-[26px] font-bold text-zinc-900 mt-0.5">{fmtMoney(data.net_payout)}</div>
                </div>
                <div>
                  <div className="text-[12px] text-zinc-500">Payout for</div>
                  <div className="text-[18px] font-bold text-zinc-900 mt-0.5">{data.cycle_label}</div>
                </div>
              </div>
              <div className="mt-3 border-t border-dashed border-zinc-200 pt-2 text-[12px] text-zinc-600">
                Payout date: <span className="font-semibold text-zinc-900">{data.payout_date}</span>
              </div>
            </div>

            {/* Settlement summary */}
            <div className="bg-white rounded-2xl">
              <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100">
                <div className="font-bold text-zinc-900">Settlement summary</div>
                <div className="flex gap-2">
                  <button data-testid="cycle-download" className="w-9 h-9 rounded-xl bg-zinc-100 grid place-items-center btn-press" onClick={() => toast.info("Report generated", "Sent to your email")}>
                    <Download className="w-4 h-4 text-zinc-700" />
                  </button>
                  <button data-testid="cycle-email" className="w-9 h-9 rounded-xl bg-zinc-100 grid place-items-center btn-press" onClick={() => toast.info("Email sent")}>
                    <Mail className="w-4 h-4 text-zinc-700" />
                  </button>
                </div>
              </div>

              <Row k="Total orders" v={String(data.total_orders)} expandable rightArrow={false} testid="row-orders" />
              <Row k="Net order value (A)" v={fmtMoney(b.A_net_order_value)} expandable onToggle={() => setOpen({ ...open, A: !open.A })} expanded={open.A} testid="row-A">
                <SubRow k="Item subtotal" v={fmtMoney(b.A_net_order_value)} />
                <SubRow k="Discount on items" v={fmtMoney(0)} />
              </Row>
              <Row k="Additions (B)" v={fmtMoney(b.B_additions)} expandable onToggle={() => setOpen({ ...open, B: !open.B })} expanded={open.B} testid="row-B">
                <SubRow k="Pickup & delivery charges" v={fmtMoney(b.B_additions)} />
              </Row>
              <Row k="Order level deductions (C)" v={fmtMoney(b.C_order_deductions)} expandable onToggle={() => setOpen({ ...open, C: !open.C })} expanded={open.C} testid="row-C" negative>
                <SubRow k="Platform commission (10%)" v={fmtMoney(b.C_order_deductions)} />
              </Row>
              <Row k="Tax deductions (D)" v={fmtMoney(b.D_tax_deductions)} expandable onToggle={() => setOpen({ ...open, D: !open.D })} expanded={open.D} testid="row-D" negative>
                <SubRow k="GST/TDS (5%)" v={fmtMoney(b.D_tax_deductions)} />
              </Row>
              <Row k="Investments in growth (E)" v={fmtMoney(b.E_investments)} expandable onToggle={() => setOpen({ ...open, E: !open.E })} expanded={open.E} testid="row-E">
                <SubRow k="Ad spend" v={fmtMoney(b.E_investments)} />
              </Row>
              <Row k="Hyperpure spend (F)" v={fmtMoney(b.F_hyperpure)} expandable onToggle={() => setOpen({ ...open, F: !open.F })} expanded={open.F} testid="row-F">
                <SubRow k="Supplies & packaging" v={fmtMoney(0)} />
              </Row>

              <div className="px-4 py-3.5 bg-zinc-50 rounded-b-2xl flex items-center justify-between" data-testid="est-payout-row">
                <div>
                  <div className="font-bold text-zinc-900">Est. payout</div>
                  <div className="text-[11px] text-zinc-500">(A + B + C + D + E + F)</div>
                </div>
                <div className="text-[18px] font-bold text-emerald-700">{fmtMoney(b.est_payout)}</div>
              </div>
            </div>

            {/* Transaction details */}
            <div className="bg-white rounded-2xl px-4 py-4" data-testid="transaction-details">
              <div className="font-bold text-zinc-900 mb-2">Transaction details</div>
              <Row inline k="UTR" v={data.bank?.utr || "—"} />
              <Row inline k="Account no." v={data.bank?.account_number ? `${data.bank.account_number}` : "Not set"} sub={data.bank?.bank_name} />
            </div>

            <Link to="/support" data-testid="cycle-chat" className="fixed bottom-24 right-4 w-12 h-12 rounded-full bg-zinc-900 text-white grid place-items-center shadow-2xl btn-press z-30">
              <MessageCircle className="w-5 h-5" />
            </Link>
          </>
        )}

        {tab === "Orders" && (
          <div className="space-y-2" data-testid="cycle-orders">
            {(data.settlements || []).length === 0 && <div className="text-center text-sm text-zinc-500 py-10">No orders in this cycle</div>}
            {(data.settlements || []).map((s) => (
              <div key={s.settlement_id} className="bg-white rounded-2xl p-3.5" data-testid={`co-${s.settlement_id}`}>
                <div className="flex justify-between">
                  <div className="font-mono text-[12px] text-zinc-500">#{s.order_id.replace("ord_","").toUpperCase().slice(0,8)}</div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    s.status === "Paid" ? "bg-emerald-50 text-emerald-700" :
                    s.status === "Approved" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"
                  }`}>{s.status}</span>
                </div>
                <div className="flex justify-between mt-1">
                  <span className="text-zinc-700">Gross {fmtMoney(s.gross)}</span>
                  <span className="text-zinc-500">−{fmtMoney(s.commission)} comm.</span>
                </div>
                <div className="font-bold text-emerald-700 mt-0.5">Net: {fmtMoney(s.amount)}</div>
              </div>
            ))}
          </div>
        )}

        {tab === "Expenses" && (
          <div className="bg-white rounded-2xl p-4 space-y-2" data-testid="cycle-expenses">
            <ExpRow label="Platform commission" amount={b.C_order_deductions} />
            <ExpRow label="Tax deducted (GST/TDS)" amount={b.D_tax_deductions} />
            <ExpRow label="Ad investments" amount={b.E_investments} />
            <ExpRow label="Hyperpure supplies" amount={b.F_hyperpure} />
            <div className="border-t border-zinc-100 pt-2 flex justify-between font-bold">
              <span>Total expenses</span>
              <span className="text-red-600">{fmtMoney((b.C_order_deductions||0) + (b.D_tax_deductions||0) + (b.E_investments||0))}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const Row = ({ k, v, sub, expandable, onToggle, expanded, children, inline, negative, testid, rightArrow }) => (
  <div className={inline ? "py-2 flex items-center justify-between" : "px-4 py-3 border-b border-zinc-50"} data-testid={testid}>
    <button onClick={onToggle} disabled={!expandable} className="w-full flex items-center justify-between text-left">
      <div className="flex items-center gap-1.5 text-zinc-700">
        <span className="font-medium">{k}</span>
        {expandable && (
          expanded ? <ChevronUp className="w-3.5 h-3.5 text-zinc-400" /> : <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
        )}
      </div>
      <div className={`font-bold ${negative ? "text-red-600" : "text-zinc-900"}`}>{v}</div>
    </button>
    {sub && <div className="text-[11px] text-zinc-500 mt-0.5">{sub}</div>}
    {expanded && children && <div className="mt-2 pl-3 border-l-2 border-zinc-100 space-y-1">{children}</div>}
  </div>
);

const SubRow = ({ k, v }) => (
  <div className="flex justify-between text-[12px] text-zinc-600">
    <span>{k}</span><span className="font-medium">{v}</span>
  </div>
);

const ExpRow = ({ label, amount }) => (
  <div className="flex justify-between text-[14px]">
    <span className="text-zinc-700">{label}</span>
    <span className="font-bold text-zinc-900">{fmtMoney(amount)}</span>
  </div>
);
