import React, { useEffect, useState } from "react";
import PartnerHeader from "@/components/PartnerHeader";
import { api } from "@/api";
import { useToast } from "@/components/ZomatoToast";
import { Star, MessageSquare, X } from "lucide-react";

export default function Reviews() {
  const toast = useToast();
  const [reviews, setReviews] = useState([]);
  const [avg, setAvg] = useState(0);
  const [reply, setReply] = useState(null);

  useEffect(() => { load(); }, []);
  const load = async () => {
    try {
      const r = await api.get("/partner/reviews");
      setReviews(r.data.items || []);
      setAvg(r.data.average || 0);
    } catch (e) {}
  };

  return (
    <>
      <PartnerHeader title="Reviews & Ratings" rightAction="menu" showOnline={false} />
      <div className="px-4 py-3">
        <div className="bg-zinc-900 text-white rounded-2xl p-4 flex items-center gap-4" data-testid="reviews-summary">
          <div className="text-[36px] font-bold leading-none flex items-center gap-2">
            {avg?.toFixed ? avg.toFixed(1) : "—"} <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
          </div>
          <div>
            <div className="text-zinc-300 text-[12px]">Avg rating</div>
            <div className="text-zinc-100 text-sm">{reviews.length} reviews</div>
          </div>
        </div>

        <div className="mt-4 space-y-3" data-testid="reviews-list">
          {reviews.length === 0 && <div className="text-center text-sm text-zinc-500 py-10">No reviews yet</div>}
          {reviews.map((r) => (
            <div key={r.review_id} className="bg-white border border-zinc-200 rounded-2xl p-3.5" data-testid={`review-${r.review_id}`}>
              <div className="flex items-center justify-between">
                <div className="font-semibold text-zinc-900">{r.user_name || "Customer"}</div>
                <div className="flex items-center gap-1 text-[12px] text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {r.rating}
                </div>
              </div>
              <div className="text-[13px] text-zinc-700 mt-1">{r.comment}</div>
              <div className="text-[11px] text-zinc-400 mt-1.5">{new Date(r.created_at).toLocaleDateString()}</div>
              {r.partner_reply ? (
                <div className="mt-2 bg-zinc-50 border-l-2 border-zinc-900 px-3 py-2 rounded text-[12px] text-zinc-700">
                  <span className="font-semibold">Your reply:</span> {r.partner_reply}
                </div>
              ) : (
                <button onClick={() => setReply(r)} data-testid={`reply-${r.review_id}`}
                        className="mt-2 text-[12px] text-blue-600 font-semibold flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5" /> Reply
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {reply && (
        <ReplyModal review={reply} onClose={() => setReply(null)} onSaved={() => { setReply(null); toast.success("Reply posted"); load(); }} />
      )}
    </>
  );
}

function ReplyModal({ review, onClose, onSaved }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const send = async () => {
    setBusy(true);
    try {
      await api.post(`/partner/reviews/${review.review_id}/reply`, { reply: text });
      onSaved();
    } catch {} setBusy(false);
  };
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-5 pb-8" onClick={(e) => e.stopPropagation()} data-testid="reply-modal">
        <div className="flex justify-between items-center mb-3">
          <div className="font-bold text-lg">Reply to {review.user_name}</div>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} placeholder="Thank you for your feedback..."
                  data-testid="reply-text"
                  className="w-full border-2 border-zinc-200 rounded-2xl px-4 py-3 outline-none focus:border-zinc-900 resize-none" />
        <button onClick={send} disabled={!text || busy} data-testid="reply-send" className="mt-3 w-full bg-zinc-900 text-white font-semibold py-3 rounded-2xl btn-press disabled:opacity-50">
          {busy ? "Posting..." : "Post reply"}
        </button>
      </div>
    </div>
  );
}
