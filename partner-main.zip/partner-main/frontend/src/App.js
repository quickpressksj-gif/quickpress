import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { SocketProvider } from "@/context/SocketContext";
import { ZomatoToastProvider } from "@/components/ZomatoToast";
import NewOrderAlert from "@/components/NewOrderAlert";

import Login from "@/pages/Login";
import Apply from "@/pages/Apply";
import PendingReview from "@/pages/PendingReview";
import Hub from "@/pages/Hub";
import Orders from "@/pages/Orders";
import OrderDetail from "@/pages/OrderDetail";
import MenuPage from "@/pages/MenuPage";
import Growth from "@/pages/Growth";
import Finance from "@/pages/Finance";
import PayoutCycle from "@/pages/PayoutCycle";
import Reviews from "@/pages/Reviews";
import Reports from "@/pages/Reports";
import Support from "@/pages/Support";
import Notifications from "@/pages/Notifications";
import AdminPartners from "@/pages/AdminPartners";
import BankSettings from "@/pages/BankSettings";
import Layout from "@/components/Layout";

function Splash() {
  return (
    <div className="app-shell min-h-screen bg-white grid place-items-center">
      <div className="text-center">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-zinc-900 grid place-items-center text-white font-bold text-lg">QP</div>
        <div className="mt-3 text-zinc-500 text-sm">Loading…</div>
      </div>
    </div>
  );
}

function Protected({ children, requireApproved = true }) {
  const { user, appStatus, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (!appStatus?.has_application) return <Navigate to="/apply" replace />;
  if (requireApproved && appStatus?.status !== "Approved") return <Navigate to="/pending" replace />;
  return children;
}

function RootRedirect() {
  const { user, appStatus, loading } = useAuth();
  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace />;
  if (!appStatus?.has_application) return <Navigate to="/apply" replace />;
  if (appStatus?.status !== "Approved") return <Navigate to="/pending" replace />;
  return <Navigate to="/hub" replace />;
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SocketProvider>
          <ZomatoToastProvider>
            <NewOrderAlert />
            <Routes>
              <Route path="/" element={<RootRedirect />} />
              <Route path="/login" element={<Login />} />
              <Route path="/apply" element={<Apply />} />
              <Route path="/pending" element={<PendingReview />} />
              <Route path="/admin" element={<AdminPartners />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/hub"     element={<Protected><Layout><Hub /></Layout></Protected>} />
              <Route path="/orders"  element={<Protected><Layout><Orders /></Layout></Protected>} />
              <Route path="/orders/:id" element={<Protected><OrderDetail /></Protected>} />
              <Route path="/menu"    element={<Protected><Layout><MenuPage /></Layout></Protected>} />
              <Route path="/growth"  element={<Protected><Layout><Growth /></Layout></Protected>} />
              <Route path="/finance" element={<Protected><Layout><Finance /></Layout></Protected>} />
              <Route path="/finance/cycle/:range" element={<Protected><PayoutCycle /></Protected>} />
              <Route path="/reviews" element={<Protected><Layout><Reviews /></Layout></Protected>} />
              <Route path="/reports" element={<Protected><Layout><Reports /></Layout></Protected>} />
              <Route path="/support" element={<Protected><Layout><Support /></Layout></Protected>} />
              <Route path="/bank"    element={<Protected><Layout><BankSettings /></Layout></Protected>} />
              <Route path="/store"   element={<Protected><Layout><MenuPage /></Layout></Protected>} />
              <Route path="/documents" element={<Protected><Layout><Support /></Layout></Protected>} />
              <Route path="/settings" element={<Protected><Layout><BankSettings /></Layout></Protected>} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </ZomatoToastProvider>
        </SocketProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
