"""QuickPress backend entry point.

Slim FastAPI app that mounts versioned routers from /routes/*.
Shared backend serves Customer, Partner (and future Rider/Admin) apps.
"""

from __future__ import annotations

from fastapi import APIRouter, FastAPI
from starlette.middleware.cors import CORSMiddleware

from core import client, db, log
from routes.admin import router as admin_router
from routes.auth import router as auth_router
from routes.catalog import router as catalog_router
from routes.customer import router as customer_router
from routes.orders import router as orders_router
from routes.partner import router as partner_router
from routes.rider import router as rider_router

app = FastAPI(title="QuickPress API")
api = APIRouter(prefix="/api")

# Mount feature routers under /api
api.include_router(auth_router)
api.include_router(catalog_router)
api.include_router(orders_router)
api.include_router(customer_router)
api.include_router(partner_router)
api.include_router(admin_router)
api.include_router(rider_router)


@api.get("/")
async def root():
    return {"app": "QuickPress", "tagline": "Fresh Clothes. Delivered Fast."}


app.include_router(api)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.on_event("startup")
async def on_startup():
    await db.users.create_index("email", unique=False, sparse=True)
    await db.users.create_index("user_id", unique=True)
    await db.user_sessions.create_index("session_token", unique=True)
    await db.user_sessions.create_index("user_id")
    await db.partners.create_index("partner_id", unique=True)
    await db.services.create_index("service_id", unique=True)
    await db.orders.create_index("order_id", unique=True)
    await db.riders.create_index("rider_id", unique=True)
    await db.riders.create_index("user_id", unique=True)
    log.info("QuickPress backend started (refactored, modular routers)")


@app.on_event("shutdown")
async def on_shutdown():
    client.close()
