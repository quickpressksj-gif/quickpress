"""Backend end-to-end tests for QuickPress Rider routes.

Covers: OTP login (role=rider), /rider/me, 5-step onboarding, admin approve,
online status (with rejection when not approved), demo-seed, available orders,
accept order, full pipeline transitions, dashboard, earnings, wallet, payouts,
notifications.
"""

from __future__ import annotations

import os
import random
import time

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://quickpress-rider.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

# A tiny base64 placeholder used as image_url for backend pipeline steps.
TINY_IMG = (
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAA"
    "C0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


def _fresh_phone() -> str:
    # 10 digit, unique-ish per run
    return "9" + str(int(time.time()) % 10**9).zfill(9)[-9:] + ""[:0] or "9" + str(random.randint(10**8, 10**9 - 1))


@pytest.fixture(scope="module")
def phone() -> str:
    return "9" + str(random.randint(10**8, 10**9 - 1))


@pytest.fixture(scope="module")
def session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def auth(session: requests.Session, phone: str) -> dict:
    """Send + verify OTP, return {'token': ..., 'user': ...}."""
    r = session.post(f"{API}/auth/otp/send", json={"phone": phone})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body.get("otp"), body
    otp = body["otp"]
    r2 = session.post(
        f"{API}/auth/otp/verify",
        json={"phone": phone, "otp": otp, "name": "TEST Rider", "role": "rider"},
    )
    assert r2.status_code == 200, r2.text
    out = r2.json()
    assert "token" in out and "user" in out
    return out


@pytest.fixture(scope="module")
def auth_session(session: requests.Session, auth: dict) -> requests.Session:
    session.headers.update({"Authorization": f"Bearer {auth['token']}"})
    return session


# -------------------------- Auth + /rider/me --------------------------

class TestAuthAndMe:
    def test_otp_send_returns_otp(self, session: requests.Session, phone: str):
        r = session.post(f"{API}/auth/otp/send", json={"phone": phone + "0"})  # different phone
        assert r.status_code == 200
        assert r.json().get("otp")

    def test_verify_with_role_rider_assigns_role(self, auth: dict):
        # After verify, /rider/me should be reachable; user role becomes rider via _ensure_rider_for_user
        assert auth["user"]["role"] in ("rider", "customer")  # initial may be set by verify

    def test_rider_me_creates_draft(self, auth_session: requests.Session):
        r = auth_session.get(f"{API}/rider/me")
        assert r.status_code == 200, r.text
        rider = r.json()["rider"]
        assert rider["status"] == "Draft"
        assert rider["onboarding_step"] == 1


# -------------------------- Status rejection when not approved --------------------------

class TestStatusBeforeApproval:
    def test_status_online_rejected_when_not_approved(self, auth_session: requests.Session):
        r = auth_session.post(f"{API}/rider/status", json={"is_online": True})
        assert r.status_code == 400


# -------------------------- 5-step onboarding --------------------------

class TestOnboarding:
    def test_personal(self, auth_session: requests.Session):
        r = auth_session.post(
            f"{API}/rider/onboarding/personal",
            json={
                "full_name": "TEST Rider",
                "mobile": "9000000099",
                "address": "Test Address, Noida",
                "emergency_contact": "9000000088",
                "emergency_name": "Mom",
            },
        )
        assert r.status_code == 200, r.text
        assert r.json()["onboarding_step"] >= 2

    def test_vehicle(self, auth_session: requests.Session):
        r = auth_session.post(
            f"{API}/rider/onboarding/vehicle",
            json={
                "vehicle_type": "Scooter",
                "vehicle_brand": "Honda",
                "vehicle_model": "Activa",
                "vehicle_number": "DL10AB1234",
                "fuel_type": "Petrol",
            },
        )
        assert r.status_code == 200, r.text
        assert r.json()["onboarding_step"] >= 3

    @pytest.mark.parametrize(
        "doc_type",
        ["aadhaar", "license", "rc", "insurance", "puc", "profile_photo", "selfie"],
    )
    def test_document(self, auth_session: requests.Session, doc_type: str):
        r = auth_session.post(
            f"{API}/rider/onboarding/document",
            json={"doc_type": doc_type, "number": "X12345", "url": TINY_IMG},
        )
        assert r.status_code == 200, r.text
        docs = r.json().get("documents", {})
        assert doc_type in docs

    def test_bank(self, auth_session: requests.Session):
        r = auth_session.post(
            f"{API}/rider/onboarding/bank",
            json={
                "account_holder": "TEST Rider",
                "account_number": "123456789012",
                "ifsc": "HDFC0001234",
                "bank_name": "HDFC Bank",
                "upi_id": "test@upi",
            },
        )
        assert r.status_code == 200, r.text
        assert r.json()["onboarding_step"] >= 5

    def test_submit_moves_to_pending(self, auth_session: requests.Session):
        r = auth_session.post(f"{API}/rider/onboarding/submit")
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Pending"

    def test_admin_approve(self, auth_session: requests.Session):
        r = auth_session.post(f"{API}/rider/admin/approve")
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Approved"

    def test_status_online_after_approve(self, auth_session: requests.Session):
        r = auth_session.post(f"{API}/rider/status", json={"is_online": True})
        assert r.status_code == 200, r.text
        assert r.json()["is_online"] is True


# -------------------------- Demo seed + Orders pipeline --------------------------

class TestPipeline:
    @pytest.fixture(scope="class")
    def order_id(self, auth_session: requests.Session) -> str:
        seed = auth_session.post(f"{API}/rider/demo-seed")
        assert seed.status_code == 200, seed.text
        avail = auth_session.get(f"{API}/rider/orders/available")
        assert avail.status_code == 200
        items = avail.json()["items"]
        assert len(items) >= 1, f"expected available orders, got: {items}"
        oid = items[0]["order_id"]
        # accept
        acc = auth_session.post(f"{API}/rider/orders/{oid}/accept")
        assert acc.status_code == 200, acc.text
        body = acc.json()
        assert body["status"] == "Rider Assigned"
        assert body.get("rider_pickup_otp") and body.get("rider_delivery_otp")
        return oid

    def test_available_offline_empty(self, auth_session: requests.Session):
        auth_session.post(f"{API}/rider/status", json={"is_online": False})
        r = auth_session.get(f"{API}/rider/orders/available")
        assert r.status_code == 200
        assert r.json()["items"] == []
        # restore online for further tests
        auth_session.post(f"{API}/rider/status", json={"is_online": True})

    def test_arrive_customer_pickup(self, auth_session: requests.Session, order_id: str):
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/arrive-customer-pickup",
            json={"lat": 28.57, "lng": 77.32},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Arrived At Customer"

    def test_customer_pickup_requires_image(self, auth_session: requests.Session, order_id: str):
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/customer-pickup",
            json={"lat": 28.57, "lng": 77.32},
        )
        assert r.status_code == 400

    def test_customer_pickup(self, auth_session: requests.Session, order_id: str):
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/customer-pickup",
            json={"lat": 28.57, "lng": 77.32, "image_url": TINY_IMG},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Picked Up"

    def test_arrive_partner(self, auth_session: requests.Session, order_id: str):
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/arrive-partner",
            json={"lat": 28.567, "lng": 77.321},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Arrived At Partner"

    def test_partner_handover_with_otp(self, auth_session: requests.Session, order_id: str):
        # fetch order to get pickup otp
        o = auth_session.get(f"{API}/rider/orders/{order_id}").json()
        pickup_otp = o["rider_pickup_otp"]
        # Wrong OTP should 400
        bad = auth_session.post(
            f"{API}/rider/orders/{order_id}/partner-handover",
            json={"otp": "0000", "lat": 28.567, "lng": 77.321, "image_url": TINY_IMG},
        )
        assert bad.status_code == 400
        # Missing image should 400
        no_img = auth_session.post(
            f"{API}/rider/orders/{order_id}/partner-handover",
            json={"otp": pickup_otp, "lat": 28.567, "lng": 77.321},
        )
        assert no_img.status_code == 400
        ok = auth_session.post(
            f"{API}/rider/orders/{order_id}/partner-handover",
            json={"otp": pickup_otp, "lat": 28.567, "lng": 77.321, "image_url": TINY_IMG},
        )
        assert ok.status_code == 200, ok.text
        assert ok.json()["status"] == "Delivered To Partner"

    def test_partner_dispatch(self, auth_session: requests.Session, order_id: str):
        # Get/generate dispatch OTP
        otp_r = auth_session.get(f"{API}/rider/orders/{order_id}/dispatch-otp")
        assert otp_r.status_code == 200
        dispatch_otp = otp_r.json()["otp"]
        assert dispatch_otp
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/partner-dispatch",
            json={"otp": dispatch_otp, "lat": 28.567, "lng": 77.321, "image_url": TINY_IMG},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Out For Delivery"

    def test_arrive_customer_delivery(self, auth_session: requests.Session, order_id: str):
        r = auth_session.post(
            f"{API}/rider/orders/{order_id}/arrive-customer-delivery",
            json={"lat": 28.571, "lng": 77.326},
        )
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "Arrived At Drop"

    def test_final_delivery(self, auth_session: requests.Session, order_id: str):
        otp_r = auth_session.get(f"{API}/rider/orders/{order_id}/delivery-otp")
        assert otp_r.status_code == 200
        delivery_otp = otp_r.json()["otp"]
        # wrong otp
        bad = auth_session.post(
            f"{API}/rider/orders/{order_id}/final-delivery",
            json={"otp": "0000", "lat": 28.571, "lng": 77.326, "image_url": TINY_IMG},
        )
        assert bad.status_code == 400
        ok = auth_session.post(
            f"{API}/rider/orders/{order_id}/final-delivery",
            json={"otp": delivery_otp, "lat": 28.571, "lng": 77.326, "image_url": TINY_IMG},
        )
        assert ok.status_code == 200, ok.text
        body = ok.json()
        assert body["status"] == "Delivered"
        assert body.get("rider_earning", 0) > 0
        # GET to verify persistence
        g = auth_session.get(f"{API}/rider/orders/{order_id}")
        assert g.status_code == 200
        assert g.json()["status"] == "Delivered"

    def test_wallet_credited_after_delivery(self, auth_session: requests.Session):
        r = auth_session.get(f"{API}/rider/wallet")
        assert r.status_code == 200
        data = r.json()
        assert data["available_balance"] > 0
        assert any(t.get("type") == "credit" for t in data["transactions"])


# -------------------------- Dashboard / Earnings / Wallet / Payouts / Notifications --------------------------

class TestRiderMisc:
    def test_dashboard(self, auth_session: requests.Session):
        r = auth_session.get(f"{API}/rider/dashboard")
        assert r.status_code == 200, r.text
        d = r.json()
        for k in [
            "today_deliveries",
            "today_earnings",
            "weekly_earnings",
            "monthly_earnings",
            "acceptance_rate",
            "completion_rate",
            "rating",
            "active_orders",
            "is_online",
            "status",
            "wallet_balance",
        ]:
            assert k in d, f"missing key {k}"

    def test_earnings_chart(self, auth_session: requests.Session):
        r = auth_session.get(f"{API}/rider/earnings")
        assert r.status_code == 200
        d = r.json()
        assert "chart" in d and isinstance(d["chart"], list) and len(d["chart"]) == 7
        assert {"day", "amount"} <= set(d["chart"][0].keys())

    def test_payout_below_minimum(self, auth_session: requests.Session):
        r = auth_session.post(f"{API}/rider/payouts/request", json={"amount": 50})
        assert r.status_code == 400

    def test_payout_request_valid(self, auth_session: requests.Session):
        # Wallet should have funds from demo-seed + final-delivery
        bal = auth_session.get(f"{API}/rider/wallet").json()["available_balance"]
        if bal < 100:
            pytest.skip(f"Insufficient wallet balance to test payout: {bal}")
        r = auth_session.post(f"{API}/rider/payouts/request", json={"amount": 100})
        assert r.status_code == 200, r.text
        out = r.json()
        assert out["status"] == "Pending"
        assert out["amount"] == 100
        # verify list endpoint
        lst = auth_session.get(f"{API}/rider/payouts").json()
        assert any(p["payout_id"] == out["payout_id"] for p in lst["items"])

    def test_notifications(self, auth_session: requests.Session):
        r = auth_session.get(f"{API}/rider/notifications")
        assert r.status_code == 200
        items = r.json()["items"]
        assert isinstance(items, list)
