"""QuickPress API routers."""
