import React, { useEffect, useMemo } from "react";
import L from "leaflet";
import { MapContainer, TileLayer, Marker, Polyline, useMap } from "react-leaflet";

// Fix default icon paths
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const makeDivIcon = (color, label, pulsing = false) => {
  const html = `
    <div style="position:relative;display:flex;flex-direction:column;align-items:center;">
      <div style="background:${color};color:white;padding:6px 10px;border-radius:999px;font-weight:700;font-size:11px;font-family:Manrope,sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.18);white-space:nowrap;">${label}</div>
      <div style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:8px solid ${color};margin-top:-2px;"></div>
      <div class="${pulsing ? "pulse-ring" : ""}" style="width:14px;height:14px;border-radius:50%;background:${color};border:3px solid white;margin-top:2px;box-shadow:0 2px 6px rgba(0,0,0,0.25);"></div>
    </div>`;
  return L.divIcon({ html, className: "qp-marker", iconSize: [80, 56], iconAnchor: [40, 50] });
};

const FitBounds = ({ points }) => {
  const map = useMap();
  useEffect(() => {
    if (!points || points.length === 0) return;
    const valid = points.filter((p) => p && Number.isFinite(p[0]) && Number.isFinite(p[1]));
    if (valid.length === 0) return;
    if (valid.length === 1) {
      map.setView(valid[0], 15);
    } else {
      map.fitBounds(valid, { padding: [40, 40], maxZoom: 16 });
    }
  }, [points, map]);
  return null;
};

export default function MapView({
  rider,
  partner,
  customer,
  route = [],
  height = "100%",
  className = "",
  showRider = true,
}) {
  const center = useMemo(() => {
    if (rider) return [rider.lat, rider.lng];
    if (partner) return [partner.lat, partner.lng];
    if (customer) return [customer.lat, customer.lng];
    return [28.5675, 77.321]; // Noida default
  }, [rider, partner, customer]);

  const points = [
    showRider && rider && [rider.lat, rider.lng],
    partner && [partner.lat, partner.lng],
    customer && [customer.lat, customer.lng],
  ].filter(Boolean);

  const riderIcon = useMemo(() => makeDivIcon("#16A34A", "Rider", true), []);
  const partnerIcon = useMemo(() => makeDivIcon("#F4B400", partner?.label || "Partner"), [partner?.label]);
  const customerIcon = useMemo(() => makeDivIcon("#3B82F6", customer?.label || "Customer"), [customer?.label]);

  return (
    <div className={className} style={{ height }} data-testid="map-view">
      <MapContainer
        center={center}
        zoom={14}
        style={{ height: "100%", width: "100%", borderRadius: "inherit" }}
        zoomControl={false}
        attributionControl={true}
      >
        <TileLayer
          attribution='&copy; OpenStreetMap'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {showRider && rider && Number.isFinite(rider.lat) && (
          <Marker position={[rider.lat, rider.lng]} icon={riderIcon} />
        )}
        {partner && Number.isFinite(partner.lat) && (
          <Marker position={[partner.lat, partner.lng]} icon={partnerIcon} />
        )}
        {customer && Number.isFinite(customer.lat) && (
          <Marker position={[customer.lat, customer.lng]} icon={customerIcon} />
        )}
        {route && route.length > 1 && (
          <Polyline positions={route} pathOptions={{ color: "#F4B400", weight: 5, opacity: 0.85 }} />
        )}
        <FitBounds points={points} />
      </MapContainer>
    </div>
  );
}

// fetch OSRM route in lng,lat,...;lng,lat order
export async function fetchRoute(points) {
  if (!points || points.length < 2) return [];
  try {
    const coords = points.map((p) => `${p[1]},${p[0]}`).join(";");
    const url = `https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson`;
    const r = await fetch(url);
    if (!r.ok) return [];
    const d = await r.json();
    const c = d?.routes?.[0]?.geometry?.coordinates || [];
    return c.map(([lng, lat]) => [lat, lng]);
  } catch {
    return [];
  }
}

export function haversineKm(a, b) {
  if (!a || !b) return 0;
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
