import React from "react";
import { motion } from "framer-motion";

export const PageWrap = ({ children, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.25, ease: "easeOut" }}
    className={className}
  >
    {children}
  </motion.div>
);

export const Skeleton = ({ className = "h-4 w-full rounded-lg" }) => (
  <div className={`skeleton ${className}`} />
);

export const StatusBadge = ({ status }) => {
  const map = {
    Draft: "bg-gray-100 text-gray-700",
    Pending: "bg-yellow-100 text-yellow-800",
    Approved: "bg-green-100 text-green-800",
    Rejected: "bg-red-100 text-red-800",
    Suspended: "bg-red-100 text-red-800",
    Delivered: "bg-green-100 text-green-800",
    Cancelled: "bg-red-100 text-red-800",
  };
  const cls = map[status] || "bg-gray-100 text-gray-700";
  return (
    <span data-testid="status-badge" className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${cls}`}>
      {status || "—"}
    </span>
  );
};

export const Spinner = ({ size = 20 }) => (
  <div
    className="inline-block animate-spin rounded-full border-2 border-current border-r-transparent align-[-0.125em]"
    style={{ width: size, height: size }}
    role="status"
    aria-label="loading"
  />
);

export const Sheet = ({ open, onClose, children }) => (
  <motion.div
    initial={false}
    animate={{ opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none" }}
    className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end justify-center"
    onClick={onClose}
  >
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: open ? 0 : "100%" }}
      transition={{ type: "spring", damping: 28, stiffness: 220 }}
      onClick={(e) => e.stopPropagation()}
      className="bg-white w-full max-w-md rounded-t-3xl pb-safe overflow-hidden"
    >
      <div className="sheet-handle" />
      {children}
    </motion.div>
  </motion.div>
);
