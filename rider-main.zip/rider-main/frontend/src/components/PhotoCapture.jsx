import React, { useRef, useState } from "react";
import { Camera, RotateCcw, Check } from "lucide-react";

// Lightweight image capture: opens device camera via <input capture> on mobile,
// falls back to file picker on desktop. Returns a base64 data URL.
export default function PhotoCapture({ onCapture, label = "Tap to capture", testid = "photo-capture" }) {
  const fileRef = useRef(null);
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState(false);

  const onPick = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setBusy(true);
    const reader = new FileReader();
    reader.onload = () => {
      // Downscale to ~800px max
      const img = new Image();
      img.onload = () => {
        const max = 900;
        let { width, height } = img;
        if (width > max || height > max) {
          const r = Math.min(max / width, max / height);
          width = Math.round(width * r);
          height = Math.round(height * r);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        // GPS+timestamp overlay
        const ts = new Date().toLocaleString();
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(0, height - 36, width, 36);
        ctx.fillStyle = "#F4B400";
        ctx.font = "600 13px Manrope, sans-serif";
        ctx.fillText("QuickPress  •  " + ts, 12, height - 14);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.78);
        setPreview(dataUrl);
        setBusy(false);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(f);
  };

  const accept = () => onCapture?.(preview);
  const retake = () => {
    setPreview(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <div data-testid={testid} className="w-full">
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={onPick}
        className="hidden"
        data-testid={`${testid}-input`}
      />
      {!preview ? (
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          data-testid={`${testid}-trigger`}
          className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center gap-3 text-gray-500 bg-gray-50 hover:bg-gray-100 transition-colors active:scale-[0.99]"
        >
          <div className="w-14 h-14 rounded-full bg-[#FEF7E6] flex items-center justify-center">
            <Camera size={26} className="text-[#F4B400]" />
          </div>
          <div className="text-sm font-semibold text-gray-700">{label}</div>
          <div className="text-xs text-gray-400">GPS + timestamp will be added</div>
        </button>
      ) : (
        <div className="space-y-3">
          <img
            src={preview}
            alt="capture preview"
            className="w-full rounded-2xl border border-gray-200 shadow-sm"
            data-testid={`${testid}-preview`}
          />
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={retake}
              data-testid={`${testid}-retake`}
              className="py-3 rounded-xl bg-gray-100 hover:bg-gray-200 font-bold text-gray-800 flex items-center justify-center gap-2"
            >
              <RotateCcw size={18} /> Retake
            </button>
            <button
              type="button"
              onClick={accept}
              data-testid={`${testid}-submit`}
              className="py-3 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white font-bold flex items-center justify-center gap-2"
            >
              <Check size={18} /> Use Photo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
