import React from "react";
import { NavLink } from "react-router-dom";
import { Home, Package, Wallet, User } from "lucide-react";

const items = [
  { to: "/", icon: Home, label: "Home", testid: "bottom-nav-home" },
  { to: "/orders", icon: Package, label: "Orders", testid: "bottom-nav-orders" },
  { to: "/earnings", icon: Wallet, label: "Earnings", testid: "bottom-nav-earnings" },
  { to: "/profile", icon: User, label: "Profile", testid: "bottom-nav-profile" },
];

export default function BottomNav() {
  return (
    <div
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white/95 backdrop-blur-xl border-t border-gray-100 pb-safe"
      style={{ boxShadow: "0 -8px 30px rgba(0,0,0,0.08)", zIndex: 2147483646 }}
      data-testid="bottom-nav"
    >
      <div className="flex">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            end={it.to === "/"}
            data-testid={it.testid}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-2.5 px-2 gap-0.5 w-1/4 text-[11px] font-semibold transition-colors ${
                isActive ? "text-[#F4B400]" : "text-gray-400"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className={`p-1.5 rounded-xl transition-all ${isActive ? "bg-[#FEF7E6]" : ""}`}>
                  <it.icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span>{it.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
}
