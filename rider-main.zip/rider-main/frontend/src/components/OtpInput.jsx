import React, { useRef, useState } from "react";

export default function OtpInput({ value, onChange, length = 4, autoFocus = true }) {
  const refs = useRef([]);
  const [digits, setDigits] = useState(() => {
    const arr = Array(length).fill("");
    (value || "").split("").slice(0, length).forEach((c, i) => (arr[i] = c));
    return arr;
  });

  const updateAll = (next) => {
    setDigits(next);
    onChange?.(next.join(""));
  };

  const handle = (i, e) => {
    const v = e.target.value.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[i] = v;
    updateAll(next);
    if (v && i < length - 1) refs.current[i + 1]?.focus();
  };

  const handleKey = (i, e) => {
    if (e.key === "Backspace" && !digits[i] && i > 0) refs.current[i - 1]?.focus();
  };

  const handlePaste = (e) => {
    const text = (e.clipboardData.getData("text") || "").replace(/\D/g, "").slice(0, length);
    if (!text) return;
    const next = Array(length).fill("");
    text.split("").forEach((c, idx) => (next[idx] = c));
    updateAll(next);
    refs.current[Math.min(text.length, length - 1)]?.focus();
    e.preventDefault();
  };

  return (
    <div className="flex justify-center gap-3" onPaste={handlePaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => (refs.current[i] = el)}
          data-testid={`otp-input-${i + 1}`}
          inputMode="numeric"
          maxLength={1}
          value={d}
          autoFocus={autoFocus && i === 0}
          onChange={(e) => handle(i, e)}
          onKeyDown={(e) => handleKey(i, e)}
          className="w-14 h-14 text-center text-2xl font-bold bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#F4B400] focus:border-[#F4B400] outline-none transition-all"
        />
      ))}
    </div>
  );
}
