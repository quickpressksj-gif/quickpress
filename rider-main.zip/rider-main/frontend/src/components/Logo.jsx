import React from "react";

export const Logo = ({ size = 32, withText = true, light = false }) => (
  <div className="flex items-center gap-2">
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect x="2" y="2" width="60" height="60" rx="16" fill="#F4B400" />
      <path
        d="M18 22 L32 14 L46 22 L46 38 L32 46 L18 38 Z"
        fill="white"
        stroke="white"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M24 28 L40 28 M24 34 L36 34" stroke="#F4B400" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="48" cy="46" r="6" fill="#16A34A" stroke="white" strokeWidth="3" />
    </svg>
    {withText && (
      <div className="leading-tight">
        <div className={`font-display font-extrabold text-lg ${light ? "text-white" : "text-gray-900"}`}>
          QuickPress
        </div>
        <div className={`text-[10px] uppercase tracking-widest ${light ? "text-white/80" : "text-gray-500"} font-semibold`}>
          Rider
        </div>
      </div>
    )}
  </div>
);

export default Logo;
