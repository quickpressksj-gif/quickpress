import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

import { AuthProvider, useAuth } from "./lib/auth";
import { Spinner } from "./components/ui-bits";

import Login from "./pages/Login";
import Onboarding from "./pages/Onboarding";
import PendingApproval from "./pages/PendingApproval";
import Dashboard from "./pages/Dashboard";
import OrderActive from "./pages/OrderActive";
import Orders from "./pages/Orders";
import Earnings from "./pages/Earnings";
import Wallet from "./pages/Wallet";
import Notifications from "./pages/Notifications";
import Profile from "./pages/Profile";
import Support from "./pages/Support";

import "./App.css";

const Shell = ({ children }) => (
  <div className="mx-auto w-full max-w-md min-h-screen bg-white relative overflow-x-hidden shadow-2xl sm:border-x sm:border-gray-200">
    {children}
  </div>
);

const Protected = ({ children, allow = "any" }) => {
  const { user, rider, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="min-h-screen flex items-center justify-center"><Spinner size={28} /></div>;
  if (!user) return <Navigate to="/login" replace state={{ from: loc }} />;

  // Onboarding gates
  if (allow === "approved") {
    if (!rider) return <div className="min-h-screen flex items-center justify-center"><Spinner /></div>;
    if (rider.status !== "Approved") {
      if (rider.status === "Draft" || (rider.onboarding_step || 1) < 5 || !rider.bank) return <Navigate to="/onboarding" replace />;
      return <Navigate to="/pending" replace />;
    }
  }
  return children;
};

function AnimatedRoutes() {
  const loc = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={loc.pathname}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.22, ease: "easeOut" }}
      >
        <Routes location={loc}>
          <Route path="/login" element={<Login />} />
          <Route path="/onboarding" element={<Protected><Onboarding /></Protected>} />
          <Route path="/pending" element={<Protected><PendingApproval /></Protected>} />

          <Route path="/" element={<Protected allow="approved"><Dashboard /></Protected>} />
          <Route path="/orders" element={<Protected allow="approved"><Orders /></Protected>} />
          <Route path="/order/:id" element={<Protected allow="approved"><OrderActive /></Protected>} />
          <Route path="/earnings" element={<Protected allow="approved"><Earnings /></Protected>} />
          <Route path="/wallet" element={<Protected><Wallet /></Protected>} />
          <Route path="/notifications" element={<Protected><Notifications /></Protected>} />
          <Route path="/profile" element={<Protected><Profile /></Protected>} />
          <Route path="/support" element={<Protected><Support /></Protected>} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Shell>
          <AnimatedRoutes />
        </Shell>
      </AuthProvider>
    </BrowserRouter>
  );
}
