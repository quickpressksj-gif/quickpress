import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, MessageCircle, Phone, Send, Loader2, Headphones } from "lucide-react";
import { riderSupport, riderSupportList } from "../lib/api";
import { StatusBadge, Skeleton } from "../components/ui-bits";

export default function Support() {
  const nav = useNavigate();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [items, setItems] = useState(null);
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState("");

  const load = () => riderSupportList().then((r) => setItems(r.data.items || [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const submit = async () => {
    setErr(""); setOk(false);
    if (!subject || !message) { setErr("Subject and message required"); return; }
    setBusy(true);
    try {
      await riderSupport(subject, message);
      setOk(true); setSubject(""); setMessage("");
      load();
    } catch (e) { setErr(e?.response?.data?.detail || "Failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-full pb-10 bg-gray-50">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3 flex items-center gap-3">
        <button data-testid="support-back-btn" onClick={() => nav(-1)} className="p-2 -ml-2 rounded-xl hover:bg-gray-50"><ArrowLeft size={20} /></button>
        <h1 className="font-display text-xl font-extrabold">Support</h1>
      </div>

      <div className="p-4">
        <div className="grid grid-cols-3 gap-3">
          <a data-testid="support-call-btn" href="tel:+918001000200" className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm text-center active:scale-[0.98]">
            <div className="mx-auto w-10 h-10 rounded-full bg-green-50 text-green-600 flex items-center justify-center mb-1.5"><Phone size={18} /></div>
            <div className="text-xs font-bold">Call</div>
          </a>
          <a data-testid="support-whatsapp-btn" href="https://wa.me/918001000200" target="_blank" rel="noreferrer" className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm text-center active:scale-[0.98]">
            <div className="mx-auto w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-1.5"><MessageCircle size={18} /></div>
            <div className="text-xs font-bold">WhatsApp</div>
          </a>
          <button data-testid="support-chat-btn" className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm text-center active:scale-[0.98]">
            <div className="mx-auto w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mb-1.5"><Headphones size={18} /></div>
            <div className="text-xs font-bold">Live Chat</div>
          </button>
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm mt-5">
          <h3 className="font-display font-bold mb-3">Raise a Ticket</h3>
          <input data-testid="support-subject-input" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject"
            className="w-full px-4 py-3 mb-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-[#F4B400] outline-none" />
          <textarea data-testid="support-message-input" rows={4} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Describe the issue…"
            className="w-full px-4 py-3 mb-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-[#F4B400] outline-none" />
          {err && <div data-testid="support-error" className="text-red-600 text-sm font-semibold mb-2">{err}</div>}
          {ok && <div className="text-green-700 text-sm font-semibold mb-2">Ticket submitted — we'll reply soon.</div>}
          <button data-testid="support-submit-btn" disabled={busy} onClick={submit}
            className="w-full py-3 rounded-xl bg-[#F4B400] hover:bg-[#D9A000] text-black font-bold flex items-center justify-center gap-2 active:scale-[0.99] disabled:opacity-60">
            {busy ? <Loader2 className="animate-spin" size={16} /> : <>Submit <Send size={16} /></>}
          </button>
        </div>

        <div className="mt-5">
          <h3 className="font-display font-bold mb-2 text-gray-800">Your Tickets</h3>
          <div className="space-y-2">
            {items === null && [1, 2].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}
            {items?.length === 0 && <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-6 text-center text-sm text-gray-500">No tickets yet</div>}
            {items?.map((t) => (
              <div key={t.ticket_id} data-testid={`ticket-${t.ticket_id}`} className="bg-white border border-gray-100 rounded-2xl p-3.5 shadow-sm">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-bold truncate">{t.subject}</div>
                  <StatusBadge status={t.status} />
                </div>
                <div className="text-xs text-gray-500 truncate">{t.message}</div>
                <div className="text-[10px] text-gray-400 mt-1">{new Date(t.created_at).toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
