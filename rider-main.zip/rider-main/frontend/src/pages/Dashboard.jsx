import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Power, IndianRupee, TrendingUp, Star, CheckCircle2, Bell, Package, MapPin, Clock, X, ArrowRight, Activity } from "lucide-react";
import { Logo } from "../components/Logo";
import BottomNav from "../components/BottomNav";
import { Sheet, Skeleton, StatusBadge } from "../components/ui-bits";
import { useAuth } from "../lib/auth";
import {
  riderDashboard, ridersAvailableOrders, ridersActiveOrders,
  riderStatus, riderAccept, riderReject, riderDemoSeed, riderLocation,
} from "../lib/api";
import { haversineKm } from "../components/MapView";

const StatCard = ({ icon: Icon, label, value, sub, accent }) => (
  <div className="bg-white rounded-2xl p-3.5 border border-gray-100 shadow-sm">
    <div className="flex items-center justify-between">
      <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">{label}</span>
      <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${accent}`}>
        <Icon size={14} />
      </div>
    </div>
    <div className="font-display text-2xl font-extrabold mt-1.5">{value}</div>
    {sub && <div className="text-[11px] text-gray-500 font-semibold mt-0.5">{sub}</div>}
  </div>
);

const INR = (n) => "₹" + (Number(n || 0)).toLocaleString("en-IN", { maximumFractionDigits: 0 });

const RIDER_HOME_LAT = 28.5680;
const RIDER_HOME_LNG = 77.3225;

export default function Dashboard() {
  const nav = useNavigate();
  const { rider, refresh } = useAuth();
  const [dash, setDash] = useState(null);
  const [available, setAvailable] = useState([]);
  const [active, setActive] = useState([]);
  const [assignment, setAssignment] = useState(null);
  const [busy, setBusy] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [seeded, setSeeded] = useState(false);

  const load = async () => {
    try {
      const [d, av, ac] = await Promise.all([riderDashboard(), ridersAvailableOrders(), ridersActiveOrders()]);
      setDash(d.data);
      setAvailable(av.data.items || []);
      setActive(ac.data.items || []);
      if (!assignment && (av.data.items || []).length > 0 && (ac.data.items || []).length === 0) {
        setAssignment((av.data.items || [])[0]);
      }
    } catch {}
  };

  useEffect(() => { load(); }, []);

  // Polling every 5s when online
  useEffect(() => {
    if (!rider?.is_online) return;
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
    // eslint-disable-next-line
  }, [rider?.is_online]);

  // Push fake location every 5s when online (uses geolocation if granted, else mock near Sector 18 Noida)
  useEffect(() => {
    if (!rider?.is_online) return;
    let lat = RIDER_HOME_LAT, lng = RIDER_HOME_LNG;
    const tick = () => {
      // small jitter to feel "moving"
      lat += (Math.random() - 0.5) * 0.0008;
      lng += (Math.random() - 0.5) * 0.0008;
      riderLocation(lat, lng, 8).catch(() => {});
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => { lat = p.coords.latitude; lng = p.coords.longitude; tick(); },
        () => tick(),
        { enableHighAccuracy: false, maximumAge: 60_000, timeout: 5000 }
      );
    } else { tick(); }
    const id = setInterval(tick, 5000);
    return () => clearInterval(id);
  }, [rider?.is_online]);

  const onToggle = async () => {
    setToggling(true);
    try {
      await riderStatus(!rider?.is_online);
      await refresh();
      await load();
    } catch (e) {
      alert(e?.response?.data?.detail || "Failed");
    } finally { setToggling(false); }
  };

  const seedDemo = async () => {
    setBusy(true);
    try { await riderDemoSeed(); setSeeded(true); await load(); await refresh(); }
    finally { setBusy(false); }
  };

  const accept = async (id) => {
    setBusy(true);
    try {
      await riderAccept(id);
      setAssignment(null);
      await load();
      nav(`/order/${id}`);
    } catch (e) { alert(e?.response?.data?.detail || "Could not accept"); }
    finally { setBusy(false); }
  };

  const reject = async (id) => {
    setBusy(true);
    try { await riderReject(id); setAssignment(null); await load(); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-full pb-24 bg-gray-50">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/90 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#F4B400] to-[#D9A000] flex items-center justify-center text-white font-bold text-lg">
              {(rider?.full_name || "R").slice(0, 1).toUpperCase()}
            </div>
            <div>
              <div className="text-[11px] text-gray-500 font-semibold uppercase tracking-wider">Welcome back</div>
              <div className="font-display text-base font-extrabold leading-tight">{rider?.full_name?.split(" ")[0] || "Rider"}</div>
            </div>
          </div>
          <button data-testid="header-notifications-btn" onClick={() => nav("/notifications")} className="relative p-2 rounded-xl bg-gray-50 border border-gray-100">
            <Bell size={18} />
          </button>
        </div>
      </div>

      <div className="px-4 pt-4">
        {/* Online/offline */}
        <motion.div
          initial={{ y: 8, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
          className={`relative rounded-3xl p-5 overflow-hidden border ${
            rider?.is_online
              ? "bg-gradient-to-br from-[#16A34A] to-[#15803D] border-transparent text-white"
              : "bg-white border-gray-100 text-gray-900"
          }`}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className={`text-[11px] font-bold uppercase tracking-wider ${rider?.is_online ? "text-white/80" : "text-gray-500"}`}>Status</div>
              <div className="font-display text-2xl font-extrabold mt-1">{rider?.is_online ? "You're Online" : "You're Offline"}</div>
              <div className={`text-xs font-semibold mt-1 ${rider?.is_online ? "text-white/85" : "text-gray-500"}`}>
                {rider?.is_online ? "Receiving live assignments" : "Go online to start earning"}
              </div>
            </div>
            <button
              data-testid="dash-online-toggle"
              onClick={onToggle}
              disabled={toggling}
              className={`relative w-20 h-20 rounded-full flex items-center justify-center font-bold transition-all active:scale-95 ${
                rider?.is_online
                  ? "bg-white text-[#16A34A] shadow-xl"
                  : "bg-[#16A34A] text-white shadow-xl"
              }`}
            >
              {rider?.is_online && <span className="absolute inset-0 rounded-full pulse-ring" />}
              <Power size={28} />
            </button>
          </div>
          {rider?.status !== "Approved" && (
            <div className={`mt-3 text-[11px] inline-flex items-center gap-1 px-2.5 py-1 rounded-full font-bold ${rider?.is_online ? "bg-white/20" : "bg-yellow-50 text-yellow-800 border border-yellow-200"}`}>
              <Activity size={12} /> Status: {rider?.status}
            </div>
          )}
        </motion.div>

        {/* Stat grid */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <StatCard icon={Package} label="Today Deliveries" value={dash?.today_deliveries ?? "—"} sub="Last 24h" accent="bg-blue-50 text-blue-600" />
          <StatCard icon={IndianRupee} label="Today Earnings" value={INR(dash?.today_earnings)} sub="Net to wallet" accent="bg-green-50 text-green-600" />
          <StatCard icon={TrendingUp} label="This Week" value={INR(dash?.weekly_earnings)} sub={`${dash?.acceptance_rate ?? 100}% accept rate`} accent="bg-yellow-50 text-yellow-700" />
          <StatCard icon={Star} label="Rating" value={(dash?.rating ?? 5).toFixed(1)} sub={`${dash?.completion_rate ?? 100}% completion`} accent="bg-purple-50 text-purple-600" />
        </div>

        {/* Active orders */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-display text-lg font-bold">Active Orders</h3>
            <span className="text-xs text-gray-500 font-semibold">{active.length} in progress</span>
          </div>
          {active.length === 0 ? (
            <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-5 text-center text-sm text-gray-500">
              No active deliveries. {rider?.is_online ? "Watching for new assignments…" : "Go online to receive assignments."}
            </div>
          ) : (
            <div className="space-y-3">
              {active.map((o) => <ActiveOrderCard key={o.order_id} o={o} onOpen={() => nav(`/order/${o.order_id}`)} />)}
            </div>
          )}
        </div>

        {/* Available */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-display text-lg font-bold">Nearby Orders</h3>
            <button data-testid="dash-refresh-btn" onClick={load} className="text-xs text-gray-500 font-semibold">Refresh</button>
          </div>

          {!rider?.is_online ? (
            <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-5 text-center text-sm text-gray-500">
              You're offline. Go online to view nearby orders.
            </div>
          ) : !available.length ? (
            <div className="bg-white border border-gray-100 rounded-2xl p-5 text-center">
              <Skeleton className="h-3 w-40 mx-auto mb-2 rounded-full" />
              <Skeleton className="h-3 w-28 mx-auto rounded-full" />
              <div className="text-xs text-gray-500 font-semibold mt-3">
                No orders near you right now.{" "}
                {!seeded && (
                  <button data-testid="dash-seed-btn" disabled={busy} onClick={seedDemo} className="text-[#16A34A] underline font-bold">
                    Seed demo orders
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {available.map((o) => (
                <button key={o.order_id} onClick={() => setAssignment(o)} data-testid={`nearby-order-${o.order_id}`} className="w-full text-left">
                  <NearbyOrderCard o={o} />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Assignment popup */}
      <Sheet open={!!assignment} onClose={() => setAssignment(null)}>
        {assignment && <AssignmentSheet o={assignment} onAccept={() => accept(assignment.order_id)} onReject={() => reject(assignment.order_id)} onClose={() => setAssignment(null)} busy={busy} />}
      </Sheet>

      <BottomNav />
    </div>
  );
}

function ActiveOrderCard({ o, onOpen }) {
  return (
    <button onClick={onOpen} data-testid={`active-order-card-${o.order_id}`} className="w-full text-left bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3 active:scale-[0.99]">
      <div className="w-12 h-12 rounded-xl bg-[#FEF7E6] flex items-center justify-center">
        <Package className="text-[#F4B400]" size={20} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider">{o.status}</div>
        <div className="font-bold truncate">{o.partner?.name || o.partner_name}</div>
        <div className="text-xs text-gray-500 truncate">to {o.customer?.name} • {o.address?.line1}</div>
      </div>
      <ArrowRight className="text-gray-400" size={18} />
    </button>
  );
}

function NearbyOrderCard({ o }) {
  const partnerLat = o.partner?.lat ?? 28.5675;
  const partnerLng = o.partner?.lng ?? 77.321;
  const custLat = o.address?.lat ?? 28.57;
  const custLng = o.address?.lng ?? 77.325;
  const dist = haversineKm({ lat: RIDER_HOME_LAT, lng: RIDER_HOME_LNG }, { lat: partnerLat, lng: partnerLng });
  const earn = Math.round(o.total * 0.15 + 20);
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider">New Order</div>
        <StatusBadge status={o.status} />
      </div>
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-gray-500">Earnings</div>
          <div className="font-display text-xl font-extrabold text-[#16A34A]">{INR(earn)}</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-gray-500">Distance</div>
          <div className="font-display text-xl font-extrabold">{dist.toFixed(1)} km</div>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-gray-100 grid gap-2 text-xs">
        <div className="flex items-center gap-2"><MapPin size={14} className="text-[#F4B400]" /><span className="font-semibold truncate">Pickup: {o.partner?.name || o.partner_name}</span></div>
        <div className="flex items-center gap-2"><MapPin size={14} className="text-blue-500" /><span className="font-semibold truncate">Drop: {o.address?.line1}, {o.address?.city}</span></div>
      </div>
    </div>
  );
}

function AssignmentSheet({ o, onAccept, onReject, onClose, busy }) {
  const [time, setTime] = useState(30);
  useEffect(() => {
    if (time <= 0) { onReject(); return; }
    const id = setTimeout(() => setTime((t) => t - 1), 1000);
    return () => clearTimeout(id);
  }, [time, onReject]);

  const partnerLat = o.partner?.lat ?? 28.5675;
  const partnerLng = o.partner?.lng ?? 77.321;
  const dist = haversineKm({ lat: RIDER_HOME_LAT, lng: RIDER_HOME_LNG }, { lat: partnerLat, lng: partnerLng });
  const earn = Math.round(o.total * 0.15 + 20);
  const eta = Math.max(5, Math.round(dist * 3));

  return (
    <div className="p-5">
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="text-[11px] font-bold uppercase text-[#F4B400] tracking-wider">New Assignment</div>
          <div className="font-display text-2xl font-extrabold">Pickup &amp; Deliver</div>
        </div>
        <div className="relative w-14 h-14">
          <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="16" stroke="#F3F4F6" strokeWidth="4" fill="none" />
            <circle cx="18" cy="18" r="16" stroke="#F4B400" strokeWidth="4" fill="none"
              strokeDasharray={`${(time/30)*100.5} 100.5`} strokeLinecap="round" />
          </svg>
          <div data-testid="assignment-countdown" className="absolute inset-0 flex items-center justify-center font-display font-extrabold">{time}</div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 my-2">
        <div className="bg-gray-50 rounded-xl p-3 text-center"><div className="text-[10px] uppercase tracking-wider font-bold text-gray-500">Earnings</div><div className="font-display text-lg font-extrabold text-[#16A34A]">{INR(earn)}</div></div>
        <div className="bg-gray-50 rounded-xl p-3 text-center"><div className="text-[10px] uppercase tracking-wider font-bold text-gray-500">Distance</div><div className="font-display text-lg font-extrabold">{dist.toFixed(1)} km</div></div>
        <div className="bg-gray-50 rounded-xl p-3 text-center"><div className="text-[10px] uppercase tracking-wider font-bold text-gray-500">ETA</div><div className="font-display text-lg font-extrabold">{eta} m</div></div>
      </div>

      <div className="mt-3 space-y-3">
        <div className="bg-white border border-gray-100 rounded-2xl p-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#FEF7E6] flex items-center justify-center"><MapPin className="text-[#F4B400]" size={18} /></div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] font-bold uppercase text-gray-500 tracking-wider">Pickup From</div>
            <div className="font-bold truncate">{o.partner?.name}</div>
            <div className="text-xs text-gray-500 truncate">{o.partner?.address}</div>
          </div>
        </div>
        <div className="bg-white border border-gray-100 rounded-2xl p-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center"><MapPin className="text-blue-500" size={18} /></div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] font-bold uppercase text-gray-500 tracking-wider">Drop At</div>
            <div className="font-bold truncate">{o.customer?.name}</div>
            <div className="text-xs text-gray-500 truncate">{o.address?.line1}, {o.address?.city} - {o.address?.pincode}</div>
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <button data-testid="assignment-reject-btn" disabled={busy} onClick={onReject} className="py-4 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold active:scale-[0.98]">
          Reject
        </button>
        <button data-testid="assignment-accept-btn" disabled={busy} onClick={onAccept} className="py-4 rounded-xl bg-[#F4B400] hover:bg-[#D9A000] text-black font-extrabold active:scale-[0.98] shadow-md">
          Accept
        </button>
      </div>
    </div>
  );
}
