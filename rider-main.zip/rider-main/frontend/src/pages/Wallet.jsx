import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowDownToLine, ArrowUpFromLine, Loader2, CheckCircle2 } from "lucide-react";
import { Sheet, Skeleton, StatusBadge } from "../components/ui-bits";
import { riderPayouts, riderRequestPayout, riderWallet } from "../lib/api";

const INR = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export default function Wallet() {
  const nav = useNavigate();
  const [w, setW] = useState(null);
  const [pos, setPos] = useState(null);
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState(false);

  const load = async () => {
    try {
      const [a, b] = await Promise.all([riderWallet(), riderPayouts()]);
      setW(a.data);
      setPos(b.data.items || []);
    } catch {}
  };
  useEffect(() => { load(); }, []);

  const submit = async () => {
    setErr(""); setOk(false);
    const v = parseFloat(amount);
    if (!v || v < 100) { setErr("Minimum ₹100"); return; }
    setBusy(true);
    try {
      await riderRequestPayout(v);
      setOk(true); setAmount("");
      await load();
      setTimeout(() => setOpen(false), 700);
    } catch (e) {
      setErr(e?.response?.data?.detail || "Failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-full pb-10 bg-gray-50">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3 flex items-center gap-3">
        <button data-testid="wallet-back-btn" onClick={() => nav(-1)} className="p-2 -ml-2 rounded-xl hover:bg-gray-50"><ArrowLeft size={20} /></button>
        <h1 className="font-display text-xl font-extrabold">Wallet</h1>
      </div>

      <div className="px-4 pt-4">
        <div className="bg-gradient-to-br from-[#F4B400] to-[#D9A000] rounded-3xl p-5 text-black shadow-lg" data-testid="wallet-balance-card">
          <div className="text-xs font-bold uppercase tracking-wider opacity-80">Available Balance</div>
          <div className="font-display text-4xl font-extrabold mt-1">{w ? INR(w.available_balance) : <Skeleton className="h-8 w-32 rounded-lg" />}</div>
          <div className="mt-1 text-sm font-bold opacity-90">Pending: {w ? INR(w.pending_balance) : "—"}</div>
          <button data-testid="request-payout-btn" onClick={() => setOpen(true)} className="mt-4 w-full py-3.5 rounded-xl bg-black text-[#F4B400] font-extrabold flex items-center justify-center gap-2 active:scale-[0.99]">
            <ArrowDownToLine size={18} /> Request Payout
          </button>
        </div>

        <div className="mt-5">
          <h3 className="font-display font-bold mb-2 text-gray-800">Payout History</h3>
          <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-100" data-testid="payout-history-list">
            {pos === null && [1, 2].map((i) => <div key={i} className="p-4"><Skeleton className="h-4 w-3/5 rounded" /></div>)}
            {pos?.length === 0 && <div className="p-4 text-sm text-gray-500 text-center">No payouts yet</div>}
            {pos?.map((p) => (
              <div key={p.payout_id} className="p-4 flex items-center justify-between" data-testid={`payout-row-${p.payout_id}`}>
                <div>
                  <div className="font-bold">{INR(p.amount)}</div>
                  <div className="text-xs text-gray-500">{new Date(p.created_at).toLocaleString()}</div>
                </div>
                <StatusBadge status={p.status} />
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5">
          <h3 className="font-display font-bold mb-2 text-gray-800">Recent Transactions</h3>
          <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-100">
            {w?.transactions?.length ? w.transactions.slice(0, 12).map((t) => (
              <div key={t.txn_id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center ${t.type === "credit" ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"}`}>
                    {t.type === "credit" ? <ArrowDownToLine size={16} /> : <ArrowUpFromLine size={16} />}
                  </div>
                  <div>
                    <div className="font-bold text-sm">{t.reason}</div>
                    <div className="text-[11px] text-gray-500">{new Date(t.created_at).toLocaleString()}</div>
                  </div>
                </div>
                <div className={`font-bold ${t.type === "credit" ? "text-green-700" : "text-red-700"}`}>
                  {t.type === "credit" ? "+" : "-"}{INR(t.amount)}
                </div>
              </div>
            )) : <div className="p-4 text-sm text-gray-500 text-center">No transactions yet</div>}
          </div>
        </div>
      </div>

      <Sheet open={open} onClose={() => !busy && setOpen(false)}>
        <div className="p-5">
          <h3 className="font-display text-xl font-extrabold mb-1">Request Payout</h3>
          <p className="text-sm text-gray-500 mb-4">Funds go to your linked bank account.</p>
          <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Amount (₹)</label>
          <input
            data-testid="payout-amount-input"
            value={amount}
            inputMode="decimal"
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g. 500"
            className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-lg font-bold focus:ring-2 focus:ring-[#F4B400] focus:border-transparent outline-none"
          />
          <div className="text-xs text-gray-500 mt-1.5">Min ₹100 • Available {w ? INR(w.available_balance) : "—"}</div>
          {err && <div data-testid="payout-error" className="mt-3 px-3 py-2 rounded-xl bg-red-50 border border-red-200 text-red-700 font-semibold text-sm">{err}</div>}
          {ok && <div className="mt-3 px-3 py-2 rounded-xl bg-green-50 border border-green-200 text-green-700 font-semibold text-sm flex items-center gap-2"><CheckCircle2 size={16} /> Request placed!</div>}
          <button data-testid="payout-submit-btn" disabled={busy} onClick={submit}
            className="mt-5 w-full py-4 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold flex items-center justify-center gap-2 active:scale-[0.99] disabled:opacity-60">
            {busy ? <Loader2 className="animate-spin" size={18} /> : "Request Payout"}
          </button>
        </div>
      </Sheet>
    </div>
  );
}
