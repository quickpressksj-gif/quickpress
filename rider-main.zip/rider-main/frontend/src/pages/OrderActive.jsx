import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Phone, MessageCircle, MapPin, CheckCircle2, Loader2, Camera, KeyRound, Info } from "lucide-react";
import MapView, { fetchRoute, haversineKm } from "../components/MapView";
import OtpInput from "../components/OtpInput";
import PhotoCapture from "../components/PhotoCapture";
import { Sheet, StatusBadge, Spinner } from "../components/ui-bits";
import {
  riderOrder, arriveCustomerPickup, customerPickup, arrivePartner, partnerHandover,
  partnerDispatch, arriveCustomerDelivery, finalDelivery, getDispatchOtp,
  riderLocation,
} from "../lib/api";
import { useAuth } from "../lib/auth";

const STEPS = [
  { id: "Rider Assigned", label: "Head to Customer", action: "Arrive at Customer" },
  { id: "Arrived At Customer", label: "Pickup from Customer", action: "Confirm Pickup (photo)" },
  { id: "Picked Up", label: "Head to Partner", action: "Arrive at Partner" },
  { id: "Arrived At Partner", label: "Handover to Partner", action: "Verify OTP & Handover" },
  { id: "Delivered To Partner", label: "Wait — Partner processing", action: "Wait for partner Ready" },
  { id: "Ready", label: "Collect from Partner", action: "Verify OTP & Dispatch" },
  { id: "Out For Delivery", label: "Head to Customer", action: "Arrive at Customer" },
  { id: "Arrived At Drop", label: "Final Delivery", action: "Verify OTP & Deliver" },
  { id: "Delivered", label: "Completed", action: null },
];

// Status equivalences for fallback when partner's existing flow runs
const STATUS_INDEX = {
  "Rider Assigned": 0,
  "Arrived At Customer": 1,
  "Picked Up": 2,
  "Arrived At Partner": 3,
  "Delivered To Partner": 4,
  "Processing": 4,
  "Ready": 5,
  "Out For Delivery": 6,
  "Arrived At Drop": 7,
  "Delivered": 8,
};

const INR = (n) => "₹" + (Number(n || 0)).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export default function OrderActive() {
  const { id } = useParams();
  const nav = useNavigate();
  const { rider } = useAuth();
  const [order, setOrder] = useState(null);
  const [route, setRoute] = useState([]);
  const [actionOpen, setActionOpen] = useState(false);
  const [actionMode, setActionMode] = useState(null); // 'photo' | 'otp_photo' | 'arrive'
  const [photo, setPhoto] = useState(null);
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [hintOtp, setHintOtp] = useState(null);

  const load = async () => {
    try {
      const r = await riderOrder(id);
      setOrder(r.data);
    } catch (e) {
      setErr(e?.response?.data?.detail || "Order not found");
    }
  };
  useEffect(() => { load(); }, [id]);

  // poll
  useEffect(() => {
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
    // eslint-disable-next-line
  }, [id]);

  // push location every 5s
  useEffect(() => {
    if (!order || order.status === "Delivered") return;
    const tick = () => {
      const r = order.rider_location;
      let lat = r?.lat ?? 28.5680, lng = r?.lng ?? 77.3225;
      lat += (Math.random() - 0.5) * 0.0008;
      lng += (Math.random() - 0.5) * 0.0008;
      riderLocation(lat, lng).catch(() => {});
    };
    const id = setInterval(tick, 5000);
    return () => clearInterval(id);
  }, [order?.status]);

  // pre-fetch hint OTPs when the rider needs them
  useEffect(() => {
    if (!order) return;
    setHintOtp(null);
    (async () => {
      try {
        if (order.status === "Arrived At Partner") {
          // partner handover uses pickup OTP — visible to rider since they need to ask partner to type it
          setHintOtp({ kind: "Pickup OTP", value: order.rider_pickup_otp });
        }
        if (order.status === "Ready") {
          const r = await getDispatchOtp(order.order_id);
          setHintOtp({ kind: "Dispatch OTP", value: r.data.otp });
        }
        if (order.status === "Arrived At Drop") {
          setHintOtp({ kind: "Delivery OTP", value: order.rider_delivery_otp });
        }
      } catch {}
    })();
  }, [order?.status]);

  const partner = useMemo(() => {
    if (!order?.partner) return null;
    const lat = order.partner.lat ?? 28.5675;
    const lng = order.partner.lng ?? 77.321;
    return { lat, lng, label: "Partner" };
  }, [order]);

  const customer = useMemo(() => {
    const lat = order?.address?.lat ?? 28.572;
    const lng = order?.address?.lng ?? 77.327;
    return { lat, lng, label: "Customer" };
  }, [order]);

  const riderLoc = useMemo(() => {
    const r = order?.rider_location || rider?.current_location;
    if (!r?.lat) return { lat: 28.568, lng: 77.3225 };
    return { lat: r.lat, lng: r.lng };
  }, [order?.rider_location, rider?.current_location]);

  // Compute route based on status
  useEffect(() => {
    if (!order) return;
    let pts = [];
    const r = [riderLoc.lat, riderLoc.lng];
    if (["Rider Assigned", "Arrived At Customer"].includes(order.status)) {
      pts = [r, [customer.lat, customer.lng]];
    } else if (["Picked Up", "Arrived At Partner", "Delivered To Partner", "Processing", "Ready"].includes(order.status)) {
      pts = [r, [partner.lat, partner.lng]];
    } else if (["Out For Delivery", "Arrived At Drop"].includes(order.status)) {
      pts = [r, [customer.lat, customer.lng]];
    }
    if (pts.length === 2) {
      fetchRoute(pts).then((p) => setRoute(p.length ? p : pts));
    } else {
      setRoute([]);
    }
  }, [order?.status, riderLoc.lat, riderLoc.lng]);

  if (!order) {
    return (
      <div className="min-h-full flex items-center justify-center text-gray-500">
        {err ? err : <Spinner />}
      </div>
    );
  }

  const stepIdx = STATUS_INDEX[order.status] ?? 0;
  const current = STEPS[stepIdx];
  const dist = haversineKm(riderLoc, order.status.includes("Customer") || order.status === "Out For Delivery" || order.status === "Arrived At Drop" || order.status === "Rider Assigned" || order.status === "Arrived At Customer" ? customer : partner);

  const beginAction = () => {
    setErr(""); setPhoto(null); setOtp("");
    if (order.status === "Rider Assigned" || order.status === "Picked Up" || order.status === "Out For Delivery") {
      setActionMode("arrive");
    } else if (order.status === "Arrived At Customer") {
      setActionMode("photo");
    } else if (order.status === "Arrived At Partner" || order.status === "Ready" || order.status === "Arrived At Drop") {
      setActionMode("otp_photo");
    } else if (order.status === "Delivered To Partner" || order.status === "Processing") {
      setActionMode("wait");
    }
    setActionOpen(true);
  };

  const submitAction = async () => {
    setBusy(true); setErr("");
    try {
      const loc = { lat: riderLoc.lat, lng: riderLoc.lng };
      if (order.status === "Rider Assigned") {
        await arriveCustomerPickup(order.order_id, loc);
      } else if (order.status === "Arrived At Customer") {
        if (!photo) throw new Error("Capture pickup photo");
        await customerPickup(order.order_id, { ...loc, image_url: photo });
      } else if (order.status === "Picked Up") {
        await arrivePartner(order.order_id, loc);
      } else if (order.status === "Arrived At Partner") {
        if (otp.length !== 4) throw new Error("Enter 4-digit OTP");
        if (!photo) throw new Error("Capture handover photo");
        await partnerHandover(order.order_id, { otp, ...loc, image_url: photo });
      } else if (order.status === "Ready") {
        if (otp.length !== 4) throw new Error("Enter dispatch OTP");
        if (!photo) throw new Error("Capture dispatch photo");
        await partnerDispatch(order.order_id, { otp, ...loc, image_url: photo });
      } else if (order.status === "Out For Delivery") {
        await arriveCustomerDelivery(order.order_id, loc);
      } else if (order.status === "Arrived At Drop") {
        if (otp.length !== 4) throw new Error("Enter delivery OTP");
        if (!photo) throw new Error("Capture delivery photo");
        await finalDelivery(order.order_id, { otp, ...loc, image_url: photo });
      }
      setActionOpen(false);
      await load();
    } catch (e) {
      setErr(e?.response?.data?.detail || e.message || "Action failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-full bg-white" data-testid="order-active-page">
      {/* Map (top 45%) */}
      <div className="relative h-[50vh] bg-gray-100" data-testid="active-order-map">
        <MapView
          rider={riderLoc}
          partner={partner}
          customer={customer}
          route={route}
          height="100%"
        />
        {/* Floating header */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <button data-testid="order-back-btn" onClick={() => nav(-1)} className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center">
            <ArrowLeft size={20} />
          </button>
          <div className="bg-white/95 backdrop-blur-xl rounded-full px-4 py-2 shadow-md text-sm">
            <span className="text-[11px] uppercase font-bold text-gray-500 tracking-wider mr-2">Distance</span>
            <span className="font-display font-extrabold">{dist.toFixed(1)} km</span>
          </div>
        </div>
      </div>

      {/* Sheet */}
      <div className="-mt-6 relative z-10 bg-white rounded-t-3xl shadow-2xl pb-24" data-testid="active-order-sheet">
        <div className="sheet-handle" />
        <div className="px-4 pt-2 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider">Order #{order.order_id.slice(-6)}</div>
              <div className="font-display text-xl font-extrabold">{current?.label || order.status}</div>
            </div>
            <StatusBadge status={order.status} />
          </div>
        </div>

        {/* Contacts */}
        <div className="px-4 grid grid-cols-2 gap-3">
          <ContactCard role="Customer" name={order.customer?.name} sub={order.address?.line1} phone={order.customer?.phone} />
          <ContactCard role="Partner" name={order.partner?.name} sub={order.partner?.address} phone={order.partner?.phone} />
        </div>

        {/* Pipeline */}
        <div className="px-4 mt-5">
          <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100" data-testid="status-pipeline">
            <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider mb-2">Delivery Pipeline</div>
            <div className="relative">
              {STEPS.slice(0, 8).map((s, i) => {
                const done = i < stepIdx;
                const cur = i === stepIdx;
                return (
                  <div key={s.id} className="flex items-start gap-3 py-1.5">
                    <div className="flex flex-col items-center">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 ${done ? "bg-[#16A34A] border-[#16A34A] text-white" : cur ? "bg-[#F4B400] border-[#F4B400] text-black" : "bg-white border-gray-200 text-gray-300"}`}>
                        {done ? <CheckCircle2 size={14} /> : <div className="w-1.5 h-1.5 rounded-full bg-current" />}
                      </div>
                      {i < 7 && <div className={`w-0.5 h-5 ${done ? "bg-[#16A34A]" : "bg-gray-200"}`} />}
                    </div>
                    <div className="pb-1">
                      <div className={`text-sm font-bold ${cur ? "text-[#F4B400]" : done ? "text-gray-700" : "text-gray-400"}`}>{s.label}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Items */}
        <div className="px-4 mt-4">
          <div className="bg-white border border-gray-100 rounded-2xl p-4">
            <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider mb-2">Order Items</div>
            {(order.items || []).map((it, i) => (
              <div key={i} className="flex justify-between py-1.5 text-sm">
                <span className="text-gray-700 font-semibold">{it.name} × {it.qty}</span>
                <span className="font-bold">{INR(it.price * it.qty)}</span>
              </div>
            ))}
            <div className="border-t border-dashed border-gray-200 mt-2 pt-2 flex justify-between font-bold">
              <span>Order Total</span><span>{INR(order.total)}</span>
            </div>
            <div className="mt-1 flex justify-between text-sm">
              <span className="text-gray-500">Your earning</span><span className="font-bold text-[#16A34A]">{INR(order.rider_earning || order.total * 0.15 + 20)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action button */}
      {order.status !== "Delivered" && (
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-100 px-4 py-3 pb-safe z-30">
          {order.status === "Delivered To Partner" || order.status === "Processing" ? (
            <button disabled className="w-full py-4 rounded-xl bg-gray-100 text-gray-500 font-bold flex items-center justify-center gap-2">
              <Loader2 className="animate-spin" size={18} /> Waiting for partner to mark Ready…
            </button>
          ) : (
            <button data-testid="active-order-action-btn" onClick={beginAction} className="w-full py-4 rounded-xl bg-[#F4B400] hover:bg-[#D9A000] text-black font-extrabold flex items-center justify-center gap-2 shadow-md active:scale-[0.99]">
              {current?.action || "Continue"}
            </button>
          )}
        </div>
      )}

      {/* Action Sheet */}
      <Sheet open={actionOpen} onClose={() => !busy && setActionOpen(false)}>
        <div className="p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-xl font-extrabold">{current?.action}</h3>
            <StatusBadge status={order.status} />
          </div>

          {actionMode === "arrive" && (
            <div className="space-y-3">
              <div className="bg-gray-50 rounded-xl p-3 text-sm text-gray-600">
                Confirm you have arrived at <span className="font-bold text-gray-900">{order.status === "Out For Delivery" || order.status === "Rider Assigned" ? order.customer?.name : order.partner?.name}</span>. Your live GPS will be recorded.
              </div>
            </div>
          )}

          {actionMode === "photo" && (
            <div>
              <div className="mb-3 bg-gray-50 rounded-xl p-3 text-sm text-gray-600">Capture clothes received from <span className="font-bold">{order.customer?.name}</span>. Photo will include GPS + timestamp.</div>
              <PhotoCapture testid="pickup-photo" label="Take pickup photo" onCapture={setPhoto} />
              {photo && <div className="mt-2 text-xs text-green-700 font-bold flex items-center gap-1"><CheckCircle2 size={14} /> Photo ready</div>}
            </div>
          )}

          {actionMode === "otp_photo" && (
            <div className="space-y-4">
              {hintOtp?.value && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl px-3 py-2.5 flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2"><Info size={14} className="text-yellow-700" /> <span className="font-semibold text-yellow-900">Share with {order.status === "Arrived At Partner" ? "partner" : order.status === "Arrived At Drop" ? "customer" : "partner"} — {hintOtp.kind}</span></div>
                  <span data-testid="otp-hint" className="font-display text-lg font-extrabold tracking-widest">{hintOtp.value}</span>
                </div>
              )}
              <div>
                <div className="text-[11px] font-bold uppercase text-gray-500 tracking-wider mb-3 text-center">Enter 4-digit OTP</div>
                <OtpInput value={otp} onChange={setOtp} length={4} />
              </div>
              <PhotoCapture testid="action-photo" label="Capture photo proof" onCapture={setPhoto} />
              {photo && <div className="text-xs text-green-700 font-bold flex items-center gap-1"><CheckCircle2 size={14} /> Photo captured</div>}
            </div>
          )}

          {err && <div data-testid="action-error" className="mt-3 px-3 py-2 rounded-xl bg-red-50 border border-red-200 text-red-700 font-semibold text-sm">{err}</div>}

          <div className="mt-5 grid grid-cols-2 gap-3">
            <button onClick={() => !busy && setActionOpen(false)} data-testid="action-cancel-btn" className="py-4 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold active:scale-[0.98]">Cancel</button>
            <button data-testid="action-submit-btn" disabled={busy} onClick={submitAction} className="py-4 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold active:scale-[0.98] shadow-md flex items-center justify-center gap-2">
              {busy ? <Loader2 className="animate-spin" size={18} /> : <>Confirm <CheckCircle2 size={18} /></>}
            </button>
          </div>
        </div>
      </Sheet>
    </div>
  );
}

function ContactCard({ role, name, sub, phone }) {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-3">
      <div className="text-[10px] uppercase tracking-wider font-bold text-gray-500">{role}</div>
      <div className="font-bold truncate">{name || "—"}</div>
      <div className="text-xs text-gray-500 truncate">{sub}</div>
      <div className="mt-2 flex gap-2">
        <a data-testid={`call-${role.toLowerCase()}-btn`} href={`tel:${phone || ""}`} className="flex-1 py-1.5 rounded-lg bg-green-50 text-green-700 font-bold text-xs flex items-center justify-center gap-1">
          <Phone size={12} /> Call
        </a>
        <button data-testid={`chat-${role.toLowerCase()}-btn`} className="flex-1 py-1.5 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center gap-1">
          <MessageCircle size={12} /> Chat
        </button>
      </div>
    </div>
  );
}
