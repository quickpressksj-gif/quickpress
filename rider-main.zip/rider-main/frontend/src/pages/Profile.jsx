import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight, LogOut, Phone, Mail, Bike, Landmark, FileText, MessageCircle, HelpCircle, Bell } from "lucide-react";
import BottomNav from "../components/BottomNav";
import { StatusBadge } from "../components/ui-bits";
import { useAuth } from "../lib/auth";

export default function Profile() {
  const nav = useNavigate();
  const { rider, user, logout } = useAuth();

  const items = [
    { icon: Bike, label: "Vehicle Information", sub: `${rider?.vehicle_type || "Not set"} • ${rider?.vehicle_number || "—"}`, to: "/onboarding", testid: "profile-link-vehicle" },
    { icon: FileText, label: "Documents", sub: `${Object.keys(rider?.documents || {}).length} uploaded`, to: "/onboarding", testid: "profile-link-docs" },
    { icon: Landmark, label: "Bank & Payouts", sub: rider?.bank?.bank_name || "Not set", to: "/wallet", testid: "profile-link-bank" },
    { icon: Bell, label: "Notifications", sub: "Recent activity", to: "/notifications", testid: "profile-link-notifications" },
    { icon: HelpCircle, label: "Support", sub: "Get help, raise a ticket", to: "/support", testid: "profile-link-support" },
  ];

  return (
    <div className="min-h-full pb-24 bg-gray-50">
      <div className="bg-gradient-to-b from-[#F4B400] to-[#D9A000] px-4 pt-8 pb-16 text-black">
        <h1 className="font-display text-2xl font-extrabold">Profile</h1>
      </div>

      <div className="px-4 -mt-12 relative z-10">
        <motion.div initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="bg-white rounded-3xl p-5 shadow-xl border border-gray-100">
          <div className="flex items-center gap-3">
            <div data-testid="profile-avatar" className="w-16 h-16 rounded-full bg-gradient-to-br from-[#F4B400] to-[#D9A000] flex items-center justify-center text-white font-bold text-2xl overflow-hidden">
              {rider?.profile_photo ? <img src={rider.profile_photo} alt="me" className="w-full h-full object-cover" /> : (rider?.full_name || "R").slice(0, 1).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-display text-lg font-extrabold truncate" data-testid="profile-name">{rider?.full_name || "Rider"}</div>
              <div className="text-xs text-gray-500 truncate flex items-center gap-1"><Phone size={12} /> {rider?.mobile || user?.phone || "—"}</div>
              {rider?.email && <div className="text-xs text-gray-500 truncate flex items-center gap-1"><Mail size={12} /> {rider?.email}</div>}
            </div>
            <StatusBadge status={rider?.status} />
          </div>

          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-gray-100">
            <Stat label="Deliveries" value={rider?.deliveries_count ?? 0} />
            <Stat label="Rating" value={(rider?.rating || 5).toFixed(1)} />
            <Stat label="Rejections" value={rider?.rejected_count ?? 0} />
          </div>
        </motion.div>

        <div className="mt-5 bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
          {items.map((it) => (
            <button key={it.label} data-testid={it.testid} onClick={() => nav(it.to)} className="w-full p-4 flex items-center gap-3 active:bg-gray-50 text-left">
              <div className="w-10 h-10 rounded-xl bg-[#FEF7E6] text-[#F4B400] flex items-center justify-center"><it.icon size={18} /></div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-gray-900">{it.label}</div>
                <div className="text-xs text-gray-500 truncate">{it.sub}</div>
              </div>
              <ChevronRight size={18} className="text-gray-400" />
            </button>
          ))}
        </div>

        <button data-testid="profile-logout-btn" onClick={logout} className="mt-5 w-full p-4 rounded-2xl bg-white border border-red-100 text-red-600 font-bold flex items-center justify-center gap-2 active:scale-[0.99]">
          <LogOut size={18} /> Logout
        </button>

        <div className="mt-6 text-center text-[11px] text-gray-400 font-semibold">QuickPress Rider • v1.0</div>
      </div>

      <BottomNav />
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="text-center">
      <div className="font-display text-xl font-extrabold">{value}</div>
      <div className="text-[10px] uppercase tracking-wider font-bold text-gray-500">{label}</div>
    </div>
  );
}
