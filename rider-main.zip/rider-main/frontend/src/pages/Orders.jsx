import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Package, ArrowRight, ChevronLeft } from "lucide-react";
import BottomNav from "../components/BottomNav";
import { StatusBadge, Skeleton } from "../components/ui-bits";
import { ridersActiveOrders, ridersHistory } from "../lib/api";

const INR = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export default function Orders() {
  const nav = useNavigate();
  const [tab, setTab] = useState("active");
  const [active, setActive] = useState(null);
  const [history, setHistory] = useState(null);

  const load = async () => {
    try {
      const [a, h] = await Promise.all([ridersActiveOrders(), ridersHistory()]);
      setActive(a.data.items || []);
      setHistory(h.data.items || []);
    } catch {}
  };

  useEffect(() => { load(); }, []);

  const data = tab === "active" ? active : history;

  return (
    <div className="min-h-full pb-24 bg-gray-50">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl font-extrabold">My Orders</h1>
        </div>
        <div className="flex bg-gray-100 rounded-xl p-1 mt-3">
          {[
            { k: "active", label: "Active" },
            { k: "history", label: "History" },
          ].map((t) => (
            <button
              key={t.k}
              data-testid={`orders-tab-${t.k}`}
              onClick={() => setTab(t.k)}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${tab === t.k ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-4 space-y-3">
        {data === null && [1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        {data !== null && data.length === 0 && (
          <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-10 text-center text-gray-500">
            <Package className="mx-auto mb-2 text-gray-300" size={28} />
            <div className="font-bold">No {tab} orders</div>
            <div className="text-xs mt-1">{tab === "active" ? "Pick up a new assignment from the home tab." : "Completed orders will appear here."}</div>
          </div>
        )}
        {data?.map((o) => (
          <button
            key={o.order_id}
            data-testid={`order-row-${o.order_id}`}
            onClick={() => tab === "active" && nav(`/order/${o.order_id}`)}
            className="w-full text-left bg-white border border-gray-100 rounded-2xl p-4 shadow-sm flex items-center gap-3 active:scale-[0.99]"
          >
            <div className="w-12 h-12 rounded-xl bg-[#FEF7E6] flex items-center justify-center">
              <Package className="text-[#F4B400]" size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <div className="font-bold truncate">{o.partner?.name || o.partner_name}</div>
                <StatusBadge status={o.status} />
              </div>
              <div className="text-xs text-gray-500 truncate mt-0.5">to {o.customer?.name} • {o.address?.line1}</div>
              <div className="flex items-center justify-between mt-1.5">
                <div className="text-xs text-gray-500">Earning: <span className="font-bold text-[#16A34A]">{INR(o.rider_earning || o.total * 0.15 + 20)}</span></div>
                {tab === "active" && <ArrowRight size={16} className="text-gray-400" />}
              </div>
            </div>
          </button>
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
