import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Wallet as WalletIcon, ArrowRight, TrendingUp, Gift, Star, IndianRupee, ChevronLeft } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import BottomNav from "../components/BottomNav";
import { Skeleton } from "../components/ui-bits";
import { riderEarnings } from "../lib/api";

const INR = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export default function Earnings() {
  const nav = useNavigate();
  const [tab, setTab] = useState("today");
  const [data, setData] = useState(null);

  useEffect(() => { riderEarnings().then((r) => setData(r.data)).catch(() => setData({})); }, []);

  const amount = data ? (tab === "today" ? data.today : tab === "week" ? data.weekly : data.monthly) : 0;

  return (
    <div className="min-h-full pb-24 bg-gradient-to-b from-[#FEF7E6] via-white to-gray-50">
      <div className="sticky top-0 z-30 bg-white/90 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3">
        <h1 className="font-display text-2xl font-extrabold">Earnings</h1>
        <div className="flex bg-gray-100 rounded-xl p-1 mt-3">
          {[
            { k: "today", l: "Today" },
            { k: "week", l: "Week" },
            { k: "month", l: "Month" },
          ].map((t) => (
            <button key={t.k} data-testid={`earnings-tab-${t.k}`} onClick={() => setTab(t.k)}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${tab === t.k ? "bg-white shadow-sm text-gray-900" : "text-gray-500"}`}>
              {t.l}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pt-5">
        {/* Main */}
        <div className="bg-white rounded-3xl p-5 shadow-lg border border-gray-100" data-testid="earnings-main">
          <div className="text-[11px] font-bold uppercase tracking-wider text-gray-500">{tab === "today" ? "Today's Total" : tab === "week" ? "This Week" : "This Month"}</div>
          <div className="font-display text-4xl font-extrabold mt-1 flex items-baseline gap-1">
            {data ? INR(amount) : <Skeleton className="h-8 w-32 rounded-lg" />}
          </div>
          <div className="text-xs text-gray-500 font-semibold mt-1">{data?.deliveries ?? 0} total deliveries</div>
        </div>

        {/* Bonus */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <BonusCard icon={Gift} label="Bonuses" value={data ? INR(data.bonuses) : "—"} sub="Earn streak rewards" />
          <BonusCard icon={Star} label="Incentives" value={data ? INR(data.incentives) : "—"} sub="Top-performer pool" />
        </div>

        {/* Chart */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mt-4" data-testid="earnings-chart">
          <div className="flex items-center justify-between mb-1">
            <div className="font-display font-bold">Weekly trend</div>
            <span className="text-[11px] text-gray-500 font-semibold">Last 7 days</span>
          </div>
          <div style={{ height: 180 }}>
            {data?.chart ? (
              <ResponsiveContainer>
                <BarChart data={data.chart} margin={{ top: 10, right: 8, left: -28, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                  <XAxis dataKey="day" tick={{ fill: "#6B7280", fontSize: 11, fontWeight: 700 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9CA3AF", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: "rgba(244,180,0,0.06)" }} contentStyle={{ background: "white", border: "1px solid #E5E7EB", borderRadius: 12, fontSize: 12, fontWeight: 600 }} formatter={(v) => INR(v)} />
                  <Bar dataKey="amount" fill="#F4B400" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <Skeleton className="h-full w-full rounded-xl" />}
          </div>
        </div>

        <button data-testid="earnings-wallet-btn" onClick={() => nav("/wallet")} className="mt-4 w-full bg-white border border-gray-100 shadow-sm rounded-2xl p-4 flex items-center gap-3 active:scale-[0.99]">
          <div className="w-11 h-11 rounded-xl bg-green-50 flex items-center justify-center"><WalletIcon className="text-[#16A34A]" size={20} /></div>
          <div className="flex-1 text-left">
            <div className="font-bold">Wallet &amp; Payouts</div>
            <div className="text-xs text-gray-500">Balance, transactions and settlements</div>
          </div>
          <ArrowRight size={18} className="text-gray-400" />
        </button>
      </div>
      <BottomNav />
    </div>
  );
}

function BonusCard({ icon: Icon, label, value, sub }) {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-3.5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="text-[11px] font-bold uppercase tracking-wider text-gray-500">{label}</div>
        <div className="w-7 h-7 rounded-lg bg-[#FEF7E6] text-[#F4B400] flex items-center justify-center"><Icon size={14} /></div>
      </div>
      <div className="font-display text-xl font-extrabold mt-1.5">{value}</div>
      <div className="text-[11px] text-gray-500 font-semibold mt-0.5">{sub}</div>
    </div>
  );
}
