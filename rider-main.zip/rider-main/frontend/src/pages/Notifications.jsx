import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Bell, Package, IndianRupee, Settings } from "lucide-react";
import { riderNotifications, markNotifRead } from "../lib/api";
import { Skeleton } from "../components/ui-bits";

const ICONS = { order: Package, payout: IndianRupee, system: Settings };

export default function Notifications() {
  const nav = useNavigate();
  const [items, setItems] = useState(null);

  useEffect(() => {
    riderNotifications().then((r) => setItems(r.data.items || [])).catch(() => setItems([]));
  }, []);

  const onClick = async (n) => {
    if (!n.read) {
      await markNotifRead(n.notif_id).catch(() => {});
      setItems((arr) => arr.map((x) => x.notif_id === n.notif_id ? { ...x, read: true } : x));
    }
  };

  return (
    <div className="min-h-full pb-10 bg-gray-50">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3 flex items-center gap-3">
        <button data-testid="notif-back-btn" onClick={() => nav(-1)} className="p-2 -ml-2 rounded-xl hover:bg-gray-50"><ArrowLeft size={20} /></button>
        <h1 className="font-display text-xl font-extrabold">Notifications</h1>
      </div>
      <div className="p-4 space-y-2">
        {items === null && [1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}
        {items?.length === 0 && (
          <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-10 text-center text-gray-500">
            <Bell className="mx-auto mb-2 text-gray-300" size={28} />
            <div className="font-bold">All caught up!</div>
          </div>
        )}
        {items?.map((n) => {
          const Icon = ICONS[n.type] || Bell;
          return (
            <button
              key={n.notif_id}
              data-testid={`notif-${n.notif_id}`}
              onClick={() => onClick(n)}
              className={`w-full text-left bg-white border ${n.read ? "border-gray-100" : "border-[#F4B400]"} rounded-2xl p-3.5 flex items-start gap-3 shadow-sm`}
            >
              <div className={`w-9 h-9 rounded-xl ${n.read ? "bg-gray-100 text-gray-500" : "bg-[#FEF7E6] text-[#F4B400]"} flex items-center justify-center`}>
                <Icon size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold">{n.title}</div>
                <div className="text-xs text-gray-500">{n.body}</div>
                <div className="text-[10px] text-gray-400 mt-1">{new Date(n.created_at).toLocaleString()}</div>
              </div>
              {!n.read && <div className="w-2 h-2 rounded-full bg-[#F4B400] mt-1.5" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}
