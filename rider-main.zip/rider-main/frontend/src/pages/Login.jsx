import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Phone, Mail, Loader2 } from "lucide-react";
import { Logo } from "../components/Logo";
import OtpInput from "../components/OtpInput";
import { authSendOtp, authVerifyOtp } from "../lib/api";
import { useAuth } from "../lib/auth";

export default function Login() {
  const nav = useNavigate();
  const { login } = useAuth();
  const [step, setStep] = useState("phone"); // phone | otp
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [otp, setOtp] = useState("");
  const [demoOtp, setDemoOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const sendOtp = async () => {
    setErr("");
    if (phone.length < 10) { setErr("Enter a valid 10-digit mobile"); return; }
    setBusy(true);
    try {
      const r = await authSendOtp("+91" + phone);
      setDemoOtp(r.data.otp); // demo only
      setStep("otp");
    } catch (e) {
      setErr(e?.response?.data?.detail || "Failed to send OTP");
    } finally { setBusy(false); }
  };

  const verifyOtp = async () => {
    setErr("");
    if (otp.length !== 4) { setErr("Enter the 4-digit OTP"); return; }
    setBusy(true);
    try {
      const r = await authVerifyOtp("+91" + phone, otp, name || undefined);
      await login(r.data.token, r.data.user);
      nav("/", { replace: true });
    } catch (e) {
      setErr(e?.response?.data?.detail || "Verification failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-full flex flex-col bg-white">
      {/* Hero */}
      <div className="relative h-[40vh] min-h-[280px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1572195577046-2f25894c06fc?w=1200&q=80"
          alt="rider"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/55 to-white" />
        <div className="relative z-10 p-6 pt-10">
          <Logo size={40} withText light />
        </div>
        <div className="absolute bottom-6 left-6 right-6 z-10">
          <motion.h1
            initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.1 }}
            className="font-display text-white text-3xl font-extrabold leading-tight"
          >
            Deliver fresh,<br />earn fast.
          </motion.h1>
          <motion.p
            initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}
            className="mt-2 text-white/90 font-medium text-sm"
          >
            India's premium laundry delivery network. Sign in to start riding.
          </motion.p>
        </div>
      </div>

      {/* Form */}
      <motion.div
        initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.15 }}
        className="-mt-6 mx-4 bg-white rounded-3xl shadow-xl border border-gray-100 p-5 flex-1"
      >
        <AnimatePresence mode="wait">
          {step === "phone" ? (
            <motion.div key="phone" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
              <div className="flex items-center gap-2 mb-1">
                <Phone size={18} className="text-[#F4B400]" />
                <h2 className="font-display text-xl font-bold">Sign in with mobile</h2>
              </div>
              <p className="text-sm text-gray-500 mb-5">We'll send a one-time code to verify.</p>

              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Mobile Number</label>
              <div className="flex gap-2 mb-3">
                <div className="flex items-center px-3 bg-gray-50 border border-gray-200 rounded-xl font-semibold text-gray-700">+91</div>
                <input
                  data-testid="auth-phone-input"
                  inputMode="numeric"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                  placeholder="98765 43210"
                  className="flex-1 px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-base font-medium focus:ring-2 focus:ring-[#F4B400] focus:border-transparent outline-none"
                />
              </div>

              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Full Name (new accounts)</label>
              <input
                data-testid="auth-name-input"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Rohit Kumar"
                className="w-full px-4 py-3.5 mb-3 bg-gray-50 border border-gray-200 rounded-xl text-base font-medium focus:ring-2 focus:ring-[#F4B400] focus:border-transparent outline-none"
              />

              {err && <div data-testid="auth-error" className="text-red-600 text-sm font-semibold mb-3">{err}</div>}

              <button
                data-testid="auth-send-otp-btn"
                onClick={sendOtp}
                disabled={busy}
                className="w-full py-4 bg-[#F4B400] hover:bg-[#D9A000] text-black font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md active:scale-[0.99] disabled:opacity-60"
              >
                {busy ? <Loader2 className="animate-spin" size={20} /> : <>Send OTP <ArrowRight size={18} /></>}
              </button>

              <div className="flex items-center my-5">
                <div className="flex-1 h-px bg-gray-100" />
                <span className="px-3 text-xs text-gray-400 font-semibold uppercase tracking-wider">or</span>
                <div className="flex-1 h-px bg-gray-100" />
              </div>

              <button
                data-testid="auth-email-login-btn"
                onClick={() => { setErr("Email/Google login coming soon. Please use mobile OTP."); }}
                className="w-full py-4 bg-gray-50 hover:bg-gray-100 text-gray-900 font-bold text-base rounded-xl border border-gray-200 flex items-center justify-center gap-2 active:scale-[0.99]"
              >
                <Mail size={18} /> Continue with Email
              </button>

              <p className="mt-6 text-xs text-gray-400 text-center leading-relaxed">
                By continuing you agree to QuickPress&apos;<br />
                <span className="text-gray-600 font-semibold">Terms of Service</span> &amp; <span className="text-gray-600 font-semibold">Privacy Policy</span>.
              </p>
            </motion.div>
          ) : (
            <motion.div key="otp" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              <h2 className="font-display text-xl font-bold">Verify mobile</h2>
              <p className="text-sm text-gray-500 mb-1">We sent a 4-digit code to <span className="font-semibold text-gray-800">+91 {phone}</span></p>
              {demoOtp && (
                <div data-testid="demo-otp-hint" className="mb-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-50 border border-yellow-200 text-yellow-800 text-xs font-bold">
                  Demo OTP: {demoOtp}
                </div>
              )}
              <div className="my-6">
                <OtpInput value={otp} onChange={setOtp} length={4} />
              </div>
              {err && <div data-testid="auth-error" className="text-red-600 text-sm font-semibold mb-3 text-center">{err}</div>}
              <button
                data-testid="auth-verify-otp-btn"
                onClick={verifyOtp}
                disabled={busy}
                className="w-full py-4 bg-[#F4B400] hover:bg-[#D9A000] text-black font-bold rounded-xl flex items-center justify-center gap-2 shadow-md active:scale-[0.99] disabled:opacity-60"
              >
                {busy ? <Loader2 className="animate-spin" size={20} /> : "Verify & Continue"}
              </button>
              <button
                data-testid="auth-change-number-btn"
                onClick={() => { setStep("phone"); setOtp(""); setDemoOtp(""); }}
                className="w-full mt-3 py-3 text-gray-600 font-semibold rounded-xl hover:bg-gray-50"
              >
                Change number
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
