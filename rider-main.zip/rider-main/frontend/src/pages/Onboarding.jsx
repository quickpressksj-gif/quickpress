import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, Loader2, Bike, ScanLine, Landmark, User as UserIcon, Check, FileText, Upload } from "lucide-react";
import PhotoCapture from "../components/PhotoCapture";
import { Logo } from "../components/Logo";
import { useAuth } from "../lib/auth";
import {
  riderPersonal, riderVehicle, riderDocument, riderBank, riderSubmit, riderApprove,
} from "../lib/api";

const VEHICLE_TYPES = [
  { v: "Bicycle", label: "Bicycle", icon: "🚲", fuel: "None" },
  { v: "Scooter", label: "Scooter", icon: "🛵", fuel: "Petrol" },
  { v: "Motorcycle", label: "Motorcycle", icon: "🏍️", fuel: "Petrol" },
  { v: "Electric Scooter", label: "E-Scooter", icon: "⚡", fuel: "Electric" },
  { v: "Electric Bike", label: "E-Bike", icon: "🔋", fuel: "Electric" },
];

const DOCS = [
  { key: "aadhaar", label: "Aadhaar Card", numbered: true },
  { key: "license", label: "Driving License", numbered: true },
  { key: "rc", label: "Vehicle RC", numbered: true },
  { key: "insurance", label: "Vehicle Insurance", numbered: false },
  { key: "puc", label: "Pollution Cert (PUC)", numbered: false },
  { key: "profile_photo", label: "Profile Photo", numbered: false },
  { key: "selfie", label: "Selfie Verification", numbered: false },
];

const Field = ({ label, children, hint }) => (
  <div className="mb-4">
    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">{label}</label>
    {children}
    {hint && <div className="text-[11px] text-gray-400 mt-1">{hint}</div>}
  </div>
);

const Input = (p) => (
  <input
    {...p}
    className={`w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-base font-medium focus:ring-2 focus:ring-[#F4B400] focus:border-transparent outline-none ${p.className || ""}`}
  />
);

export default function Onboarding() {
  const { rider, refresh } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(rider?.onboarding_step ? Math.min(rider.onboarding_step, 5) : 1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // Step 1
  const [p1, setP1] = useState({
    full_name: rider?.full_name || "",
    mobile: rider?.mobile || "",
    email: rider?.email || "",
    address: rider?.address || "",
    emergency_contact: rider?.emergency_contact || "",
    emergency_name: rider?.emergency_name || "",
  });

  // Step 2
  const [p2, setP2] = useState({
    vehicle_type: rider?.vehicle_type || "",
    vehicle_brand: rider?.vehicle_brand || "",
    vehicle_model: rider?.vehicle_model || "",
    vehicle_number: rider?.vehicle_number || "",
    fuel_type: rider?.fuel_type || "",
  });

  // Step 3 docs state
  const [docs, setDocs] = useState(rider?.documents || {});
  const [docNumber, setDocNumber] = useState({});

  // Step 4
  const [p4, setP4] = useState({
    account_holder: rider?.bank?.account_holder || "",
    account_number: rider?.bank?.account_number || "",
    ifsc: rider?.bank?.ifsc || "",
    bank_name: rider?.bank?.bank_name || "",
    upi_id: rider?.bank?.upi_id || "",
  });

  const total = 5;
  const progressPct = (step / total) * 100;

  const next = async () => {
    setErr("");
    setBusy(true);
    try {
      if (step === 1) {
        if (!p1.full_name || !p1.mobile || !p1.address || !p1.emergency_contact) {
          throw new Error("Please fill all required fields");
        }
        await riderPersonal(p1);
      } else if (step === 2) {
        if (!p2.vehicle_type || !p2.vehicle_number || !p2.vehicle_brand) {
          throw new Error("Vehicle type, brand and number are required");
        }
        await riderVehicle({ ...p2, fuel_type: p2.fuel_type || "Petrol" });
      } else if (step === 3) {
        const need = DOCS.map((d) => d.key);
        const missing = need.filter((k) => !docs[k]?.url);
        if (missing.length) throw new Error(`Upload all documents (${missing.length} pending)`);
      } else if (step === 4) {
        if (!p4.account_holder || !p4.account_number || !p4.ifsc || !p4.bank_name) {
          throw new Error("All bank fields except UPI are required");
        }
        await riderBank(p4);
      }
      await refresh();
      setStep((s) => Math.min(total, s + 1));
    } catch (e) {
      setErr(e?.response?.data?.detail || e.message || "Please try again");
    } finally { setBusy(false); }
  };

  const back = () => setStep((s) => Math.max(1, s - 1));

  const submit = async () => {
    setErr("");
    setBusy(true);
    try {
      await riderSubmit();
      // demo: auto approve so user can immediately try the app end-to-end
      try { await riderApprove(); } catch {}
      await refresh();
      nav("/", { replace: true });
    } catch (e) {
      setErr(e?.response?.data?.detail || "Submission failed");
    } finally { setBusy(false); }
  };

  const uploadDoc = async (key, dataUrl) => {
    setBusy(true);
    try {
      const body = { doc_type: key, number: docNumber[key] || null, url: dataUrl };
      await riderDocument(body);
      setDocs((d) => ({ ...d, [key]: { ...body, status: "Pending", uploaded_at: new Date().toISOString() } }));
      await refresh();
    } catch (e) { setErr(e?.response?.data?.detail || "Upload failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-full flex flex-col bg-white">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xl border-b border-gray-100 px-4 pt-4 pb-3">
        <div className="flex items-center justify-between mb-3">
          <button data-testid="wizard-back-btn" onClick={step === 1 ? () => nav(-1) : back} className="p-2 -ml-2 rounded-xl hover:bg-gray-50">
            <ArrowLeft size={22} />
          </button>
          <Logo size={28} withText={false} />
          <div className="text-xs font-bold text-gray-500 tracking-wider" data-testid="wizard-step-indicator">
            STEP {step}/{total}
          </div>
        </div>
        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
          <motion.div initial={false} animate={{ width: `${progressPct}%` }} transition={{ type: "spring", damping: 24, stiffness: 180 }} className="h-full bg-[#F4B400] rounded-full" />
        </div>
      </div>

      <div className="flex-1 px-4 py-5 pb-32">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="flex items-center gap-2 mb-1"><UserIcon size={18} className="text-[#F4B400]" /><h2 className="font-display text-2xl font-bold">Personal details</h2></div>
              <p className="text-sm text-gray-500 mb-5">Tell us who you are.</p>
              <Field label="Full Name *"><Input data-testid="personal-name-input" value={p1.full_name} onChange={(e) => setP1({ ...p1, full_name: e.target.value })} placeholder="Rohit Kumar" /></Field>
              <Field label="Mobile Number *"><Input data-testid="personal-mobile-input" inputMode="numeric" value={p1.mobile} onChange={(e) => setP1({ ...p1, mobile: e.target.value })} placeholder="+91 98765 43210" /></Field>
              <Field label="Email"><Input data-testid="personal-email-input" type="email" value={p1.email} onChange={(e) => setP1({ ...p1, email: e.target.value })} placeholder="rohit@example.com" /></Field>
              <Field label="Address *">
                <textarea data-testid="personal-address-input" rows={3} value={p1.address} onChange={(e) => setP1({ ...p1, address: e.target.value })} placeholder="House no, street, city, pincode"
                  className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-base font-medium focus:ring-2 focus:ring-[#F4B400] focus:border-transparent outline-none" />
              </Field>
              <Field label="Emergency Contact Name"><Input data-testid="personal-emergency-name" value={p1.emergency_name} onChange={(e) => setP1({ ...p1, emergency_name: e.target.value })} placeholder="Spouse / Parent" /></Field>
              <Field label="Emergency Contact Number *"><Input data-testid="personal-emergency-input" inputMode="numeric" value={p1.emergency_contact} onChange={(e) => setP1({ ...p1, emergency_contact: e.target.value })} placeholder="+91 99999 99999" /></Field>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="flex items-center gap-2 mb-1"><Bike size={18} className="text-[#F4B400]" /><h2 className="font-display text-2xl font-bold">Vehicle details</h2></div>
              <p className="text-sm text-gray-500 mb-5">Choose your ride and add the basics.</p>
              <Field label="Vehicle Type *">
                <div className="grid grid-cols-3 gap-2">
                  {VEHICLE_TYPES.map((v) => (
                    <button
                      key={v.v}
                      data-testid={`vehicle-type-${v.v.toLowerCase().replace(/\s+/g, "-")}`}
                      onClick={() => setP2({ ...p2, vehicle_type: v.v, fuel_type: v.fuel })}
                      className={`p-3 rounded-2xl border-2 text-center transition-all active:scale-[0.98] ${p2.vehicle_type === v.v ? "border-[#F4B400] bg-[#FEF7E6]" : "border-gray-200 bg-white"}`}
                    >
                      <div className="text-2xl mb-1">{v.icon}</div>
                      <div className="text-[11px] font-bold text-gray-700">{v.label}</div>
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="Vehicle Brand *"><Input data-testid="vehicle-brand-input" value={p2.vehicle_brand} onChange={(e) => setP2({ ...p2, vehicle_brand: e.target.value })} placeholder="e.g. Honda" /></Field>
              <Field label="Vehicle Model"><Input data-testid="vehicle-model-input" value={p2.vehicle_model} onChange={(e) => setP2({ ...p2, vehicle_model: e.target.value })} placeholder="e.g. Activa 6G" /></Field>
              <Field label="Vehicle Number *"><Input data-testid="vehicle-number-input" value={p2.vehicle_number} onChange={(e) => setP2({ ...p2, vehicle_number: e.target.value.toUpperCase() })} placeholder="DL 8C XX 1234" /></Field>
              <Field label="Fuel Type"><Input data-testid="vehicle-fuel-input" value={p2.fuel_type} onChange={(e) => setP2({ ...p2, fuel_type: e.target.value })} placeholder="Petrol / Electric" /></Field>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="flex items-center gap-2 mb-1"><ScanLine size={18} className="text-[#F4B400]" /><h2 className="font-display text-2xl font-bold">Documents</h2></div>
              <p className="text-sm text-gray-500 mb-5">Upload clear photos of each document.</p>
              <div className="space-y-3">
                {DOCS.map((d) => {
                  const have = !!docs[d.key]?.url;
                  return (
                    <details key={d.key} className="bg-white border border-gray-200 rounded-2xl overflow-hidden" open={!have} data-testid={`doc-row-${d.key}`}>
                      <summary className="cursor-pointer p-4 flex items-center justify-between list-none">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${have ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-500"}`}>
                            {have ? <Check size={20} /> : <FileText size={20} />}
                          </div>
                          <div>
                            <div className="font-bold text-gray-900">{d.label}</div>
                            <div className="text-xs text-gray-500">{have ? "Uploaded — tap to replace" : "Pending upload"}</div>
                          </div>
                        </div>
                        <Upload size={18} className="text-gray-400" />
                      </summary>
                      <div className="p-4 pt-0 space-y-3">
                        {d.numbered && (
                          <Input
                            data-testid={`doc-number-${d.key}`}
                            placeholder={`${d.label} number`}
                            value={docNumber[d.key] || ""}
                            onChange={(e) => setDocNumber({ ...docNumber, [d.key]: e.target.value })}
                          />
                        )}
                        <PhotoCapture
                          testid={`upload-document-${d.key}`}
                          label={`Tap to upload ${d.label}`}
                          onCapture={(url) => uploadDoc(d.key, url)}
                        />
                      </div>
                    </details>
                  );
                })}
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="s4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="flex items-center gap-2 mb-1"><Landmark size={18} className="text-[#F4B400]" /><h2 className="font-display text-2xl font-bold">Bank details</h2></div>
              <p className="text-sm text-gray-500 mb-5">Where you'd like your earnings sent.</p>
              <Field label="Account Holder *"><Input data-testid="bank-holder-input" value={p4.account_holder} onChange={(e) => setP4({ ...p4, account_holder: e.target.value })} placeholder="As per bank record" /></Field>
              <Field label="Account Number *"><Input data-testid="bank-account-input" inputMode="numeric" value={p4.account_number} onChange={(e) => setP4({ ...p4, account_number: e.target.value })} placeholder="11-digit account no." /></Field>
              <Field label="IFSC *"><Input data-testid="bank-ifsc-input" value={p4.ifsc} onChange={(e) => setP4({ ...p4, ifsc: e.target.value.toUpperCase() })} placeholder="HDFC0001234" /></Field>
              <Field label="Bank Name *"><Input data-testid="bank-name-input" value={p4.bank_name} onChange={(e) => setP4({ ...p4, bank_name: e.target.value })} placeholder="HDFC Bank" /></Field>
              <Field label="UPI ID (optional)"><Input data-testid="bank-upi-input" value={p4.upi_id} onChange={(e) => setP4({ ...p4, upi_id: e.target.value })} placeholder="rider@upi" /></Field>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div key="s5" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="py-6">
              <div className="text-center">
                <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mx-auto w-24 h-24 rounded-full bg-[#FEF7E6] flex items-center justify-center mb-5">
                  <Check size={48} className="text-[#F4B400]" />
                </motion.div>
                <h2 className="font-display text-3xl font-extrabold mb-2">Ready to submit</h2>
                <p className="text-gray-500 mb-7">Your details look good. Submit your application and we'll verify it shortly.</p>
                <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 text-left text-sm space-y-2 mb-6">
                  <div className="flex justify-between"><span className="text-gray-500">Name</span><span className="font-semibold">{p1.full_name}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Vehicle</span><span className="font-semibold">{p2.vehicle_type} • {p2.vehicle_number}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Bank</span><span className="font-semibold">{p4.bank_name}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Documents</span><span className="font-semibold text-green-700">{Object.keys(docs).length}/7 uploaded</span></div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {err && <div data-testid="wizard-error" className="mt-4 px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-red-700 font-semibold text-sm">{err}</div>}
      </div>

      {/* Sticky bottom action */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-100 px-4 py-3 pb-safe z-30">
        {step < total ? (
          <button
            data-testid="wizard-next-btn"
            disabled={busy}
            onClick={next}
            className="w-full py-4 bg-[#F4B400] hover:bg-[#D9A000] text-black font-bold rounded-xl flex items-center justify-center gap-2 shadow-md active:scale-[0.99] disabled:opacity-60"
          >
            {busy ? <Loader2 className="animate-spin" size={20} /> : <>Continue <ArrowRight size={18} /></>}
          </button>
        ) : (
          <button
            data-testid="wizard-submit-btn"
            disabled={busy}
            onClick={submit}
            className="w-full py-4 bg-[#16A34A] hover:bg-[#15803D] text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-md active:scale-[0.99] disabled:opacity-60"
          >
            {busy ? <Loader2 className="animate-spin" size={20} /> : <>Submit Application <Check size={18} /></>}
          </button>
        )}
      </div>
    </div>
  );
}
