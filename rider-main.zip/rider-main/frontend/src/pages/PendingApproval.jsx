import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Clock, RefreshCw, CheckCircle2, AlertCircle, LogOut } from "lucide-react";
import { Logo } from "../components/Logo";
import { useAuth } from "../lib/auth";
import { riderApprove } from "../lib/api";

export default function PendingApproval() {
  const { rider, refresh, logout } = useAuth();
  const [busy, setBusy] = useState(false);

  // Poll every 8s for status changes
  useEffect(() => {
    const id = setInterval(refresh, 8000);
    return () => clearInterval(id);
  }, [refresh]);

  const onApproveDemo = async () => {
    setBusy(true);
    try { await riderApprove(); await refresh(); } finally { setBusy(false); }
  };

  const status = rider?.status || "Pending";
  const checks = [
    { k: "personal", label: "Personal details", ok: !!rider?.full_name },
    { k: "vehicle", label: "Vehicle details", ok: !!rider?.vehicle_number },
    { k: "documents", label: "Documents", ok: Object.keys(rider?.documents || {}).length >= 5 },
    { k: "bank", label: "Bank details", ok: !!rider?.bank },
  ];

  return (
    <div className="min-h-full bg-gradient-to-b from-[#FEF7E6] via-white to-white px-5 py-6 flex flex-col">
      <div className="flex items-center justify-between">
        <Logo size={32} withText />
        <button onClick={logout} data-testid="pending-logout-btn" className="p-2 rounded-xl text-gray-500 hover:bg-gray-100">
          <LogOut size={18} />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center text-center mt-6">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", damping: 12 }}
          className="relative w-32 h-32 rounded-full bg-white shadow-2xl flex items-center justify-center mb-6 border border-yellow-100"
        >
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 8, repeat: Infinity, ease: "linear" }} className="absolute inset-0 rounded-full border-4 border-dashed border-[#F4B400]/50" />
          {status === "Approved" ? <CheckCircle2 size={56} className="text-[#16A34A]" /> :
            status === "Rejected" || status === "Suspended" ? <AlertCircle size={56} className="text-red-500" /> :
              <Clock size={56} className="text-[#F4B400]" />}
        </motion.div>

        <h1 className="font-display text-3xl font-extrabold leading-tight">
          {status === "Approved" ? "You're approved!" :
            status === "Rejected" ? "Application rejected" :
              status === "Suspended" ? "Account suspended" :
                "Under review"}
        </h1>
        <p className="mt-2 text-gray-500 max-w-xs">
          {status === "Approved" ? "Welcome to QuickPress. You can now go online and start delivering." :
            status === "Rejected" ? "Please contact support to know more or re-apply with corrected documents." :
              status === "Suspended" ? "Please reach out to support to reinstate your account." :
                "We're verifying your details. This usually takes a few minutes. You'll be notified the moment you're approved."}
        </p>

        <div data-testid="pending-status-card" className="mt-6 w-full max-w-sm bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
          {checks.map((c) => (
            <div key={c.k} className="flex items-center justify-between py-2.5">
              <div className="flex items-center gap-3">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center ${c.ok ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-400"}`}>
                  <CheckCircle2 size={16} />
                </div>
                <span className="font-semibold text-gray-800">{c.label}</span>
              </div>
              <span className={`text-xs font-bold uppercase ${c.ok ? "text-green-700" : "text-gray-400"}`}>{c.ok ? "Done" : "Pending"}</span>
            </div>
          ))}
        </div>

        <button
          data-testid="pending-refresh-btn"
          onClick={() => refresh()}
          className="mt-5 flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-gray-200 font-bold text-gray-700 text-sm shadow-sm hover:bg-gray-50"
        >
          <RefreshCw size={14} /> Refresh status
        </button>

        {status === "Pending" && (
          <button
            data-testid="pending-demo-approve-btn"
            onClick={onApproveDemo}
            disabled={busy}
            className="mt-3 px-4 py-2 rounded-full bg-[#F4B400] text-black font-bold text-sm shadow-md hover:bg-[#D9A000] disabled:opacity-60"
          >
            {busy ? "Approving…" : "Demo: Auto-approve me"}
          </button>
        )}
      </div>
    </div>
  );
}
