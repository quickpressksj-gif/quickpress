# QuickPress Rider Application — PRD

## Original problem statement
Build a premium, production-ready Rider application for QuickPress, reusing the
existing QuickPress backend & database. Realtime tracking, OTP-based handover
pipeline, OpenStreetMap (Leaflet/OSRM), responsive web. Brand: yellow #F4B400,
green #16A34A, white background.

## Architecture
- **Backend**: existing FastAPI app from the QuickPress codebase, extended with
  `routes/rider.py` (mounted at `/api/rider`). Reuses `core.db`, `core.get_user_from_token`,
  `auth.py` (mocked OTP), `users`, `orders`, `partners`, `notifications` collections.
  New collections: `riders`, `rider_payouts`, `wallet_transactions`, `support_tickets`,
  `rider_audit`.
- **Frontend**: React (CRA + Tailwind + Craco), responsive single-column max-w-md
  layout (mobile-first PWA-style). Framer Motion for page/sheet animations, Leaflet
  + OSM tiles, OSRM `router.project-osrm.org` for routes, Recharts for earnings chart.

## What's implemented (Jan 2026)
- Auth: Mobile OTP (mocked – OTP returned in API; surfaced as a "demo OTP" pill on Login).
- 5-step Onboarding wizard: Personal → Vehicle → Documents (7 docs with camera
  capture + GPS+timestamp overlay) → Bank → Review/Submit. Auto-approve in demo so
  e2e flow runs immediately.
- Pending Approval screen with live status polling (8s).
- Dashboard: prominent online/offline power-button, today/week stats, rating, completion,
  active orders, nearby orders, AssignmentSheet with 30s countdown timer to accept/reject,
  one-click "seed demo orders" link.
- OrderActive: Leaflet map with branded rider/partner/customer markers + OSRM route polyline,
  contextual pipeline timeline (8 statuses), action sheet that adapts to the current step:
  arrival confirmation, photo capture, or OTP+photo verification. OTP hints shown to the
  rider so they can read to partner/customer. Status flows through Rider Assigned → Arrived
  at Customer → Picked Up → Arrived at Partner → Delivered to Partner → Ready → Out for
  Delivery → Arrived at Drop → Delivered. Final delivery credits the wallet.
- Orders list (active + history tabs), Earnings (today/week/month + bar chart), Wallet &
  Payouts (request payout, transactions, payout history), Notifications, Profile, Support.
- Live tracking: location pushed every 5s while online or while order is active.
- Bottom-nav (4 tabs) z-index 2147483646 so it isn't covered by the platform badge.
- Audit logs: every state-changing rider action is recorded in `rider_audit`.

## User personas
- **Rider**: gig delivery rider on a phone browser. Needs frictionless onboarding,
  fast online/offline toggle, very clear order pipeline, OTP+photo confirmations,
  visible earnings, fast payout.

## Backlog (P1/P2)
- P1: True websocket assignments push (replace 5s polling). Image upload to S3 instead
  of base64. Live route re-optimization via OSRM legs per leg.
- P2: Admin verification UI (currently rider self-approves in demo). Multi-stop batched
  orders. Heatmap of demand hotspots. In-app chat between rider/customer/partner.
- Smart enhancement: **referral bonus** flow – riders share their referral code, and earn
  ₹200 when an invited friend completes 5 deliveries (boosts supply-side virality).

## Next action items
- Replace the demo auto-approve with a real admin review queue.
- Add in-app live chat with customer/partner using websockets.
- Persist documents to S3 (currently stored as base64 data URLs on the order/rider).
